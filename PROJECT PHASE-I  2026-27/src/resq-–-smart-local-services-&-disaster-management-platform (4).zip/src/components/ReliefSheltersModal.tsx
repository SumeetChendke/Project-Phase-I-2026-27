import React, { useState, useEffect } from 'react';
import {
  X,
  LifeBuoy,
  MapPin,
  Phone,
  Droplet,
  Home,
  HeartPulse,
  Navigation,
  CheckCircle2,
} from 'lucide-react';
import { ReliefResource } from '../types';
import { api } from '../services/api';
import { useLocation } from '../context/LocationContext';

interface ReliefSheltersModalProps {
  onClose: () => void;
}

export const ReliefSheltersModal: React.FC<ReliefSheltersModalProps> = ({ onClose }) => {
  const { location } = useLocation();
  const [resources, setResources] = useState<ReliefResource[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    api
      .getReliefResources(location.lat, location.lng)
      .then((data) => {
        if (isMounted) {
          setResources(data);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error(err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [location.lat, location.lng]);

  const getResourceIcon = (type: ReliefResource['resourceType']) => {
    switch (type) {
      case 'drinking_water':
        return <Droplet className="w-4 h-4 text-blue-600" />;
      case 'medical_camp':
        return <HeartPulse className="w-4 h-4 text-red-600" />;
      default:
        return <Home className="w-4 h-4 text-purple-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center">
              <LifeBuoy className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold">Disaster Relief Centres &amp; Shelters</h3>
              <p className="text-xs text-slate-400">
                Municipal shelters, emergency drinking water, and field medical triage near {location.name}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {isLoading ? (
            <div className="py-12 text-center text-xs text-slate-400">Locating relief centres...</div>
          ) : resources.length > 0 ? (
            resources.map((res) => {
              const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                `${res.name} ${res.address}`
              )}`;

              return (
                <div
                  key={res.id}
                  className="p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 rounded-lg bg-slate-100">{getResourceIcon(res.resourceType)}</div>
                        <h4 className="text-sm font-bold text-slate-900">{res.name}</h4>
                      </div>
                      <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200">
                        {res.operatingStatus}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{res.address}</span>
                      <span>·</span>
                      <span className="font-mono tabular-nums text-slate-700 font-medium">
                        {res.distanceKm} km away
                      </span>
                    </div>

                    {res.suppliesAvailable && res.suppliesAvailable.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 my-2">
                        {res.suppliesAvailable.map((sup) => (
                          <span
                            key={sup}
                            className="px-2 py-0.5 text-[11px] bg-slate-100 text-slate-700 rounded-md"
                          >
                            {sup}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <div>
                      {res.contactPerson && (
                        <span className="text-slate-500 block text-[11px]">
                          Officer: {res.contactPerson} ({res.contactPhone})
                        </span>
                      )}
                      {typeof res.capacity === 'number' && (
                        <span className="text-slate-600 text-[11px] font-mono">
                          Occupancy: {res.currentOccupancy ?? 0} / {res.capacity}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <a
                        href={`tel:${res.contactPhone}`}
                        className="px-3 py-1.5 font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1"
                      >
                        <Phone className="w-3 h-3 text-slate-600" />
                        <span>Call</span>
                      </a>
                      <a
                        href={mapsUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg flex items-center gap-1"
                      >
                        <Navigation className="w-3 h-3" />
                        <span>Directions</span>
                      </a>
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-8 text-center bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-500">
              No designated relief centers recorded in this immediate radius. Check with local District Emergency Operations Centre (1077).
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
