import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  ServiceProvider,
  ServiceCategory,
  ServiceBooking,
  ServiceReview,
  EmergencyReport,
  DisasterGuide,
  DisasterAlert,
  ReliefResource,
  EmergencyContact,
} from '../types';
import { SERVICE_CATEGORIES } from '../data/categoriesData';
import { DISASTER_GUIDES } from '../data/disasterGuidesData';
import { EMERGENCY_CONTACTS } from '../data/emergencyContactsData';
import { SEED_PROVIDERS, SEED_ALERTS, SEED_RELIEF_RESOURCES } from '../data/seedProvidersData';

// Haversine formula to calculate accurate distance between two geographical points in km
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

// In-Memory Database Store (mirrored with Supabase when configured)
class AppDatabase {
  private supabase: SupabaseClient | null = null;
  public categories: ServiceCategory[] = [...SERVICE_CATEGORIES];
  public providers: ServiceProvider[] = [...SEED_PROVIDERS];
  public bookings: ServiceBooking[] = [
    {
      id: 'book-001',
      userId: 'user-demo-123',
      providerId: 'garage-001',
      providerName: 'CityAuto 24-Hour Garage & Roadside Assistance',
      categoryName: 'Car & Bike Garages',
      serviceTitle: 'Brake Inspection & Emergency Battery Jumpstart',
      bookingDate: '2026-10-23',
      bookingTime: '10:30 AM',
      status: 'accepted',
      contactPhone: '+91-98110-44221',
      notes: 'Car stopped near Inner Circle block B.',
      createdAt: new Date().toISOString(),
    },
  ];
  public reviews: ServiceReview[] = [
    {
      id: 'rev-001',
      userId: 'user-001',
      userName: 'Vikram Malhotra',
      providerId: 'hosp-001',
      rating: 5,
      comment: 'Immediate attention at AIIMS Trauma triage when my uncle had severe chest pain. Fast response.',
      isVerifiedVisit: true,
      status: 'approved',
      createdAt: '2026-09-15T10:00:00Z',
    },
    {
      id: 'rev-002',
      userId: 'user-002',
      userName: 'Priya Sundaram',
      providerId: 'garage-001',
      rating: 5,
      comment: 'Came to Connaught Place within 20 minutes for tire puncture and battery jump. Honest billing.',
      isVerifiedVisit: true,
      status: 'approved',
      createdAt: '2026-10-02T14:30:00Z',
    },
  ];
  public favorites: { id: string; userId: string; providerId: string; createdAt: string }[] = [
    {
      id: 'fav-001',
      userId: 'user-demo-123',
      providerId: 'hosp-001',
      createdAt: new Date().toISOString(),
    },
  ];
  public reports: EmergencyReport[] = [
    {
      id: 'rep-001',
      userId: 'user-demo-123',
      userName: 'Local Citizen',
      reportType: 'disaster_hazard',
      title: 'Waterlogging under Minto Bridge underpass',
      description: 'Water depth approximately 3 feet, cars getting stranded. Barricade required immediately.',
      locationName: 'Minto Bridge, Connaught Place Outer',
      latitude: 28.6360,
      longitude: 77.2280,
      status: 'investigating',
      urgency: 'high',
      createdAt: '2026-10-22T04:15:00Z',
    },
  ];
  public disasterGuides: DisasterGuide[] = [...DISASTER_GUIDES];
  public alerts: DisasterAlert[] = [...SEED_ALERTS];
  public reliefResources: ReliefResource[] = [...SEED_RELIEF_RESOURCES];
  public emergencyContacts: EmergencyContact[] = [...EMERGENCY_CONTACTS];

  constructor() {
    const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
    const supabaseKey = process.env.SUPABASE_SECRET_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY;

    if (supabaseUrl && supabaseKey && !supabaseUrl.includes('your-project')) {
      try {
        this.supabase = createClient(supabaseUrl, supabaseKey);
        console.log('[ResQ DB] Connected to Supabase backend instance:', supabaseUrl);
      } catch (err) {
        console.warn('[ResQ DB] Supabase initialization failed, falling back to local persistent store.', err);
      }
    } else {
      console.log('[ResQ DB] Supabase credentials not set or using placeholder; operating in high-performance local store mode.');
    }
  }

  // Get all categories
  getCategories(): ServiceCategory[] {
    return this.categories;
  }

  // Dynamically add live discovered providers
  addProviders(newProviders: ServiceProvider[]) {
    for (const p of newProviders) {
      if (!this.providers.some((existing) => existing.id === p.id)) {
        this.providers.push(p);
      }
    }
  }

  // Search and find nearby services
  getNearbyServices(params: {
    lat: number;
    lng: number;
    categoryId?: string;
    query?: string;
    radiusKm?: number;
    sortBy?: 'rating' | 'reviews' | 'distance' | 'balanced';
  }): ServiceProvider[] {
    const { lat, lng, categoryId, query, radiusKm = 50, sortBy = 'balanced' } = params;

    let results = this.providers.map((p) => {
      const distance = calculateDistanceKm(lat, lng, p.latitude, p.longitude);
      return {
        ...p,
        distanceKm: distance,
      };
    });

    // Filter by radius
    if (radiusKm > 0) {
      results = results.filter((p) => (p.distanceKm ?? 0) <= radiusKm);
    }

    // Filter by category
    if (categoryId && categoryId !== 'all') {
      results = results.filter((p) => p.primaryCategoryId.toLowerCase() === categoryId.toLowerCase());
    }

    // Filter by query
    if (query && query.trim().length > 0) {
      const q = query.toLowerCase().trim();
      results = results.filter(
        (p) =>
          p.businessName.toLowerCase().includes(q) ||
          p.locality.toLowerCase().includes(q) ||
          p.city.toLowerCase().includes(q) ||
          p.address.toLowerCase().includes(q) ||
          (p.servicesOffered && p.servicesOffered.some((s) => s.toLowerCase().includes(q)))
      );
    }

    // Ranking and sorting logic
    results.sort((a, b) => {
      if (sortBy === 'distance') {
        return (a.distanceKm ?? 0) - (b.distanceKm ?? 0);
      }
      if (sortBy === 'reviews') {
        const revA = a.googleReviewCount ?? 0;
        const revB = b.googleReviewCount ?? 0;
        return revB - revA;
      }
      if (sortBy === 'rating') {
        const rateA = a.googleRating ?? -1;
        const rateB = b.googleRating ?? -1;
        return rateB - rateA;
      }

      // Default 'balanced' ranking algorithm (Bayesian weighted score with distance decay)
      // W = (v / (v + m)) * R + (m / (v + m)) * C
      const m = 30; // minimum review weight
      const C = 4.0; // baseline prior
      const vA = a.googleReviewCount ?? 0;
      const rA = a.googleRating ?? C;
      const scoreA = (vA / (vA + m)) * rA + (m / (vA + m)) * C - (a.distanceKm ?? 0) * 0.02;

      const vB = b.googleReviewCount ?? 0;
      const rB = b.googleRating ?? C;
      const scoreB = (vB / (vB + m)) * rB + (m / (vB + m)) * C - (b.distanceKm ?? 0) * 0.02;

      return scoreB - scoreA;
    });

    return results;
  }

  // Mandatory Section 4: Popular Hospitals Near User with configurable ranking
  getPopularHospitals(params: {
    lat: number;
    lng: number;
    sortBy?: 'rating' | 'reviews' | 'distance';
    limit?: number;
  }): ServiceProvider[] {
    const { lat, lng, sortBy = 'rating', limit = 10 } = params;

    let hospitals = this.providers
      .filter((p) => p.primaryCategoryId === 'hospitals')
      .map((p) => ({
        ...p,
        distanceKm: calculateDistanceKm(lat, lng, p.latitude, p.longitude),
      }));

    hospitals.sort((a, b) => {
      if (sortBy === 'distance') {
        return (a.distanceKm ?? 0) - (b.distanceKm ?? 0);
      }
      if (sortBy === 'reviews') {
        const revA = a.googleReviewCount ?? 0;
        const revB = b.googleReviewCount ?? 0;
        return revB - revA;
      }
      // 'rating' sort: avoid ranking a 1-review hospital with 5.0 above a 4.7 hospital with thousands of reviews
      // If review counts are comparable (>20), sort by raw rating. If rating missing, goes to end.
      const rateA = a.googleRating ?? 0;
      const rateB = b.googleRating ?? 0;
      const countA = a.googleReviewCount ?? 0;
      const countB = b.googleReviewCount ?? 0;

      // Bayesian weighting for rating
      const m = 25;
      const C = 4.0;
      const weightedA = (countA / (countA + m)) * rateA + (m / (countA + m)) * C;
      const weightedB = (countB / (countB + m)) * rateB + (m / (countB + m)) * C;

      return weightedB - weightedA;
    });

    return hospitals.slice(0, limit);
  }

  // Get single provider by ID
  getProviderById(id: string): ServiceProvider | null {
    const found = this.providers.find((p) => p.id === id);
    return found || null;
  }

  // Bookings
  createBooking(booking: Omit<ServiceBooking, 'id' | 'createdAt'>): ServiceBooking {
    const newBooking: ServiceBooking = {
      ...booking,
      id: `book-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.bookings.unshift(newBooking);
    return newBooking;
  }

  getBookingsByUser(userId: string): ServiceBooking[] {
    return this.bookings.filter((b) => b.userId === userId);
  }

  updateBookingStatus(id: string, status: ServiceBooking['status']): ServiceBooking | null {
    const booking = this.bookings.find((b) => b.id === id);
    if (!booking) return null;
    booking.status = status;
    return booking;
  }

  // Reviews
  createReview(review: Omit<ServiceReview, 'id' | 'createdAt' | 'status'>): ServiceReview {
    const newReview: ServiceReview = {
      ...review,
      id: `rev-${Date.now()}`,
      status: 'approved',
      createdAt: new Date().toISOString(),
    };
    this.reviews.unshift(newReview);

    // Update platform reviews on provider
    const provider = this.providers.find((p) => p.id === review.providerId);
    if (provider) {
      const providerReviews = this.reviews.filter((r) => r.providerId === provider.id && r.status === 'approved');
      const totalScore = providerReviews.reduce((sum, r) => sum + r.rating, 0);
      provider.platformRating = Math.round((totalScore / providerReviews.length) * 10) / 10;
      provider.platformReviewCount = (provider.platformReviewCount || 0) + 1;
    }

    return newReview;
  }

  getReviewsByProvider(providerId: string): ServiceReview[] {
    return this.reviews.filter((r) => r.providerId === providerId && r.status === 'approved');
  }

  // Favorites
  addFavorite(userId: string, providerId: string): boolean {
    const exists = this.favorites.some((f) => f.userId === userId && f.providerId === providerId);
    if (!exists) {
      this.favorites.push({
        id: `fav-${Date.now()}`,
        userId,
        providerId,
        createdAt: new Date().toISOString(),
      });
      return true;
    }
    return false;
  }

  removeFavorite(userId: string, providerId: string): boolean {
    const idx = this.favorites.findIndex((f) => f.userId === userId && f.providerId === providerId);
    if (idx !== -1) {
      this.favorites.splice(idx, 1);
      return true;
    }
    return false;
  }

  getFavoritesByUser(userId: string): ServiceProvider[] {
    const userFavIds = this.favorites.filter((f) => f.userId === userId).map((f) => f.providerId);
    return this.providers.filter((p) => userFavIds.includes(p.id));
  }

  // Reports
  createReport(report: Omit<EmergencyReport, 'id' | 'createdAt' | 'status'>): EmergencyReport {
    const newReport: EmergencyReport = {
      ...report,
      id: `rep-${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    this.reports.unshift(newReport);
    return newReport;
  }

  getReports(): EmergencyReport[] {
    return this.reports;
  }

  updateReportStatus(id: string, status: EmergencyReport['status']): EmergencyReport | null {
    const report = this.reports.find((r) => r.id === id);
    if (!report) return null;
    report.status = status;
    return report;
  }

  // Relief Resources
  getReliefResources(lat: number, lng: number): ReliefResource[] {
    return this.reliefResources.map((res) => ({
      ...res,
      distanceKm: calculateDistanceKm(lat, lng, res.latitude, res.longitude),
    }));
  }

  // Disaster Guides
  getDisasterGuides(): DisasterGuide[] {
    return this.disasterGuides;
  }

  getDisasterGuideById(id: string): DisasterGuide | null {
    return this.disasterGuides.find((g) => g.id === id) || null;
  }

  // Alerts
  getAlerts(): DisasterAlert[] {
    return this.alerts.filter((a) => a.isActive);
  }

  createAlert(alert: Omit<DisasterAlert, 'id' | 'isActive'>): DisasterAlert {
    const newAlert: DisasterAlert = {
      ...alert,
      id: `alert-${Date.now()}`,
      isActive: true,
    };
    this.alerts.unshift(newAlert);
    return newAlert;
  }

  // Contacts
  getEmergencyContacts(): EmergencyContact[] {
    return this.emergencyContacts;
  }

  // Admin stats
  getAdminStats() {
    return {
      totalCategories: this.categories.length,
      totalProviders: this.providers.length,
      activeAlertsCount: this.alerts.filter((a) => a.isActive).length,
      pendingReportsCount: this.reports.filter((r) => r.status === 'pending').length,
      totalBookingsCount: this.bookings.length,
      totalReviewsCount: this.reviews.length,
    };
  }
}

export const db = new AppDatabase();
