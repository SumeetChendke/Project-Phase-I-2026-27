import React, { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  ShieldAlert,
  Radio,
  FileCheck,
  AlertTriangle,
  Users,
  CheckCircle2,
  Clock,
  Layers,
  Send,
} from 'lucide-react';
import { api } from '../services/api';
import { DisasterAlert } from '../types';

interface AdminDashboardModalProps {
  onClose: () => void;
  onAlertBroadcasted?: () => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  onClose,
  onAlertBroadcasted,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'reports' | 'alerts' | 'resources'>('overview');
  const [overviewData, setOverviewData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  // New alert broadcast form
  const [alertHazard, setAlertHazard] = useState('Heavy Rainfall & Cloudburst Warning');
  const [alertTitle, setAlertTitle] = useState('IMD Flash Flood Warning for Downstream River Sectors');
  const [alertArea, setAlertArea] = useState('Central District & Low-lying River Basins');
  const [alertSeverity, setAlertSeverity] = useState<'warning' | 'severe' | 'critical' | 'advisory'>('severe');
  const [alertDetails, setAlertDetails] = useState('');
  const [alertInstructions, setAlertInstructions] = useState('');
  const [alertSource, setAlertSource] = useState('State Disaster Management Authority (SDMA)');
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  useEffect(() => {
    let isMounted = true;
    api
      .getAdminOverview()
      .then((data) => {
        if (isMounted) {
          setOverviewData(data);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error(err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const handlePublishAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.createAlert({
        hazardType: alertHazard,
        title: alertTitle,
        affectedArea: alertArea,
        severity: alertSeverity,
        source: alertSource,
        details: alertDetails || 'Rapid escalation in water volume reported by telemetry sensors.',
        instructions: alertInstructions || 'Avoid river embankments, secure livestock, and evacuate to upper floors.',
        issueTime: new Date().toISOString(),
        verifiedStatus: true,
      });
      setBroadcastSuccess(true);
      if (onAlertBroadcasted) onAlertBroadcasted();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
        {/* Top Bar */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold">ResQ Operations &amp; Admin Console</h3>
                <span className="text-[10px] bg-indigo-900/80 text-indigo-200 px-2 py-0.5 rounded-sm font-mono">
                  Super Admin
                </span>
              </div>
              <p className="text-xs text-slate-400">
                System telemetry, alert broadcasting, review moderation, and report audit logs
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 px-6 bg-slate-50 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'overview'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Platform Telemetry
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('alerts')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'alerts'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Broadcast Official Alert
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('reports')}
            className={`py-3 px-4 border-b-2 transition-colors ${
              activeTab === 'reports'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            Citizen Reports Audit
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {isLoading ? (
            <div className="py-12 text-center text-xs text-slate-400">Loading admin data...</div>
          ) : (
            <>
              {/* 1. OVERVIEW TELEMETRY */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* KPI Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="p-4 rounded-xl border border-slate-200 bg-white">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                        Service Categories
                      </span>
                      <p className="text-2xl font-black text-slate-900 mt-1 tabular-nums">
                        {overviewData?.stats?.totalCategories || 44}
                      </p>
                      <span className="text-[11px] text-slate-500">7 Functional groups</span>
                    </div>

                    <div className="p-4 rounded-xl border border-slate-200 bg-white">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                        Verified Providers
                      </span>
                      <p className="text-2xl font-black text-slate-900 mt-1 tabular-nums">
                        {overviewData?.stats?.totalProviders || 20}
                      </p>
                      <span className="text-[11px] text-emerald-600 font-medium">100% geo-indexed</span>
                    </div>

                    <div className="p-4 rounded-xl border border-slate-200 bg-white">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                        Active Alerts
                      </span>
                      <p className="text-2xl font-black text-red-600 mt-1 tabular-nums">
                        {overviewData?.stats?.activeAlertsCount || 2}
                      </p>
                      <span className="text-[11px] text-slate-500">IMD &amp; CPCB verified</span>
                    </div>

                    <div className="p-4 rounded-xl border border-slate-200 bg-white">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                        Pending Reports
                      </span>
                      <p className="text-2xl font-black text-amber-600 mt-1 tabular-nums">
                        {overviewData?.stats?.pendingReportsCount || 1}
                      </p>
                      <span className="text-[11px] text-slate-500">Awaiting field audit</span>
                    </div>
                  </div>

                  {/* Recent Bookings Activity */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                      Recent Service Appointments &amp; Requests
                    </h4>
                    <div className="space-y-2">
                      {overviewData?.recentBookings?.map((b: any) => (
                        <div
                          key={b.id}
                          className="p-3.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs"
                        >
                          <div>
                            <span className="font-bold text-slate-900">{b.providerName}</span>
                            <p className="text-slate-500">{b.serviceTitle}</p>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200">
                              {b.status}
                            </span>
                            <span className="text-[11px] text-slate-400 block mt-0.5 font-mono">
                              {b.bookingDate} {b.bookingTime}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 2. BROADCAST ALERT */}
              {activeTab === 'alerts' && (
                <div>
                  {broadcastSuccess ? (
                    <div className="p-6 text-center bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900">
                      <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
                      <h4 className="text-base font-bold">Official Alert Broadcasted</h4>
                      <p className="text-xs mt-1 text-emerald-700">
                        This advisory is now live in the early warning banner for all citizens in the designated region.
                      </p>
                      <button
                        type="button"
                        onClick={() => setBroadcastSuccess(false)}
                        className="mt-4 px-4 py-2 text-xs font-semibold bg-emerald-700 text-white rounded-lg hover:bg-emerald-800"
                      >
                        Publish Another Warning
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={handlePublishAlert} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">
                            Hazard Classification:
                          </label>
                          <input
                            type="text"
                            value={alertHazard}
                            onChange={(e) => setAlertHazard(e.target.value)}
                            required
                            className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">
                            Severity Level:
                          </label>
                          <select
                            value={alertSeverity}
                            onChange={(e) => setAlertSeverity(e.target.value as any)}
                            className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                          >
                            <option value="critical">Critical (Immediate life threat / Red Alert)</option>
                            <option value="severe">Severe (Orange Alert / Extreme precautions)</option>
                            <option value="warning">Warning (Yellow Alert / Stay vigilant)</option>
                            <option value="advisory">Advisory (Informational notice)</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Alert Headline / Title:
                        </label>
                        <input
                          type="text"
                          value={alertTitle}
                          onChange={(e) => setAlertTitle(e.target.value)}
                          required
                          className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">
                            Affected Geographic Area:
                          </label>
                          <input
                            type="text"
                            value={alertArea}
                            onChange={(e) => setAlertArea(e.target.value)}
                            required
                            className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-medium text-slate-700 mb-1">
                            Official Authorizing Source:
                          </label>
                          <input
                            type="text"
                            value={alertSource}
                            onChange={(e) => setAlertSource(e.target.value)}
                            required
                            className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Situation Assessment &amp; Technical Details:
                        </label>
                        <textarea
                          rows={3}
                          value={alertDetails}
                          onChange={(e) => setAlertDetails(e.target.value)}
                          placeholder="Provide telemetry readings, river discharge rates, or seismic epicenter info..."
                          className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Mandatory Public Action Instructions:
                        </label>
                        <textarea
                          rows={3}
                          value={alertInstructions}
                          onChange={(e) => setAlertInstructions(e.target.value)}
                          placeholder="e.g. Do not attempt crossing underpasses; boil drinking water; charge essential backup batteries..."
                          className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl transition-colors shadow-sm flex items-center justify-center gap-2"
                      >
                        <Radio className="w-4 h-4" />
                        <span>Broadcast Official Early Warning</span>
                      </button>
                    </form>
                  )}
                </div>
              )}

              {/* 3. CITIZEN REPORTS AUDIT */}
              {activeTab === 'reports' && (
                <div className="space-y-3">
                  {overviewData?.recentReports?.map((rep: any) => (
                    <div
                      key={rep.id}
                      className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col sm:flex-row sm:items-start justify-between gap-3 text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-slate-900">{rep.title}</span>
                          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-blue-50 text-blue-700">
                            {rep.reportType}
                          </span>
                        </div>
                        <p className="text-slate-600 leading-relaxed">{rep.description}</p>
                        <span className="text-[11px] text-slate-400 mt-1 block font-mono">
                          Location: {rep.locationName} · Urgency: {rep.urgency.toUpperCase()}
                        </span>
                      </div>
                      <div className="shrink-0 flex items-center gap-2">
                        <button
                          type="button"
                          className="px-2.5 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 rounded-md hover:bg-emerald-100"
                        >
                          Resolve
                        </button>
                        <button
                          type="button"
                          className="px-2.5 py-1 text-xs font-medium text-slate-500 bg-slate-100 rounded-md hover:bg-slate-200"
                        >
                          Dismiss
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
