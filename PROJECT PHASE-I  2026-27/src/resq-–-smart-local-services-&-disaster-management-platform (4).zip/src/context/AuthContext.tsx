import React, { createContext, useContext, useState, useEffect } from 'react';
import { createClient, SupabaseClient, User as SupabaseUser } from '@supabase/supabase-js';
import { AppUser } from '../types';

interface AuthContextType {
  user: AppUser | null;
  supabaseClient: SupabaseClient | null;
  loginDemoUser: (role?: AppUser['role']) => void;
  logout: () => void;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isModerator: boolean;
  isProvider: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [supabaseClient, setSupabaseClient] = useState<SupabaseClient | null>(null);
  const [user, setUser] = useState<AppUser | null>(() => {
    const saved = localStorage.getItem('resq_auth_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    // Default guest user has demo profile available
    return {
      id: 'user-demo-123',
      email: 'citizen.care@resq.in',
      fullName: 'Aarav Sharma',
      role: 'user',
      phone: '+91-98765-43210',
    };
  });

  useEffect(() => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

    if (supabaseUrl && supabaseKey && !supabaseUrl.includes('your-project')) {
      try {
        const client = createClient(supabaseUrl, supabaseKey);
        setSupabaseClient(client);

        client.auth.getSession().then(({ data: { session } }) => {
          if (session?.user) {
            mapSupabaseUser(session.user);
          }
        });

        const { data: { subscription } } = client.auth.onAuthStateChange((_event, session) => {
          if (session?.user) {
            mapSupabaseUser(session.user);
          } else {
            // Keep guest demo
          }
        });

        return () => subscription.unsubscribe();
      } catch (err) {
        console.warn('Supabase client init note:', err);
      }
    }
  }, []);

  const mapSupabaseUser = (sbUser: SupabaseUser) => {
    const appUser: AppUser = {
      id: sbUser.id,
      email: sbUser.email || 'user@resq.in',
      fullName: sbUser.user_metadata?.full_name || sbUser.email?.split('@')[0] || 'Citizen',
      role: sbUser.user_metadata?.role || 'user',
      phone: sbUser.phone,
    };
    setUser(appUser);
    localStorage.setItem('resq_auth_user', JSON.stringify(appUser));
  };

  const loginDemoUser = (role: AppUser['role'] = 'user') => {
    const roleNames: Record<AppUser['role'], string> = {
      user: 'Aarav Sharma (Citizen)',
      provider: 'Devendra Kumar (CityAuto Services)',
      moderator: 'Dr. Anita Roy (Disaster Auditor)',
      admin: 'Sumeet Chendke (System Administrator)',
    };

    const newUser: AppUser = {
      id: role === 'admin' ? 'admin-resq-01' : role === 'provider' ? 'prov-001' : 'user-demo-123',
      email: `${role}@resq.in`,
      fullName: roleNames[role],
      role,
      phone: '+91-98110-00222',
    };

    setUser(newUser);
    localStorage.setItem('resq_auth_user', JSON.stringify(newUser));
  };

  const logout = () => {
    if (supabaseClient) {
      supabaseClient.auth.signOut();
    }
    setUser(null);
    localStorage.removeItem('resq_auth_user');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        supabaseClient,
        loginDemoUser,
        logout,
        isAuthenticated: !!user,
        isAdmin: user?.role === 'admin',
        isModerator: user?.role === 'moderator' || user?.role === 'admin',
        isProvider: user?.role === 'provider' || user?.role === 'admin',
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
