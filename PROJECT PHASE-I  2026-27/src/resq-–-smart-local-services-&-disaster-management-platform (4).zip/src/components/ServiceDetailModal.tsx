import React, { useState, useEffect } from 'react';
import {
  X,
  Star,
  MapPin,
  Phone,
  Globe,
  Navigation,
  Clock,
  Bookmark,
  Calendar,
  MessageSquare,
  AlertTriangle,
  CheckCircle2,
  Building2,
  ShieldCheck,
} from 'lucide-react';
import { ServiceProvider, ServiceReview } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

interface ServiceDetailModalProps {
  provider: ServiceProvider;
  onClose: () => void;
  onRefreshData?: () => void;
  onOpenSos?: (service: ServiceProvider) => void;
}

export const ServiceDetailModal: React.FC<ServiceDetailModalProps> = ({
  provider,
  onClose,
  onRefreshData,
  onOpenSos,
}) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'info' | 'book' | 'review' | 'report'>('info');
  const [reviews, setReviews] = useState<ServiceReview[]>([]);
  const [isFavorite, setIsFavorite] = useState(false);

  // Booking Form State
  const [bookingDate, setBookingDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [bookingTime, setBookingTime] = useState('10:00 AM');
  const [contactPhone, setContactPhone] = useState(user?.phone || '+91-98765-43210');
  const [bookingNotes, setBookingNotes] = useState('');
  const [bookingSubmitted, setBookingSubmitted] = useState(false);
  const [bookingError, setBookingError] = useState<string | null>(null);

  // Review Form State
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);

  // Report Form State
  const [reportType, setReportType] = useState('incorrect_listing');
  const [reportTitle, setReportTitle] = useState('Incorrect contact or operating hours');
  const [reportDesc, setReportDesc] = useState('');
  const [reportSubmitted, setReportSubmitted] = useState(false);

  useEffect(() => {
    api.getServiceDetails(provider.id).then((res) => {
      setReviews(res.reviews || []);
    });

    api.getFavorites(user?.id).then((favs) => {
      setIsFavorite(favs.some((f) => f.id === provider.id));
    });
  }, [provider.id, user?.id]);

  const toggleFavorite = async () => {
    if (isFavorite) {
      await api.removeFavorite(provider.id, user?.id);
      setIsFavorite(false);
    } else {
      await api.addFavorite(provider.id, user?.id);
      setIsFavorite(true);
    }
  };

  const handleCreateBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setBookingError(null);
    try {
      await api.createBooking({
        userId: user?.id,
        providerId: provider.id,
        providerName: provider.businessName,
        categoryName: provider.primaryCategoryId,
        serviceTitle: `Appointment / Service Request with ${provider.businessName}`,
        bookingDate,
        bookingTime,
        contactPhone,
        notes: bookingNotes,
      });
      setBookingSubmitted(true);
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      setBookingError(err.message || 'Failed to place booking');
    }
  };

  const handleCreateReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setReviewError(null);
    try {
      const newRev = await api.createReview({
        userId: user?.id,
        userName: user?.fullName || 'Verified Patient / Customer',
        providerId: provider.id,
        rating: reviewRating,
        comment: reviewComment,
      });
      setReviews([newRev, ...reviews]);
      setReviewSubmitted(true);
      setReviewComment('');
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      setReviewError(err.message || 'Failed to submit review');
    }
  };

  const handleCreateReport = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.submitReport({
        userId: user?.id,
        userName: user?.fullName,
        reportType,
        targetProviderId: provider.id,
        title: reportTitle,
        description: reportDesc || 'Reported discrepancy in provider location or details.',
        locationName: provider.address,
        urgency: 'medium',
      });
      setReportSubmitted(true);
    } catch (err) {
      console.error(err);
    }
  };

  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    `${provider.businessName} ${provider.address}`
  )}`;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden my-8">
        {/* Modal Top Header */}
        <div className="p-6 bg-slate-900 text-white relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">
              {provider.primaryCategoryId.replace('-', ' ')}
            </span>
            {provider.isVerified && (
              <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-800">
                <ShieldCheck className="w-3 h-3" />
                <span>Verified Provider</span>
              </span>
            )}
            {provider.isOpenNow && (
              <span className="text-[11px] text-slate-300 bg-slate-800 px-2 py-0.5 rounded-md">
                Open 24/7
              </span>
            )}
          </div>

          <h2 className="text-xl sm:text-2xl font-bold">{provider.businessName}</h2>

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300 mt-2">
            <span className="flex items-center gap-1 text-white font-semibold">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              <span>{provider.googleRating?.toFixed(1) ?? 'No Google rating'}</span>
              <span className="text-slate-400 font-normal">
                ({provider.googleReviewCount?.toLocaleString() ?? 0} Google reviews)
              </span>
            </span>
            <span>·</span>
            <span className="text-emerald-400 font-medium">
              ResQ Platform: {provider.platformRating ?? 0}★ ({provider.platformReviewCount} reviews)
            </span>
            <span>·</span>
            <span className="font-mono tabular-nums text-slate-300">
              {provider.distanceKm} km away
            </span>
          </div>

          {/* Quick Buttons row */}
          <div className="mt-5 flex flex-wrap items-center gap-2.5">
            {onOpenSos && (
              <button
                type="button"
                onClick={() => onOpenSos(provider)}
                className="px-3 py-1.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
                title={`Dispatch Emergency SOS for ${provider.businessName} (Includes facility contacts & shortest driving route)`}
              >
                <AlertTriangle className="w-3.5 h-3.5 text-white animate-pulse" />
                <span>🚨 Emergency SOS</span>
              </button>
            )}

            <a
              href={`tel:${provider.phone}`}
              className="px-3 py-1.5 text-xs font-semibold text-slate-900 bg-white hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-red-600" />
              <span>Call Provider</span>
            </a>

            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5 border border-slate-700"
            >
              <Navigation className="w-3.5 h-3.5 text-blue-400" />
              <span>Get Directions</span>
            </a>

            <button
              type="button"
              onClick={toggleFavorite}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                isFavorite
                  ? 'bg-amber-400 text-slate-900'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>{isFavorite ? 'Saved' : 'Save to Favorites'}</span>
            </button>
          </div>
        </div>

        {/* Modal Tab Controls */}
        <div className="flex border-b border-slate-200 px-6 bg-slate-50 text-xs font-medium">
          <button
            type="button"
            onClick={() => setActiveTab('info')}
            className={`py-3 px-4 border-b-2 font-semibold transition-colors ${
              activeTab === 'info'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Overview &amp; Reviews
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('book')}
            className={`py-3 px-4 border-b-2 font-semibold transition-colors ${
              activeTab === 'book'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Book / Request Service
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('review')}
            className={`py-3 px-4 border-b-2 font-semibold transition-colors ${
              activeTab === 'review'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Submit Review
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('report')}
            className={`py-3 px-4 border-b-2 font-semibold transition-colors ${
              activeTab === 'report'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Report Listing
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 max-h-[460px] overflow-y-auto">
          {/* 1. INFO TAB */}
          {activeTab === 'info' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  About Provider
                </h4>
                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {provider.description}
                </p>
              </div>

              {provider.servicesOffered && provider.servicesOffered.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Key Offerings &amp; Facilities
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {provider.servicesOffered.map((s) => (
                      <span
                        key={s}
                        className="px-2.5 py-1 text-xs bg-slate-100 rounded-md text-slate-700 font-medium"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-400 block mb-0.5">Physical Address:</span>
                  <p className="font-semibold text-slate-800">{provider.address}</p>
                  <p className="text-slate-500">
                    {provider.locality}, {provider.city}, {provider.state} - {provider.postalCode}
                  </p>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Direct Helplines:</span>
                  <p className="font-semibold text-slate-800">{provider.phone}</p>
                  {provider.alternatePhone && (
                    <p className="text-slate-600">Alt: {provider.alternatePhone}</p>
                  )}
                  {provider.website && (
                    <a
                      href={provider.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline block mt-1"
                    >
                      Visit Official Portal
                    </a>
                  )}
                </div>
              </div>

              {/* Verified Citizen Reviews on ResQ Platform */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                  ResQ Platform Reviews ({reviews.length})
                </h4>
                {reviews.length > 0 ? (
                  <div className="space-y-3">
                    {reviews.map((rev) => (
                      <div
                        key={rev.id}
                        className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs text-slate-900">{rev.userName}</span>
                            {rev.isVerifiedVisit && (
                              <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-sm font-medium">
                                Verified Visit
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-0.5 text-xs text-amber-500 font-bold">
                            <Star className="w-3 h-3 fill-amber-400" />
                            <span>{rev.rating}</span>
                          </div>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">{rev.comment}</p>
                        <span className="text-[10px] text-slate-400 font-mono block">
                          {new Date(rev.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 text-center rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500">
                    No ResQ citizen reviews yet. Be the first to share your experience using the "Submit Review" tab.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 2. BOOK / REQUEST TAB */}
          {activeTab === 'book' && (
            <div>
              {bookingSubmitted ? (
                <div className="p-6 text-center bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
                  <h4 className="text-base font-bold">Booking Request Sent</h4>
                  <p className="text-xs mt-1 text-emerald-700">
                    Your request has been placed with status <strong>Pending</strong>. The provider will verify slot capacity and call your contact number ({contactPhone}).
                  </p>
                  <button
                    type="button"
                    onClick={() => setBookingSubmitted(false)}
                    className="mt-4 px-4 py-2 text-xs font-semibold bg-emerald-700 text-white rounded-lg hover:bg-emerald-800"
                  >
                    Place Another Request
                  </button>
                </div>
              ) : (
                <form onSubmit={handleCreateBooking} className="space-y-4">
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-900 leading-relaxed">
                    <strong>Real Booking Policy:</strong> ResQ stores and forwards this request directly to {provider.businessName}. Bookings remain pending until confirmed by the provider.
                  </div>

                  {bookingError && (
                    <div className="p-2.5 bg-red-50 text-red-800 rounded-lg text-xs">{bookingError}</div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Preferred Date:
                      </label>
                      <input
                        type="date"
                        value={bookingDate}
                        onChange={(e) => setBookingDate(e.target.value)}
                        required
                        className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Preferred Time Slot:
                      </label>
                      <select
                        value={bookingTime}
                        onChange={(e) => setBookingTime(e.target.value)}
                        className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                      >
                        <option>09:00 AM - 11:00 AM</option>
                        <option>11:00 AM - 01:00 PM</option>
                        <option>02:00 PM - 04:00 PM</option>
                        <option>04:00 PM - 07:00 PM</option>
                        <option>Immediate Emergency Assistance</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Contact Phone (for confirmation SMS / call):
                    </label>
                    <input
                      type="tel"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      required
                      placeholder="+91-9876543210"
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Service Requirements / Symptoms / Notes:
                    </label>
                    <textarea
                      rows={3}
                      value={bookingNotes}
                      onChange={(e) => setBookingNotes(e.target.value)}
                      placeholder="e.g. Inquiring about trauma bed availability or vehicle breakdown location..."
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors shadow-sm"
                  >
                    Confirm &amp; Place Request
                  </button>
                </form>
              )}
            </div>
          )}

          {/* 3. REVIEW TAB */}
          {activeTab === 'review' && (
            <div>
              {reviewSubmitted ? (
                <div className="p-6 text-center bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900">
                  <CheckCircle2 className="w-10 h-10 text-emerald-600 mx-auto mb-2" />
                  <h4 className="text-base font-bold">Review Published</h4>
                  <p className="text-xs mt-1 text-emerald-700">
                    Thank you. Your feedback has been recorded in the ResQ database.
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('info')}
                    className="mt-4 px-4 py-2 text-xs font-semibold bg-emerald-700 text-white rounded-lg hover:bg-emerald-800"
                  >
                    View Updated Reviews
                  </button>
                </div>
              ) : (
                <form onSubmit={handleCreateReview} className="space-y-4">
                  {reviewError && (
                    <div className="p-2.5 bg-red-50 text-red-800 rounded-lg text-xs">{reviewError}</div>
                  )}

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Your Rating:
                    </label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setReviewRating(star)}
                          className="p-1 text-amber-400 hover:scale-110 transition-transform"
                        >
                          <Star
                            className={`w-6 h-6 ${
                              star <= reviewRating ? 'fill-amber-400 text-amber-500' : 'text-slate-300'
                            }`}
                          />
                        </button>
                      ))}
                      <span className="text-xs font-bold text-slate-800 ml-2">{reviewRating} out of 5</span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Review Comments:
                    </label>
                    <textarea
                      rows={4}
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      required
                      placeholder="Share details on response time, professionalism, clean facilities, or cost fairness..."
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors shadow-sm"
                  >
                    Publish Verified Review
                  </button>
                </form>
              )}
            </div>
          )}

          {/* 4. REPORT TAB */}
          {activeTab === 'report' && (
            <div>
              {reportSubmitted ? (
                <div className="p-6 text-center bg-amber-50 rounded-2xl border border-amber-200 text-amber-900">
                  <CheckCircle2 className="w-10 h-10 text-amber-600 mx-auto mb-2" />
                  <h4 className="text-base font-bold">Report Forwarded to Moderators</h4>
                  <p className="text-xs mt-1 text-amber-700">
                    Our verification team will audit this provider address and contact coordinates.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleCreateReport} className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Issue Type:</label>
                    <select
                      value={reportType}
                      onChange={(e) => setReportType(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                    >
                      <option value="incorrect_listing">Incorrect address, phone or closed permanently</option>
                      <option value="road_block">Access road blocked by disaster/construction</option>
                      <option value="shortage">Extreme shortage of emergency supplies</option>
                      <option value="other">Other listing discrepancy</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Report Summary:</label>
                    <input
                      type="text"
                      value={reportTitle}
                      onChange={(e) => setReportTitle(e.target.value)}
                      required
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Details:</label>
                    <textarea
                      rows={3}
                      value={reportDesc}
                      onChange={(e) => setReportDesc(e.target.value)}
                      placeholder="Please specify what needs correction so our team can fix it..."
                      className="w-full px-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl transition-colors"
                  >
                    Submit Report to Moderators
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
