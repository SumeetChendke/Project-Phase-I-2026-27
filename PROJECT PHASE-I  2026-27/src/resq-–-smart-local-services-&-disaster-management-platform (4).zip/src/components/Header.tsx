import React, { useState, useEffect } from 'react';
import {
  MapPin,
  Search,
  PhoneCall,
  User,
  ShieldAlert,
  Sparkles,
  Bookmark,
  ChevronDown,
  LogOut,
  Sliders,
  CheckCircle2,
  LocateFixed,
} from 'lucide-react';
import { useLocation, PRESET_LOCATIONS } from '../context/LocationContext';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { UserLocation } from '../types';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenAiAssistant: () => void;
  onOpenAdmin: () => void;
  onOpenUserAccount: (tab?: string) => void;
  onOpenEmergencySos: () => void;
  onSelectCategory: (categoryId: string) => void;
  onOpenMap: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenAiAssistant,
  onOpenAdmin,
  onOpenUserAccount,
  onOpenEmergencySos,
  onSelectCategory,
  onOpenMap,
}) => {
  const {
    location,
    setLocation,
    detectGpsLocation,
    isDetecting,
    gpsError,
    isLiveGps,
    gpsAccuracyMeters,
    lastUpdated,
    isLiveTracking,
    toggleLiveTracking,
  } = useLocation();
  const { user, logout, loginDemoUser, isAdmin } = useAuth();
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Main Top Bar Contract: 3 zones separated by gap-8 */}
          <div className="flex items-center justify-between gap-8 h-16">
            {/* Zone 1: Single element Brand wordmark */}
            <div className="flex items-center gap-3 shrink-0">
              <a
                href="/"
                className="text-xl font-bold tracking-tight text-slate-900 flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center text-white shadow-sm font-black text-sm">
                  R
                </div>
                <span>ResQ</span>
              </a>

              {/* Location Selector Button */}
              <button
                type="button"
                onClick={() => setShowLocationModal(true)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors max-w-[220px] sm:max-w-xs truncate ${
                  isLiveGps
                    ? 'text-emerald-950 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200'
                    : 'text-slate-700 bg-slate-100 hover:bg-slate-200'
                }`}
                title="Change location"
              >
                <MapPin
                  className={`w-3.5 h-3.5 shrink-0 ${
                    isLiveGps ? 'text-emerald-600 animate-pulse' : 'text-red-600'
                  }`}
                />
                <span className="truncate">{location.name}</span>
                {isLiveGps && (
                  <span className="text-[10px] font-semibold text-emerald-700 hidden sm:inline">
                    Live
                  </span>
                )}
                <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
              </button>

              {/* Quick 1-Click Live GPS Detect Button */}
              <button
                type="button"
                onClick={async () => {
                  await detectGpsLocation();
                }}
                disabled={isDetecting}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold rounded-md transition-all shadow-2xs shrink-0 cursor-pointer ${
                  isLiveGps
                    ? 'text-emerald-800 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300'
                    : 'text-white bg-red-600 hover:bg-red-700 animate-pulse'
                }`}
                title={isLiveGps ? 'Live GPS Active - Click to re-center' : 'Click to detect your live location now'}
              >
                <LocateFixed className={`w-3.5 h-3.5 ${isDetecting ? 'animate-spin' : ''}`} />
                <span className="hidden sm:inline">
                  {isDetecting ? 'Detecting...' : isLiveGps ? 'Live GPS Active' : '🎯 Live Location'}
                </span>
              </button>
            </div>

            {/* Zone 2: Concise single-line navigation links */}
            <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
              <a href="#services" className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0">
                All Services
              </a>
              <a href="#hospitals" className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0">
                Popular Hospitals
              </a>
              <a href="#disasters" className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0">
                Disaster Centre
              </a>
              <a href="#alerts" className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0">
                Official Alerts
              </a>
              <a
                href="#map-section"
                className="hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1 text-blue-600 font-semibold"
              >
                <span>Live Google Map</span>
              </a>
            </nav>

            {/* Zone 3: Primary action cluster */}
            <div className="flex items-center gap-3 shrink-0">
              {/* Universal Search trigger */}
              <button
                type="button"
                onClick={onOpenSearch}
                className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                title="Search services"
              >
                <Search className="w-4 h-4" />
              </button>

              {/* AI Assistant Button */}
              <button
                type="button"
                onClick={onOpenAiAssistant}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
                title="Ask Gemini Assistant"
              >
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>AI Assist</span>
              </button>

              {/* Emergency SOS Button */}
              <button
                type="button"
                onClick={onOpenEmergencySos}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-black text-white bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0 animate-pulse"
                title="Emergency SOS: Immediate call to +91 9373783496 & forward live location to sumeetchendke@gmail.com"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>🚨 SOS (9373783496)</span>
              </button>

              {/* Profile / Menu dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowProfileMenu(!showProfileMenu)}
                  className="flex items-center gap-1.5 p-1.5 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-xs font-semibold text-slate-700">
                    {user?.fullName?.charAt(0) || 'U'}
                  </div>
                </button>

                {showProfileMenu && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-lg border border-slate-200 py-2 z-50">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs font-medium text-slate-500">Signed in as</p>
                      <p className="text-sm font-semibold text-slate-900 truncate">{user?.fullName}</p>
                      <span className="inline-block mt-0.5 text-[11px] text-slate-500 font-mono">
                        Role: {user?.role.toUpperCase()}
                      </span>
                    </div>

                    <div className="py-1">
                      <button
                        type="button"
                        onClick={() => {
                          setShowProfileMenu(false);
                          onOpenUserAccount('favorites');
                        }}
                        className="w-full px-4 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                      >
                        <Bookmark className="w-3.5 h-3.5 text-slate-500" />
                        <span>Saved Services</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowProfileMenu(false);
                          onOpenUserAccount('bookings');
                        }}
                        className="w-full px-4 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5 text-slate-500" />
                        <span>My Bookings</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setShowProfileMenu(false);
                          onOpenUserAccount('plan');
                        }}
                        className="w-full px-4 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2.5"
                      >
                        <ShieldAlert className="w-3.5 h-3.5 text-slate-500" />
                        <span>Preparedness Plan</span>
                      </button>

                      {isAdmin && (
                        <button
                          type="button"
                          onClick={() => {
                            setShowProfileMenu(false);
                            onOpenAdmin();
                          }}
                          className="w-full px-4 py-2 text-left text-xs font-semibold text-indigo-700 hover:bg-indigo-50 flex items-center gap-2.5"
                        >
                          <Sliders className="w-3.5 h-3.5 text-indigo-600" />
                          <span>Admin Dashboard</span>
                        </button>
                      )}
                    </div>

                    <div className="border-t border-slate-100 pt-1 px-4 py-2">
                      <p className="text-[11px] font-medium text-slate-400 mb-1.5">Switch Demo Role:</p>
                      <div className="grid grid-cols-2 gap-1 text-[11px]">
                        <button
                          type="button"
                          onClick={() => loginDemoUser('user')}
                          className="px-2 py-1 text-left rounded hover:bg-slate-100 text-slate-600"
                        >
                          Citizen
                        </button>
                        <button
                          type="button"
                          onClick={() => loginDemoUser('provider')}
                          className="px-2 py-1 text-left rounded hover:bg-slate-100 text-slate-600"
                        >
                          Provider
                        </button>
                        <button
                          type="button"
                          onClick={() => loginDemoUser('moderator')}
                          className="px-2 py-1 text-left rounded hover:bg-slate-100 text-slate-600"
                        >
                          Moderator
                        </button>
                        <button
                          type="button"
                          onClick={() => loginDemoUser('admin')}
                          className="px-2 py-1 text-left rounded hover:bg-slate-100 font-semibold text-indigo-600"
                        >
                          Admin
                        </button>
                      </div>
                    </div>

                    <div className="border-t border-slate-100 pt-1">
                      <button
                        type="button"
                        onClick={() => {
                          setShowProfileMenu(false);
                          logout();
                        }}
                        className="w-full px-4 py-2 text-left text-xs text-red-600 hover:bg-red-50 flex items-center gap-2.5"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Location Modal */}
      {showLocationModal && (
        <LocationModal
          onClose={() => setShowLocationModal(false)}
          currentLocation={location}
          onSelect={(loc) => {
            setLocation(loc);
            setShowLocationModal(false);
          }}
          onDetectGps={async () => {
            await detectGpsLocation();
            setShowLocationModal(false);
          }}
          isDetecting={isDetecting}
          gpsError={gpsError}
          isLiveGps={isLiveGps}
          accuracyMeters={gpsAccuracyMeters}
          lastUpdated={lastUpdated}
          isLiveTracking={isLiveTracking}
          onToggleLiveTracking={toggleLiveTracking}
        />
      )}
    </>
  );
};

interface LocationModalProps {
  onClose: () => void;
  currentLocation: UserLocation;
  onSelect: (loc: UserLocation) => void;
  onDetectGps: () => Promise<void>;
  isDetecting: boolean;
  gpsError: string | null;
  isLiveGps?: boolean;
  accuracyMeters?: number | null;
  lastUpdated?: string | null;
  isLiveTracking?: boolean;
  onToggleLiveTracking?: () => void;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  onClose,
  currentLocation,
  onSelect,
  onDetectGps,
  isDetecting,
  gpsError,
  isLiveGps,
  accuracyMeters,
  lastUpdated,
  isLiveTracking,
  onToggleLiveTracking,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [liveSearchResults, setLiveSearchResults] = useState<any[]>([]);
  const [isSearchingLive, setIsSearchingLive] = useState(false);

  // Debounced live location search using Nominatim
  useEffect(() => {
    if (!searchQuery.trim() || searchQuery.length < 2) {
      setLiveSearchResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearchingLive(true);
      try {
        const results = await api.searchLocations(searchQuery);
        setLiveSearchResults(results);
      } catch (err) {
        console.error(err);
      } finally {
        setIsSearchingLive(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const filteredPresets = PRESET_LOCATIONS.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.state.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-lg w-full p-6 border border-slate-200">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div>
            <h3 className="text-base font-semibold text-slate-900">Choose Your Location</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Accurate nearby hospitals, garages, and disaster alerts depend on your location.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
          >
            ✕
          </button>
        </div>

        {/* GPS Button & Live Status */}
        <div className="my-4 space-y-2">
          <button
            type="button"
            onClick={onDetectGps}
            disabled={isDetecting}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors disabled:opacity-60 shadow-xs"
          >
            <MapPin className={`w-4 h-4 ${isDetecting ? 'animate-bounce text-amber-400' : 'text-red-400'}`} />
            <span>{isDetecting ? 'Detecting Live Coordinates...' : 'Detect Live GPS Location Now'}</span>
          </button>

          {isLiveGps && (
            <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping" />
                <span className="font-semibold">Live GPS Active</span>
                {accuracyMeters && (
                  <span className="text-[11px] font-mono text-emerald-700">
                    (±{accuracyMeters}m accuracy)
                  </span>
                )}
              </div>
              {lastUpdated && (
                <span className="text-[10px] text-emerald-700 font-mono">
                  Updated: {lastUpdated}
                </span>
              )}
            </div>
          )}

          {gpsError && (
            <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-800 leading-relaxed">
              {gpsError}
            </div>
          )}
        </div>

        {/* Manual Search */}
        <div className="relative mb-3">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search village, town, city, district or PIN code..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-400"
          />
        </div>

        {/* Dynamic Search Results vs Preset Cities List */}
        <div>
          {searchQuery.trim().length >= 2 ? (
            <div>
              <p className="text-xs font-medium text-slate-500 mb-1.5 flex items-center justify-between">
                <span>Matching Live Locations</span>
                {isSearchingLive && <span className="text-[10px] text-blue-600">Searching...</span>}
              </p>
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {liveSearchResults.length > 0 ? (
                  liveSearchResults.map((res, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => onSelect(res)}
                      className="w-full text-left p-2.5 rounded-lg border border-slate-100 hover:border-slate-200 hover:bg-slate-50 text-xs transition-colors"
                    >
                      <span className="font-bold text-slate-900 block truncate">{res.name}</span>
                      <span className="text-[11px] text-slate-500">
                        {res.city}, {res.state} {res.country}
                      </span>
                    </button>
                  ))
                ) : !isSearchingLive ? (
                  <div className="p-4 text-center text-xs text-slate-400">
                    No matching location found. Try adding city or state name.
                  </div>
                ) : null}
              </div>
            </div>
          ) : (
            <div>
              <p className="text-xs font-medium text-slate-500 mb-2">Preset Cities &amp; Regions</p>
              <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                {filteredPresets.map((loc) => {
                  const isSelected = loc.name === currentLocation.name;
                  return (
                    <button
                      key={loc.name}
                      type="button"
                      onClick={() => onSelect(loc)}
                      className={`w-full text-left px-3 py-2 text-xs rounded-lg transition-colors flex items-center justify-between ${
                        isSelected
                          ? 'bg-red-50 text-red-900 font-semibold border border-red-200'
                          : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div>
                        <span className="block font-medium">{loc.name}</span>
                        <span className="text-[11px] text-slate-400">
                          {loc.city}, {loc.state}
                        </span>
                      </div>
                      {isSelected && <span className="text-[11px] text-red-600 font-semibold">Active</span>}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <div className="mt-5 pt-3 border-t border-slate-100 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
