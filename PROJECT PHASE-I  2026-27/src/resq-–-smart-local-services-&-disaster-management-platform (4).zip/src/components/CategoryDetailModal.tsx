import React, { useState, useEffect } from 'react';
import {
  X,
  Star,
  MapPin,
  Phone,
  Navigation,
  SlidersHorizontal,
  Map as MapIcon,
  List,
  Building2,
  CalendarPlus,
  ShieldCheck,
} from 'lucide-react';
import { ServiceCategory, ServiceProvider } from '../types';
import { SERVICE_CATEGORIES } from '../data/categoriesData';
import { api } from '../services/api';
import { useLocation } from '../context/LocationContext';
import { MapView } from './MapView';

interface CategoryDetailModalProps {
  categoryId: string;
  onClose: () => void;
  onSelectService: (service: ServiceProvider) => void;
  onBookAppointment: (service: ServiceProvider) => void;
  onOpenSos?: (service: ServiceProvider, categoryName?: string) => void;
}

export const CategoryDetailModal: React.FC<CategoryDetailModalProps> = ({
  categoryId,
  onClose,
  onSelectService,
  onBookAppointment,
  onOpenSos,
}) => {
  const { location } = useLocation();
  const category =
    SERVICE_CATEGORIES.find((c) => c.id === categoryId) || {
      id: categoryId,
      name: categoryId.replace('-', ' '),
      group: 'Healthcare',
      icon: 'Building2',
      description: 'Verified local service directory',
      isEmergency: false,
      displayOrder: 0,
    };

  const [services, setServices] = useState<ServiceProvider[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'rating' | 'reviews' | 'distance' | 'balanced'>('balanced');
  const [radiusKm, setRadiusKm] = useState<number>(50);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    api
      .getNearbyServices({
        lat: location.lat,
        lng: location.lng,
        category: categoryId,
        radius: radiusKm,
        sort: sortBy,
      })
      .then((res) => {
        if (isMounted) {
          setServices(res.services);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error(err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [categoryId, location.lat, location.lng, sortBy, radiusKm]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Top Header */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">
                {category.group}
              </span>
              {category.isEmergency && (
                <span className="text-[10px] text-red-400 font-bold bg-red-950 px-2 py-0.5 rounded-md">
                  Emergency Priority
                </span>
              )}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold">{category.name}</h2>
            <p className="text-xs text-slate-400 mt-1">
              {category.description} near <span className="text-slate-200 font-medium">{location.name}</span>
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar: Sort, Radius, and View Mode Toggle */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Sort:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-2.5 py-1 bg-white border border-slate-200 rounded-md focus:outline-none font-medium text-slate-800"
              >
                <option value="balanced">Recommended (Bayesian Balanced)</option>
                <option value="rating">Highest Rated</option>
                <option value="reviews">Most Reviewed</option>
                <option value="distance">Nearest First</option>
              </select>
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-medium">Radius:</span>
              <select
                value={radiusKm}
                onChange={(e) => setRadiusKm(parseInt(e.target.value, 10))}
                className="px-2.5 py-1 bg-white border border-slate-200 rounded-md focus:outline-none font-medium text-slate-800"
              >
                <option value={10}>Within 10 km</option>
                <option value={25}>Within 25 km</option>
                <option value={50}>Within 50 km</option>
                <option value={100}>Within 100 km</option>
              </select>
            </div>
          </div>

          {/* List vs Map view toggle */}
          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-white">
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`px-3 py-1 rounded-md font-semibold flex items-center gap-1 transition-colors ${
                viewMode === 'list'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List ({services.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('map')}
              className={`px-3 py-1 rounded-md font-semibold flex items-center gap-1 transition-colors ${
                viewMode === 'map'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5" />
              <span>Map View</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {viewMode === 'map' ? (
            <MapView
              services={services}
              onSelectService={(s) => {
                onClose();
                onSelectService(s);
              }}
              onOpenSos={(s) => {
                onClose();
                onOpenSos?.(s, category.name);
              }}
              selectedCategory={category.name}
            />
          ) : isLoading ? (
            <div className="py-12 text-center text-xs text-slate-400">Loading nearby {category.name}...</div>
          ) : services.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {services.map((service) => {
                const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                  `${service.businessName} ${service.address}`
                )}`;

                return (
                  <div
                    key={service.id}
                    className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col justify-between hover:border-slate-300 hover:shadow-xs transition-all"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <span className="text-[11px] font-mono font-medium text-slate-500 tabular-nums">
                          {service.distanceKm} km away
                        </span>
                        {service.isOpenNow && (
                          <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-sm font-semibold">
                            Open 24/7
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm font-bold text-slate-900 line-clamp-1">
                        {service.businessName}
                      </h4>

                      <div className="flex items-center gap-2 text-xs text-slate-500 mt-1 mb-2">
                        {typeof service.googleRating === 'number' ? (
                          <span className="flex items-center gap-1 font-semibold text-slate-900">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                            <span>{service.googleRating.toFixed(1)}</span>
                            <span className="text-slate-400 font-normal">
                              ({service.googleReviewCount ?? 0})
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">No rating</span>
                        )}
                        <span>·</span>
                        <span className="truncate">{service.locality}</span>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {service.description}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-1.5 flex-wrap">
                      <div className="flex items-center gap-2">
                        <a
                          href={mapsUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs text-blue-600 hover:underline flex items-center gap-1 font-medium"
                        >
                          <Navigation className="w-3 h-3" />
                          <span>Route</span>
                        </a>

                        <button
                          type="button"
                          onClick={() => {
                            onClose();
                            onBookAppointment(service);
                          }}
                          className="text-xs text-emerald-700 hover:underline flex items-center gap-1 font-medium"
                        >
                          <CalendarPlus className="w-3 h-3" />
                          <span>Book</span>
                        </button>

                        {onOpenSos && (
                          <button
                            type="button"
                            onClick={() => {
                              onClose();
                              onOpenSos(service, category.name);
                            }}
                            className="text-xs font-bold text-red-700 bg-red-50 hover:bg-red-100 px-2 py-0.5 rounded border border-red-200 cursor-pointer"
                            title={`Dispatch Emergency SOS for ${service.businessName}`}
                          >
                            🚨 SOS
                          </button>
                        )}
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onSelectService(service);
                        }}
                        className="px-3 py-1 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                      >
                        View Details
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-12 text-center text-xs text-slate-500 bg-slate-50 rounded-xl border border-slate-200">
              No verified listings found within {radiusKm} km of {location.name}. Try broadening your search radius above.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
