# ResQ – Smart Local Services & Disaster Management Platform

ResQ is an all-in-one unified web application integrating local service discovery, authentic ratings-based recommendations, interactive mapping, 112 emergency assistance, disaster preparedness, early warning alerts, and Gemini 3.8 Flash AI assistance.

---

## 🌟 Key Features

1. **44 Comprehensive Service Categories (7 Functional Groups)**
   - **Healthcare & Medical**: Hospitals, Clinics & Diagnostics, Doctors & Specialists, Pharmacies, Ambulances, Blood Banks, Veterinary Clinics.
   - **Emergency & Public Safety**: Police Stations, Fire Stations, Disaster Response Teams (NDRF/SDRF), Disaster Relief Centres, Emergency Shelters, Crisis Support, Government Disaster Offices.
   - **Vehicles & Transport**: Petrol Pumps, EV Charging Stations, Garages, Mechanics & Puncture Repair, Towing, Bus Depots, Railway Stations, Vehicle Rentals, Battery Jumpstart Assistance.
   - **Daily Essentials**: Supermarkets, Restaurants, Potable Water Suppliers, Fruit/Veg Mandis, Public Toilets, Couriers, Waste & Recycling.
   - **Finance & Public Services**: Banks & ATMs, Citizen Service Centres, Legal Aid, Post Offices, Insurance Offices.
   - **Home & Utilities**: Electricians, Plumbers, Home Maintenance, Internet & Telecom Centers.
   - **Community & Lifestyle**: Lodges & Hotels, Schools & Colleges, Public Assembly Parks, Community Langar Kitchens, Animal Rescue.

2. **Mandatory Popular Hospitals Section**
   - Verified hospital listings with authentic Google Maps ratings and review counts.
   - Bayesian weighted ranking algorithm ensuring high-volume, well-reviewed trauma centers are properly ranked against single-review 5.0 clinics.
   - Preserves "Rating unavailable" without ever fabricating missing ratings.
   - Direct appointment/bed inquiry request workflow, phone calls, and directions links.

3. **Emergency Assistance & 112 Protocol**
   - Prominent 112 Emergency Support action.
   - Displays current user GPS coordinates to communicate to operators.
   - Dedicated direct lines for Ambulance (108), Police (100), Fire (101), and Disaster Relief (1070/1077).
   - Clear transparency on emergency dispatch mechanism (no simulated dispatch).

4. **Disaster Management Centre (16 Disasters)**
   - Floods, Earthquakes, Cyclones, Tsunamis, Landslides, Fires, Heatwaves, Droughts, Lightning Storms, Cloudbursts, Industrial Accidents, Chemical Leaks, Road Accidents, Building Collapse, Dam Failure, Forest Fires.
   - Step-by-step verified action protocols for **Before**, **During**, and **After** events.
   - Interactive survival kit checklist and downloadable preparedness plan.
   - Guaranteed offline availability even when external APIs or AI services are offline.

5. **Official Alerts & Early Warnings**
   - Real-time hazard advisories from IMD, CPCB, and DDMA.
   - Specific affected areas, issuance/expiry timestamps, and mandatory public safety instructions.

6. **Interactive Mapping & Geo-Discovery**
   - High-performance Leaflet mapping with OpenStreetMap tiles.
   - Provider pins colored by emergency priority, radius selection, and directions.
   - Browser Geolocation API with fallback to manual search for village, town, city, or PIN code.

7. **Gemini 3.8 Flash AI Assistant**
   - Server-side integration using official `@google/genai` TypeScript SDK with `aistudio-build` telemetry header.
   - Real tool calling for nearby service lookup, disaster safety guidance, and emergency numbers.
   - No hallucinated ratings, phone numbers, or emergency contacts.

8. **PostgreSQL & Supabase Architecture**
   - Full PostgreSQL migration under `supabase/migrations/20261022000001_initial_schema.sql`.
   - PostGIS/lat-lng indexing, Row Level Security (RLS) policies for user data isolation.
   - Separate storage for third-party ratings vs. citizen reviews.

---

## 🛠 Tech Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide React, Motion.
- **Backend**: Node.js, Express.js (mounted with Vite middlewares in dev mode on port 3000).
- **Database**: PostgreSQL with Supabase, Row Level Security (RLS).
- **AI**: Google Gemini 3.8 Flash via official `@google/genai` TypeScript SDK.
- **Maps**: Leaflet with OpenStreetMap provider, Google Maps Platform directions links.
- **Testing**: Vitest and Supertest.

---

---

## 💻 Running in Visual Studio Code (VS Code)

### Prerequisites
- **Node.js**: Version 18+ or 20+ installed ([nodejs.org](https://nodejs.org/)). Verify with `node -v` and `npm -v`.
- **VS Code**: Visual Studio Code installed ([code.visualstudio.com](https://code.visualstudio.com/)).

### Step-by-Step Execution Guide:

1. **Open the Project in VS Code**:
   - Open VS Code.
   - Click **File** > **Open Folder...** (or press `Ctrl+K Ctrl+O` on Windows/Linux or `Cmd+O` on Mac).
   - Select this project's root folder (the folder containing `package.json` and `server.ts`).

2. **Open the Integrated Terminal**:
   - In VS Code, press **`Ctrl + \``** (backtick) or select **Terminal** > **New Terminal** from the top menu.

3. **Install Dependencies**:
   - In the terminal, run:
     ```bash
     npm install
     ```
   - This downloads all required frontend and backend packages (React, Vite, Express, Tailwind, Twilio, Nodemailer, etc.).

4. **Set Up Your Environment (`.env`)**:
   - In the VS Code file explorer, copy `.env.example` to `.env`:
     ```bash
     cp .env.example .env
     ```
     *(On Windows PowerShell: `Copy-Item .env.example .env`)*
   - Open `.env` and fill in any API keys you wish to use (Google Maps API key, Gemini API key, SMTP credentials, or Twilio keys).

5. **Execute the Application**:
   - In the VS Code terminal, start the development server:
     ```bash
     npm run dev
     ```
   - *Alternatively, press **`F5`** or go to the **Run and Debug** tab in the VS Code sidebar and click **Run ResQ (npm run dev)**.*

6. **Open in Your Browser**:
   - Open your browser and navigate to:
     ```
     http://localhost:3000
     ```
   - Both the React frontend and the Express backend API run together on port 3000.

7. **Run Tests (Optional)**:
   - In a new terminal tab, verify everything works:
     ```bash
     npm test
     ```

---

## 📄 License
Apache-2.0
