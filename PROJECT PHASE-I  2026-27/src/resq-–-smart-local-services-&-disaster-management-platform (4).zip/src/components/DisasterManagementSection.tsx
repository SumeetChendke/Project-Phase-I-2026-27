import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Waves,
  Activity,
  Wind,
  Anchor,
  Mountain,
  Flame,
  Sun,
  CloudOff,
  Zap,
  CloudRain,
  Factory,
  Biohazard,
  Car,
  Building,
  CheckSquare,
  Square,
  PhoneCall,
  Download,
  AlertTriangle,
  FileText,
  LifeBuoy,
} from 'lucide-react';
import { DISASTER_GUIDES } from '../data/disasterGuidesData';
import { DisasterGuide } from '../types';

const DISASTER_ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  Waves,
  Activity,
  Wind,
  Anchor,
  Mountain,
  Flame,
  Sun,
  CloudOff,
  Zap,
  CloudRain,
  Factory,
  Biohazard,
  Car,
  Building,
  ShieldAlert,
};

interface DisasterManagementSectionProps {
  onOpenReliefShelters: () => void;
  onAskAiSafety: (disasterName: string) => void;
}

export const DisasterManagementSection: React.FC<DisasterManagementSectionProps> = ({
  onOpenReliefShelters,
  onAskAiSafety,
}) => {
  const [selectedDisasterId, setSelectedDisasterId] = useState<string>('floods');
  const [activePhase, setActivePhase] = useState<'before' | 'during' | 'after'>('during');
  const [completedItems, setCompletedItems] = useState<Record<string, boolean>>({});

  const currentGuide: DisasterGuide =
    DISASTER_GUIDES.find((d) => d.id === selectedDisasterId) || DISASTER_GUIDES[0];

  const IconComponent = DISASTER_ICON_MAP[currentGuide.icon] || ShieldAlert;

  const toggleChecklistItem = (item: string) => {
    setCompletedItems((prev) => ({
      ...prev,
      [`${selectedDisasterId}_${item}`]: !prev[`${selectedDisasterId}_${item}`],
    }));
  };

  const handleDownloadPlan = () => {
    const planText = `RESQ DISASTER PREPAREDNESS PLAN
Disaster: ${currentGuide.name}
Generated: ${new Date().toLocaleDateString()}

EMERGENCY PROTOCOLS:
BEFORE:
${currentGuide.beforeSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

DURING:
${currentGuide.duringSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

AFTER:
${currentGuide.afterSteps.map((s, i) => `${i + 1}. ${s}`).join('\n')}

EMERGENCY SURVIVAL KIT:
${currentGuide.emergencyKit.map((k) => `[ ] ${k}`).join('\n')}

VERIFIED EMERGENCY HELPLINES:
${currentGuide.vitalContacts.map((c) => `${c.label}: ${c.number}`).join('\n')}
Universal Emergency: 112`;

    const blob = new Blob([planText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ResQ_Preparedness_Plan_${currentGuide.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section id="disasters" className="py-14 bg-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <ShieldAlert className="w-4 h-4 text-red-400" />
              <span className="text-xs font-bold text-red-400 uppercase tracking-wider">
                Disaster Management &amp; Civil Protection
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Preparedness, Response &amp; Recovery
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              16 verified hazard protocols with step-by-step actions for Before, During, and After disaster events. Always offline-accessible.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenReliefShelters}
              className="px-3.5 py-2 text-xs font-semibold text-slate-900 bg-white hover:bg-slate-100 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
            >
              <LifeBuoy className="w-3.5 h-3.5 text-red-600" />
              <span>Nearby Shelters</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadPlan}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Plan</span>
            </button>
          </div>
        </div>

        {/* Disaster Type Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 scrollbar-none">
          {DISASTER_GUIDES.map((guide) => {
            const isSelected = guide.id === selectedDisasterId;
            const GuideIcon = DISASTER_ICON_MAP[guide.icon] || AlertTriangle;
            return (
              <button
                key={guide.id}
                type="button"
                onClick={() => setSelectedDisasterId(guide.id)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'bg-red-600 text-white shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-800'
                }`}
              >
                <GuideIcon className="w-3.5 h-3.5" />
                <span>{guide.name.split('&')[0].trim()}</span>
              </button>
            );
          })}
        </div>

        {/* Active Disaster Guidance Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Action Guidelines (Before, During, After) */}
          <div className="lg:col-span-2 bg-slate-800/80 rounded-2xl border border-slate-800 p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-700/60">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center">
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">{currentGuide.name}</h3>
                    <p className="text-xs text-slate-400 mt-0.5">{currentGuide.summary}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onAskAiSafety(currentGuide.name)}
                  className="px-3 py-1.5 text-xs font-medium text-blue-300 bg-blue-950/60 border border-blue-800 hover:bg-blue-900 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Ask Gemini AI
                </button>
              </div>

              {/* Phase Switcher Tabs */}
              <div className="flex items-center gap-2 mt-6 mb-5">
                <button
                  type="button"
                  onClick={() => setActivePhase('before')}
                  className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
                    activePhase === 'before'
                      ? 'bg-amber-500 text-slate-950 shadow-xs'
                      : 'bg-slate-700/50 text-slate-400 hover:text-white'
                  }`}
                >
                  1. Before (Mitigation)
                </button>
                <button
                  type="button"
                  onClick={() => setActivePhase('during')}
                  className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
                    activePhase === 'during'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'bg-slate-700/50 text-slate-400 hover:text-white'
                  }`}
                >
                  2. During (Immediate Safety)
                </button>
                <button
                  type="button"
                  onClick={() => setActivePhase('after')}
                  className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors ${
                    activePhase === 'after'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-700/50 text-slate-400 hover:text-white'
                  }`}
                >
                  3. After (Recovery)
                </button>
              </div>

              {/* Step Checklist List */}
              <div className="space-y-3">
                {(activePhase === 'before'
                  ? currentGuide.beforeSteps
                  : activePhase === 'during'
                  ? currentGuide.duringSteps
                  : currentGuide.afterSteps
                ).map((step, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-700/50 flex items-start gap-3 text-xs leading-relaxed text-slate-200"
                  >
                    <span className="font-mono font-bold text-slate-400 w-5 shrink-0 tabular-nums">
                      {idx + 1}.
                    </span>
                    <p className="flex-1">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Offline availability guarantee badge */}
            <div className="mt-6 pt-4 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-slate-400">
              <span>Verified under National Disaster Management Authority (NDMA) guidelines.</span>
              <span className="text-emerald-400 font-medium">Offline Cached</span>
            </div>
          </div>

          {/* Emergency Kit & Vital Helplines */}
          <div className="space-y-6">
            {/* Interactive Emergency Kit Checklist */}
            <div className="bg-slate-800/80 rounded-2xl border border-slate-800 p-5">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Required Emergency Kit
                </h4>
                <span className="text-[11px] text-slate-400">Survival Check</span>
              </div>

              <div className="space-y-2">
                {currentGuide.emergencyKit.map((item) => {
                  const isChecked = !!completedItems[`${selectedDisasterId}_${item}`];
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleChecklistItem(item)}
                      className="w-full p-2.5 rounded-lg bg-slate-900/60 border border-slate-700/40 text-left flex items-center gap-2.5 hover:bg-slate-900 transition-colors"
                    >
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-500 shrink-0" />
                      )}
                      <span
                        className={`text-xs ${
                          isChecked ? 'line-through text-slate-500' : 'text-slate-300'
                        }`}
                      >
                        {item}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Verified Emergency Helplines for this disaster */}
            <div className="bg-slate-800/80 rounded-2xl border border-slate-800 p-5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3">
                Vital Response Helplines
              </h4>

              <div className="space-y-2">
                {currentGuide.vitalContacts.map((contact) => (
                  <div
                    key={contact.number}
                    className="p-3 rounded-lg bg-slate-900/60 border border-slate-700/40 flex items-center justify-between text-xs"
                  >
                    <div>
                      <span className="block font-medium text-slate-200">{contact.label}</span>
                      <span className="text-[11px] font-mono text-red-400 font-bold tabular-nums">
                        {contact.number}
                      </span>
                    </div>
                    <a
                      href={`tel:${contact.number}`}
                      className="p-2 rounded-lg bg-red-600/30 text-red-300 hover:bg-red-600 hover:text-white transition-colors"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}

                <div className="p-3 rounded-lg bg-red-950/60 border border-red-800/60 flex items-center justify-between text-xs">
                  <div>
                    <span className="block font-bold text-white">Universal Emergency (ERSS)</span>
                    <span className="text-[11px] font-mono text-red-300 font-black">112</span>
                  </div>
                  <a
                    href="tel:112"
                    className="px-3 py-1.5 rounded-lg bg-red-600 text-white font-bold hover:bg-red-700 transition-colors"
                  >
                    Call 112
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
