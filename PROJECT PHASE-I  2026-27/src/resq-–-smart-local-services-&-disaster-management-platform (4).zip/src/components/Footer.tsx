import React from 'react';
import { PhoneCall, ShieldCheck, Heart } from 'lucide-react';

interface FooterProps {
  onOpenSos: () => void;
  onSelectCategory: (categoryId: string) => void;
  onOpenShelters: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenSos,
  onSelectCategory,
  onOpenShelters,
}) => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs py-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
          {/* Brand Col */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-red-600 flex items-center justify-center text-white font-black text-xs">
                R
              </div>
              <span className="text-base font-bold text-white tracking-tight">ResQ</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              All-in-One Smart Local Services and Disaster Management Platform. Providing real nearby service discovery, verified ratings, 112 emergency response, and civil protection.
            </p>
            <div className="pt-1">
              <button
                type="button"
                onClick={onOpenSos}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700 transition-colors"
                title="Immediate call to +91 9373783496 & live location email to sumeetchendke@gmail.com"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>🚨 Emergency SOS (+91 9373783496)</span>
              </button>
            </div>
          </div>

          {/* Emergency & Safety Links */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-white block mb-3">
              Emergency &amp; Rescue
            </span>
            <ul className="space-y-2">
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('hospitals')}
                  className="hover:text-white transition-colors"
                >
                  Nearby Hospitals &amp; Trauma ICU
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('ambulances')}
                  className="hover:text-white transition-colors"
                >
                  Ambulance Emergency (108 / 102)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('police-stations')}
                  className="hover:text-white transition-colors"
                >
                  Police Stations (100)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('fire-stations')}
                  className="hover:text-white transition-colors"
                >
                  Fire Brigade (101)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={onOpenShelters}
                  className="hover:text-white transition-colors"
                >
                  Disaster Relief Shelters
                </button>
              </li>
            </ul>
          </div>

          {/* Vehicle & Essentials */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-white block mb-3">
              Vehicle &amp; Essentials
            </span>
            <ul className="space-y-2">
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('garages')}
                  className="hover:text-white transition-colors"
                >
                  Car &amp; Bike Garages
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('towing')}
                  className="hover:text-white transition-colors"
                >
                  Roadside Towing Assistance
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('petrol-pumps')}
                  className="hover:text-white transition-colors"
                >
                  24/7 Petrol &amp; Fuel Stations
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('pharmacies')}
                  className="hover:text-white transition-colors"
                >
                  Night Pharmacies &amp; Medicine
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onSelectCategory('water-suppliers')}
                  className="hover:text-white transition-colors"
                >
                  Drinking Water Supply Hubs
                </button>
              </li>
            </ul>
          </div>

          {/* Official Disclaimers */}
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-white block mb-3">
              Integrity &amp; Standards
            </span>
            <div className="space-y-2 text-slate-400">
              <p>
                Ratings and reviews reflect authentic provider records. ResQ does not manufacture missing review counts or simulate live emergency dispatch.
              </p>
              <div className="flex items-center gap-1.5 text-slate-300 font-medium pt-1">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Compliant with NDMA safety protocols</span>
              </div>
            </div>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500">
          <p>&copy; {new Date().getFullYear()} ResQ Platform. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <a href="#services" className="hover:text-slate-300">All 44 Services</a>
            <a href="#hospitals" className="hover:text-slate-300">Popular Hospitals</a>
            <a href="#disasters" className="hover:text-slate-300">Disaster Centre</a>
            <a href="#alerts" className="hover:text-slate-300">Official Alerts</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
