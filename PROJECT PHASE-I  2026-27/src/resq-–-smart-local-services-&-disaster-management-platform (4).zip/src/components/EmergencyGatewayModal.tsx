import React, { useState, useEffect } from 'react';
import {
  X,
  Mail,
  PhoneCall,
  Server,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Info,
  ExternalLink,
  Save,
  Activity,
  Zap,
} from 'lucide-react';
import { api } from '../services/api';

interface EmergencyGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved?: () => void;
}

export const EmergencyGatewayModal: React.FC<EmergencyGatewayModalProps> = ({
  isOpen,
  onClose,
  onSaved,
}) => {
  const [activeTab, setActiveTab] = useState<'gmail' | 'telephony' | 'fast2sms'>('gmail');
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [status, setStatus] = useState<any>(null);
  const [saveSuccess, setSaveSuccess] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<any>(null);

  // Form fields
  const [smtpHost, setSmtpHost] = useState('smtp.gmail.com');
  const [smtpPort, setSmtpPort] = useState(587);
  const [smtpUser, setSmtpUser] = useState('sumeetchendke@gmail.com');
  const [smtpPass, setSmtpPass] = useState('');

  const [twilioSid, setTwilioSid] = useState('ACd22962bfc4b94a331d37881d349147fd');
  const [twilioAuth, setTwilioAuth] = useState('');
  const [twilioFrom, setTwilioFrom] = useState('+17407444164');

  const [fast2smsApiKey, setFast2smsApiKey] = useState('');

  useEffect(() => {
    if (isOpen) {
      loadStatus();
    }
  }, [isOpen]);

  const loadStatus = async () => {
    setLoading(true);
    try {
      const data = await api.getSosGatewayStatus();
      setStatus(data);
    } catch (_err) {
      // Ignore
    } finally {
      setLoading(false);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSaveSuccess(null);
    try {
      const res = await api.saveSosGatewayConfig({
        smtpHost: smtpHost || 'smtp.gmail.com',
        smtpPort: Number(smtpPort) || 587,
        smtpUser: smtpUser.trim(),
        smtpPass: smtpPass.trim(),
        twilioSid: twilioSid.trim(),
        twilioAuth: twilioAuth.trim(),
        twilioFrom: twilioFrom.trim(),
        fast2smsApiKey: fast2smsApiKey.trim(),
      });
      setStatus(res.status);
      setSaveSuccess('Gateway credentials successfully saved and activated in ResQ server!');
      if (onSaved) onSaved();
    } catch (err: any) {
      alert(`Failed to save: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleTestConnection = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const result = await api.testSosGateway();
      setTestResult(result);
      await loadStatus();
    } catch (err: any) {
      setTestResult({
        emailResult: { success: false, message: err.message },
        telephonyResult: { success: false, message: 'Test failed to execute' },
      });
    } finally {
      setTesting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 sm:p-6 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300 shrink-0">
              <Server className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-black tracking-tight">
                  Emergency Dispatch Gateway Setup
                </h3>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Zero Client Apps
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                Target Mobile: <span className="text-white font-bold">+91 9373783496</span> • Email: <span className="text-white font-bold">sumeetchendke@gmail.com</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Why were credentials needed notice */}
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs space-y-2">
            <div className="flex items-center gap-2 text-amber-900 font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Why wasn't an email or call received yet?</span>
            </div>
            <p className="text-amber-800 leading-relaxed text-[11px]">
              Browsers and cloud servers do not possess a cellular SIM card or permission to access your private inbox. To make your Indian mobile (<strong className="text-slate-900">+91 9373783496</strong>) ring and deliver emails directly to <strong className="text-slate-900">sumeetchendke@gmail.com</strong> without opening any desktop email or phone app, the cloud server connects to an authenticated gateway.
            </p>
          </div>

          {/* Current Live Status Overview */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className={`p-3.5 rounded-2xl border ${status?.email?.configured ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950' : 'bg-slate-50 border-slate-200 text-slate-700'}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold flex items-center gap-1.5">
                  <Mail className="w-4 h-4 text-indigo-600" />
                  Email Gateway (Gmail)
                </span>
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${status?.email?.configured ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                  {status?.email?.configured ? '🟢 READY' : '🟡 NEEDS SETUP'}
                </span>
              </div>
              <p className="text-[11px] opacity-80 leading-snug">
                {status?.email?.configured
                  ? `Active via ${status.email.provider} (${status.email.user || 'Configured'})`
                  : 'Enter 16-letter Gmail App Password to enable live inbox delivery.'}
              </p>
            </div>

            <div className={`p-3.5 rounded-2xl border ${status?.telephony?.configured ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950' : 'bg-slate-50 border-slate-200 text-slate-700'}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold flex items-center gap-1.5">
                  <PhoneCall className="w-4 h-4 text-emerald-600" />
                  Mobile Ring &amp; SMS
                </span>
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${status?.telephony?.configured ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                  {status?.telephony?.configured ? '🟢 READY' : '🟡 NEEDS SETUP'}
                </span>
              </div>
              <p className="text-[11px] opacity-80 leading-snug">
                {status?.telephony?.configured
                  ? `Active via ${status.telephony.provider}`
                  : 'Enter Twilio credentials or Fast2SMS API Key to ring mobile.'}
              </p>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <button
              type="button"
              onClick={() => setActiveTab('gmail')}
              className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'gmail'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              1. Gmail Delivery (SMTP)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('telephony')}
              className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'telephony'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <PhoneCall className="w-3.5 h-3.5" />
              2. Twilio Voice &amp; SMS
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('fast2sms')}
              className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'fast2sms'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              3. Fast2SMS (Indian SMS)
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSaveConfig} className="space-y-4">
            {activeTab === 'gmail' && (
              <div className="space-y-3.5">
                <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-[11px] text-blue-900 space-y-1.5">
                  <p className="font-bold flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-blue-600" />
                    How to get your free 16-character Gmail App Password (1 minute):
                  </p>
                  <ol className="list-decimal list-inside space-y-0.5 text-blue-800 pl-1">
                    <li>Go to your Google Account at <strong>myaccount.google.com/security</strong></li>
                    <li>Ensure <strong>2-Step Verification</strong> is ON, then search for <strong>"App passwords"</strong></li>
                    <li>Enter <strong>"ResQ SOS"</strong> and click Create. Google gives a 16-letter code (e.g. <code>abcd efgh ijkl mnop</code>)</li>
                    <li>Paste that 16-letter password below. ResQ server will now send real emails to your inbox!</li>
                  </ol>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Gmail Address (Sender &amp; Target):
                    </label>
                    <input
                      type="email"
                      value={smtpUser}
                      onChange={(e) => setSmtpUser(e.target.value)}
                      placeholder="sumeetchendke@gmail.com"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      16-Letter Gmail App Password:
                    </label>
                    <input
                      type="password"
                      value={smtpPass}
                      onChange={(e) => setSmtpPass(e.target.value)}
                      placeholder="xxxx xxxx xxxx xxxx"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-[11px] text-slate-500 mb-1">SMTP Host (default: smtp.gmail.com)</label>
                    <input
                      type="text"
                      value={smtpHost}
                      onChange={(e) => setSmtpHost(e.target.value)}
                      className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50 font-mono text-slate-600"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-500 mb-1">Port (default: 587 or 465)</label>
                    <input
                      type="number"
                      value={smtpPort}
                      onChange={(e) => setSmtpPort(Number(e.target.value))}
                      className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 bg-slate-50 font-mono text-slate-600"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'telephony' && (
              <div className="space-y-3.5">
                <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-xl text-[11px] text-indigo-900 space-y-1">
                  <p className="font-bold flex items-center gap-1.5">
                    <PhoneCall className="w-3.5 h-3.5 text-indigo-600" />
                    Twilio Outbound Calling &amp; SMS Setup
                  </p>
                  <p className="text-indigo-800 leading-relaxed">
                    Twilio enables automated cellular phone ringing and SMS dispatch to <strong>+91 9373783496</strong>. You can get free trial credits at <strong>twilio.com</strong>.
                  </p>
                  <div className="mt-2 pt-2 border-t border-indigo-200/60 text-[10px] text-indigo-950 font-medium space-y-0.5">
                    <p className="font-bold text-indigo-900">💡 Important for Twilio Free Trial Accounts:</p>
                    <p className="text-slate-600 leading-normal">
                      Twilio Trial accounts require you to add <strong>+91 9373783496</strong> under <strong>Verified Caller IDs</strong> in your Twilio Console before trial accounts can ring or SMS it.
                    </p>
                    <a
                      href="https://console.twilio.com/us1/develop/phone-numbers/manage/verified"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-indigo-700 font-bold hover:underline"
                    >
                      <span>Open Twilio Console &rarr; Verified Caller IDs</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Twilio Account SID:
                  </label>
                  <input
                    type="text"
                    value={twilioSid}
                    onChange={(e) => setTwilioSid(e.target.value)}
                    placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Twilio Auth Token:
                    </label>
                    <input
                      type="password"
                      value={twilioAuth}
                      onChange={(e) => setTwilioAuth(e.target.value)}
                      placeholder="Auth Token"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Twilio Outbound Phone Number:
                    </label>
                    <input
                      type="text"
                      value={twilioFrom}
                      onChange={(e) => setTwilioFrom(e.target.value)}
                      placeholder="+1234567890"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'fast2sms' && (
              <div className="space-y-3.5">
                <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-[11px] text-emerald-900 space-y-1">
                  <p className="font-bold flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-emerald-600" />
                    Fast2SMS Quick Indian SMS Gateway
                  </p>
                  <p className="text-emerald-800 leading-relaxed">
                    Fast2SMS (fast2sms.com) is the quickest way to send direct SMS to Indian mobile numbers (e.g. <strong>9373783496</strong>) with zero paperwork.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Fast2SMS Authorization API Key:
                  </label>
                  <input
                    type="password"
                    value={fast2smsApiKey}
                    onChange={(e) => setFast2smsApiKey(e.target.value)}
                    placeholder="Enter your Fast2SMS API Key"
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {/* Success Feedback */}
            {saveSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800 font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{saveSuccess}</span>
              </div>
            )}

            {/* Test Results Display */}
            {testResult && (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-xs">
                <p className="font-bold text-slate-800 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-indigo-600" />
                  Live Gateway Test Diagnostics:
                </p>
                <div className="text-[11px] space-y-1 pt-1">
                  <p className={testResult.emailResult.success ? 'text-emerald-700' : 'text-amber-700'}>
                    <strong>Email:</strong> {testResult.emailResult.message}
                  </p>
                  <p className={testResult.telephonyResult.success ? 'text-emerald-700' : 'text-amber-700'}>
                    <strong>Telephony:</strong> {testResult.telephonyResult.message}
                  </p>
                </div>
              </div>
            )}

            {/* Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
              <button
                type="button"
                onClick={handleTestConnection}
                disabled={testing}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <Activity className={`w-3.5 h-3.5 ${testing ? 'animate-spin' : ''}`} />
                <span>{testing ? 'Verifying Connections...' : 'Test Gateway Connection'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 text-slate-600 hover:text-slate-900 text-xs font-semibold rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{loading ? 'Saving...' : 'Save & Activate Gateways'}</span>
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
