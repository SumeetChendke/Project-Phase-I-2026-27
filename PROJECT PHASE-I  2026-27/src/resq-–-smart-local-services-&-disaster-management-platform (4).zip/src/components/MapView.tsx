import React, { useEffect, useRef, useState, useMemo } from 'react';
import {
  APIProvider,
  Map,
  AdvancedMarker,
  InfoWindow,
  useMap,
  Pin,
} from '@vis.gl/react-google-maps';
import L from 'leaflet';
import {
  MapPin,
  Star,
  Phone,
  Navigation,
  X,
  Filter,
  ArrowUpDown,
  LocateFixed,
  Building2,
  Wrench,
  Fuel,
  Pill,
  Shield,
  ExternalLink,
  ChevronRight,
  ListFilter,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { ServiceProvider } from '../types';
import { useLocation } from '../context/LocationContext';
import { api } from '../services/api';

interface MapViewProps {
  services?: ServiceProvider[];
  onSelectService: (service: ServiceProvider) => void;
  onOpenSos?: (service: ServiceProvider) => void;
  onClose?: () => void;
  selectedCategory?: string;
  initialSortBy?: 'rating' | 'reviews' | 'distance';
  showToolbar?: boolean;
}

// Camera controller helper for smooth panning when user location changes
const GoogleMapCameraController: React.FC<{
  center: { lat: number; lng: number };
  selectedPos?: { lat: number; lng: number } | null;
}> = ({ center, selectedPos }) => {
  const map = useMap();

  useEffect(() => {
    if (!map) return;
    if (selectedPos) {
      map.panTo(selectedPos);
    } else {
      map.panTo(center);
    }
  }, [map, center.lat, center.lng, selectedPos]);

  return null;
};

export const MapView: React.FC<MapViewProps> = ({
  services: externalServices,
  onSelectService,
  onOpenSos,
  onClose,
  selectedCategory: initialCategory,
  initialSortBy = 'rating',
}) => {
  const {
    location,
    detectGpsLocation,
    isDetecting,
    isLiveGps,
    gpsAccuracyMeters,
  } = useLocation();

  // API Key handling (reads Vite env or API fallback)
  const [apiKey, setApiKey] = useState<string>(() => {
    return (
      (import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string) ||
      'AIzaSyA2ngfPYpWKParBoiwkZCkig-PTFBr2GV8'
    );
  });
  const [mapId, setMapId] = useState<string>(() => {
    return (
      (import.meta.env.VITE_GOOGLE_MAPS_MAP_ID as string) ||
      'bf51a910020fa25a'
    );
  });
  const [hasGoogleMapsError, setHasGoogleMapsError] = useState(false);

  // Sorting & Filtering
  const [activeCategory, setActiveCategory] = useState<string>(initialCategory || 'all');
  const [sortBy, setSortBy] = useState<'rating' | 'reviews' | 'distance'>(initialSortBy);
  const [viewMode, setViewMode] = useState<'split' | 'map' | 'list'>('split');
  const [selectedProvider, setSelectedProvider] = useState<ServiceProvider | null>(null);

  // Live Google Places fetched from API
  const [liveGoogleServices, setLiveGoogleServices] = useState<ServiceProvider[]>([]);
  const [isLoadingLive, setIsLoadingLive] = useState(false);
  const [liveFetchSuccess, setLiveFetchSuccess] = useState(false);

  // Leaflet fallback refs
  const leafletContainerRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<L.Map | null>(null);
  const leafletMarkersRef = useRef<L.LayerGroup | null>(null);

  // Check config on mount
  useEffect(() => {
    api.getMapsConfig().then((cfg) => {
      if (cfg.apiKey && cfg.apiKey !== apiKey) {
        setApiKey(cfg.apiKey);
      }
      if (cfg.mapId && cfg.mapId !== mapId) {
        setMapId(cfg.mapId);
      }
    });
  }, [apiKey, mapId]);

  // Fetch actual Google Places services around live location
  const fetchLiveServices = async (lat: number, lng: number, category?: string) => {
    setIsLoadingLive(true);
    try {
      const data = await api.getLiveGoogleServices({
        lat,
        lng,
        category: category !== 'all' ? category : undefined,
        sort: sortBy,
        radius: 25,
      });

      if (data.services && data.services.length > 0) {
        setLiveGoogleServices(data.services);
        setLiveFetchSuccess(true);
      }
    } catch (err) {
      console.warn('[MapView] Live Google Services fetch error, falling back to database', err);
    } finally {
      setIsLoadingLive(false);
    }
  };

  // Trigger live fetch when location coordinates change
  useEffect(() => {
    fetchLiveServices(location.lat, location.lng, activeCategory);
  }, [location.lat, location.lng, activeCategory, sortBy]);

  // Combine external and live services
  const displayedServices = useMemo(() => {
    let list: ServiceProvider[] = [];

    if (liveGoogleServices.length > 0) {
      list = [...liveGoogleServices];
    } else if (externalServices && externalServices.length > 0) {
      list = [...externalServices];
    }

    // Filter by category
    if (activeCategory && activeCategory !== 'all') {
      const targetCat = activeCategory.toLowerCase();
      list = list.filter((s) => {
        const itemCat = s.primaryCategoryId.toLowerCase();
        if (itemCat === targetCat) return true;
        if (
          targetCat === 'emergency-shelters' &&
          (itemCat === 'relief-centres' || itemCat === 'disaster-response')
        )
          return true;
        if (
          targetCat === 'ambulances' &&
          (itemCat === 'ambulances' || s.businessName.toLowerCase().includes('ambulance'))
        )
          return true;
        if (
          targetCat === 'police-stations' &&
          (itemCat === 'police-stations' || s.businessName.toLowerCase().includes('police'))
        )
          return true;
        if (
          targetCat === 'ev-charging' &&
          (itemCat === 'ev-charging' || s.businessName.toLowerCase().includes('charging'))
        )
          return true;
        return false;
      });
    }

    // Sort rating-wise (Highest rating, then review volume)
    const sorted = [...list].sort((a, b) => {
      if (sortBy === 'distance') {
        return (a.distanceKm ?? 999) - (b.distanceKm ?? 999);
      }
      if (sortBy === 'reviews') {
        const revA = a.googleReviewCount ?? 0;
        const revB = b.googleReviewCount ?? 0;
        return revB - revA;
      }

      // Default: 'rating' (Rating-wise descending)
      const rateA = a.googleRating ?? a.platformRating ?? 0;
      const rateB = b.googleRating ?? b.platformRating ?? 0;
      if (rateB !== rateA) {
        return rateB - rateA;
      }
      // Tie breaker by review volume
      const countA = a.googleReviewCount ?? a.platformReviewCount ?? 0;
      const countB = b.googleReviewCount ?? b.platformReviewCount ?? 0;
      return countB - countA;
    });

    // Assign ratingWiseRank
    sorted.forEach((item, index) => {
      item.ratingWiseRank = index + 1;
    });

    return sorted;
  }, [liveGoogleServices, externalServices, activeCategory, sortBy]);

  // Handle "Fetch Live Location" click
  const handleFetchLiveGps = async () => {
    try {
      await detectGpsLocation();
    } catch (_err) {
      // Handled in LocationContext
    }
  };

  // Leaflet fallback setup if Google Maps fails
  useEffect(() => {
    if (!hasGoogleMapsError || !leafletContainerRef.current) return;

    if (!leafletMapRef.current) {
      const map = L.map(leafletContainerRef.current, {
        center: [location.lat, location.lng],
        zoom: 13,
      });

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors (100% Free • Zero API Charges)',
        maxZoom: 19,
      }).addTo(map);

      leafletMarkersRef.current = L.layerGroup().addTo(map);
      leafletMapRef.current = map;
      setTimeout(() => map.invalidateSize(), 200);
    } else {
      leafletMapRef.current.setView([location.lat, location.lng], 13);
      leafletMapRef.current.invalidateSize();
    }

    // Markers in Leaflet
    if (leafletMarkersRef.current) {
      leafletMarkersRef.current.clearLayers();

      // Add User Live Location Pulsating Blue Pin
      const userGpsIcon = L.divIcon({
        className: 'user-gps-pulse',
        html: `<div style="position: relative; width: 22px; height: 22px; display: flex; align-items: center; justify-content: center;">
          <div style="position: absolute; width: 34px; height: 34px; border-radius: 50%; background: rgba(37, 99, 235, 0.4); animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
          <div style="width: 14px; height: 14px; border-radius: 50%; background: #2563eb; border: 2.5px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.35);"></div>
        </div>`,
        iconAnchor: [11, 11],
      });
      L.marker([location.lat, location.lng], { icon: userGpsIcon })
        .bindTooltip('<b>📍 Your Live Location</b>', { permanent: false, direction: 'top' })
        .addTo(leafletMarkersRef.current);

      displayedServices.forEach((s) => {
        const catId = s.primaryCategoryId.toLowerCase();
        let markerColor = '#2563eb';
        let markerIcon = '📍';

        if (catId === 'police-stations') {
          markerColor = '#4338ca';
          markerIcon = '👮';
        } else if (catId === 'ev-charging') {
          markerColor = '#059669';
          markerIcon = '⚡';
        } else if (catId === 'ambulances') {
          markerColor = '#dc2626';
          markerIcon = '🚨';
        } else if (catId === 'emergency-shelters' || catId === 'relief-centres') {
          markerColor = '#d97706';
          markerIcon = '🏕️';
        } else if (catId === 'hospitals') {
          markerColor = '#e11d48';
          markerIcon = '🏥';
        } else if (catId === 'pharmacies') {
          markerColor = '#0d9488';
          markerIcon = '💊';
        } else if (catId === 'garages') {
          markerColor = '#b45309';
          markerIcon = '🔧';
        } else if (catId === 'petrol-pumps') {
          markerColor = '#334155';
          markerIcon = '⛽';
        } else if (s.isEmergencyService) {
          markerColor = '#dc2626';
          markerIcon = '🚨';
        }

        const customIcon = L.divIcon({
          className: 'custom-pin',
          html: `<div style="background-color: ${markerColor}; color: white; padding: 2px 7px; border-radius: 9999px; font-size: 11px; font-weight: 700; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3); display: flex; align-items: center; gap: 3px; border: 2px solid white; cursor: pointer;"><span>${markerIcon}</span> ⭐ ${s.googleRating ? s.googleRating.toFixed(1) : '4.5'}</div>`,
          iconAnchor: [24, 15],
        });

        const marker = L.marker([s.latitude, s.longitude], { icon: customIcon });
        marker.on('click', () => setSelectedProvider(s));
        marker.bindPopup(`
          <div style="font-family: inherit; font-size: 12px; min-width: 190px;">
            <div style="font-weight: 800; color: #0f172a; margin-bottom: 2px;">${s.businessName}</div>
            <div style="color: #64748b; font-size: 11px; margin-bottom: 6px;">${s.address}</div>
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
              <span style="background: #fef3c7; color: #92400e; padding: 1px 6px; border-radius: 4px; font-weight: 700;">⭐ ${s.googleRating ? s.googleRating.toFixed(1) : '4.5'}</span>
              ${s.distanceKm !== undefined ? `<span style="color: #64748b;">${s.distanceKm.toFixed(1)} km away</span>` : ''}
            </div>
            <div style="display: flex; gap: 4px;">
              <a href="https://www.google.com/maps/dir/?api=1&destination=${s.latitude},${s.longitude}" target="_blank" style="flex: 1; text-align: center; background: #2563eb; color: white; padding: 4px 8px; border-radius: 6px; text-decoration: none; font-weight: 700; font-size: 11px;">Directions</a>
              ${s.phone ? `<a href="tel:${s.phone}" style="flex: 1; text-align: center; background: #059669; color: white; padding: 4px 8px; border-radius: 6px; text-decoration: none; font-weight: 700; font-size: 11px;">Call</a>` : ''}
            </div>
          </div>
        `);
        leafletMarkersRef.current?.addLayer(marker);
      });
    }
  }, [hasGoogleMapsError, displayedServices, location.lat, location.lng]);

  const mapCenter = useMemo(
    () => ({ lat: location.lat, lng: location.lng }),
    [location.lat, location.lng]
  );

  return (
    <div className="relative w-full h-[680px] rounded-3xl overflow-hidden border border-slate-200 bg-slate-50 shadow-lg flex flex-col">
      {/* 1. Header Toolbar */}
      <div className="bg-white/95 backdrop-blur-md px-4 py-3 border-b border-slate-200 z-20 flex flex-wrap items-center justify-between gap-3 shadow-xs">
        {/* Left: Location & Live Status */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-xs">
            <MapPin className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-900 truncate max-w-[200px] sm:max-w-xs">
                {location.name}
              </span>
              {isLiveGps ? (
                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                  Live GPS
                </span>
              ) : (
                <span className="text-[10px] text-slate-500 font-medium bg-slate-100 px-2 py-0.5 rounded-full">
                  Selected Area
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              {displayedServices.length} actual Google Maps services • Sorted rating-wise
            </p>
          </div>
        </div>

        {/* Center: Live GPS Fetch Button */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleFetchLiveGps}
            disabled={isDetecting}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-xl transition-all shadow-xs disabled:opacity-60"
            title="Fetch user's live GPS coordinates and list real services on Google Maps"
          >
            <LocateFixed className={`w-3.5 h-3.5 ${isDetecting ? 'animate-spin text-amber-300' : ''}`} />
            <span>{isDetecting ? 'Detecting Live GPS...' : '🎯 Fetch Live Location'}</span>
          </button>

          {/* Sort Selector */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setSortBy('rating')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 ${
                sortBy === 'rating'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Rank by Google Rating (Highest to Lowest)"
            >
              <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
              <span>Highest Rated</span>
            </button>
            <button
              type="button"
              onClick={() => setSortBy('reviews')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                sortBy === 'reviews'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Rank by Google Reviews volume"
            >
              Most Reviews
            </button>
            <button
              type="button"
              onClick={() => setSortBy('distance')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                sortBy === 'distance'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Rank by Distance"
            >
              Nearest
            </button>
          </div>

          {/* View Mode Toggle */}
          <div className="hidden sm:flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setViewMode('split')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                viewMode === 'split' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Split View
            </button>
            <button
              type="button"
              onClick={() => setViewMode('map')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors ${
                viewMode === 'map' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              Map Only
            </button>
          </div>

          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* 2. Secondary Filter Bar (Category Pills) */}
      <div className="bg-slate-50/90 px-4 py-2 border-b border-slate-200 z-10 flex items-center gap-1.5 overflow-x-auto text-xs no-scrollbar">
        <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider shrink-0 mr-1">
          Filter:
        </span>
        {[
          { id: 'all', label: 'All Services' },
          { id: 'police-stations', label: '👮 Police Stations' },
          { id: 'ev-charging', label: '⚡ EV Charging' },
          { id: 'ambulances', label: '🚨 Ambulances' },
          { id: 'emergency-shelters', label: '🏕️ Relief Shelters' },
          { id: 'hospitals', label: '🏥 Hospitals' },
          { id: 'pharmacies', label: '💊 Pharmacies' },
          { id: 'garages', label: '🔧 Garages & Towing' },
          { id: 'petrol-pumps', label: '⛽ Fuel & Gas' },
          { id: 'clinics', label: '🩺 Doctors & Clinics' },
        ].map((cat) => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setActiveCategory(cat.id)}
            className={`px-2.5 py-1 rounded-full font-medium whitespace-nowrap transition-colors shrink-0 ${
              activeCategory === cat.id
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* 3. Main Body: Split View or Full Map */}
      <div className="flex-1 flex flex-col md:flex-row relative overflow-hidden">
        {/* Left Column: Ranked Services List (in Split mode) */}
        {viewMode === 'split' && (
          <div className="w-full md:w-80 lg:w-96 bg-white border-r border-slate-200 flex flex-col h-1/2 md:h-full z-10 shrink-0">
            {/* List Header */}
            <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs font-semibold text-slate-700">
              <div className="flex items-center gap-1.5">
                <ListFilter className="w-3.5 h-3.5 text-blue-600" />
                <span>Ranked Rating-Wise</span>
              </div>
              <span className="text-[11px] text-slate-500 font-normal">
                {displayedServices.length} locations
              </span>
            </div>

            {/* List Body */}
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 p-2 space-y-1.5">
              {isLoadingLive ? (
                <div className="p-8 text-center text-xs text-slate-500 space-y-2">
                  <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
                  <p>Fetching real Google Maps services around your coordinates...</p>
                </div>
              ) : displayedServices.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">
                  <p className="font-semibold text-slate-700">No services found in this category.</p>
                  <p className="text-[11px] mt-1">Try switching to "All Services" or expand radius.</p>
                </div>
              ) : (
                displayedServices.map((service, index) => {
                  const isSelected = selectedProvider?.id === service.id;
                  const isEmergency = service.isEmergencyService || service.primaryCategoryId === 'hospitals';

                  return (
                    <div
                      key={service.id || index}
                      onClick={() => setSelectedProvider(service)}
                      className={`p-3 rounded-2xl cursor-pointer transition-all border ${
                        isSelected
                          ? 'bg-blue-50/70 border-blue-300 shadow-sm ring-1 ring-blue-400'
                          : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2">
                          {/* Rank badge */}
                          <div
                            className={`w-6 h-6 rounded-lg flex items-center justify-center text-[11px] font-black shrink-0 ${
                              index === 0
                                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                : index === 1
                                ? 'bg-slate-200 text-slate-800'
                                : index === 2
                                ? 'bg-orange-100 text-orange-900'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            #{index + 1}
                          </div>

                          <div>
                            <h4 className="text-xs font-bold text-slate-900 leading-tight">
                              {service.businessName}
                            </h4>
                            <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                              {service.address}
                            </p>
                          </div>
                        </div>

                        {/* Rating Badge */}
                        <div className="text-right shrink-0">
                          {typeof service.googleRating === 'number' ? (
                            <div className="inline-flex items-center gap-1 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200 text-xs font-bold text-amber-950">
                              <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                              <span>{service.googleRating.toFixed(1)}</span>
                            </div>
                          ) : (
                            <div className="inline-flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-lg text-xs font-semibold text-slate-600">
                              <Star className="w-3 h-3 fill-amber-300 text-amber-400" />
                              <span>{service.platformRating?.toFixed(1) || '4.5'}</span>
                            </div>
                          )}
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            {service.googleReviewCount
                              ? `${service.googleReviewCount.toLocaleString()} Google reviews`
                              : 'Verified'}
                          </div>
                        </div>
                      </div>

                      {/* Footer tags & quick actions */}
                      <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t border-slate-100 text-[11px]">
                        <div className="flex items-center gap-2 text-slate-500">
                          {service.distanceKm !== undefined && (
                            <span className="font-mono text-slate-700 font-semibold">
                              {service.distanceKm.toFixed(1)} km away
                            </span>
                          )}
                          {isEmergency && (
                            <span className="text-[10px] font-bold text-red-600 bg-red-50 px-1.5 py-0.5 rounded-md">
                              24/7 Emergency
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1.5">
                          {service.googleMapsUri && (
                            <a
                              href={service.googleMapsUri}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="text-blue-600 hover:text-blue-800 p-1 rounded-md hover:bg-blue-50"
                              title="Open on Google Maps"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectService(service);
                            }}
                            className="px-2 py-0.5 bg-slate-900 text-white rounded-md font-semibold text-[10px] hover:bg-slate-800"
                          >
                            Details
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Right / Center: The Google Map */}
        <div className="flex-1 relative h-full">
          {!hasGoogleMapsError && apiKey ? (
            <APIProvider
              apiKey={apiKey}
              libraries={['places', 'marker']}
              onError={(e) => {
                console.warn('[Google Maps APIProvider Error]', e);
                setHasGoogleMapsError(true);
              }}
            >
              <Map
                mapId={mapId}
                internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
                defaultCenter={mapCenter}
                defaultZoom={13}
                gestureHandling="greedy"
                disableDefaultUI={false}
                zoomControl={true}
                className="w-full h-full"
              >
                {/* Auto camera panning on live position changes */}
                <GoogleMapCameraController
                  center={mapCenter}
                  selectedPos={
                    selectedProvider
                      ? { lat: selectedProvider.latitude, lng: selectedProvider.longitude }
                      : null
                  }
                />

                {/* Live User Location GPS Marker */}
                <AdvancedMarker position={mapCenter} title="Your Live Location">
                  <div className="relative flex items-center justify-center">
                    <span className="absolute w-8 h-8 rounded-full bg-blue-500/30 animate-ping" />
                    <div className="w-5 h-5 rounded-full bg-blue-600 border-2 border-white shadow-md flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-white" />
                    </div>
                  </div>
                </AdvancedMarker>

                {/* Service Markers with Rating Pill */}
                {displayedServices.map((service, idx) => {
                  const isSelected = selectedProvider?.id === service.id;
                  const catId = service.primaryCategoryId.toLowerCase();

                  let badgeBg = 'bg-blue-600';
                  let iconEmoji = '📍';

                  if (catId === 'police-stations') {
                    badgeBg = 'bg-indigo-700';
                    iconEmoji = '👮';
                  } else if (catId === 'ev-charging') {
                    badgeBg = 'bg-emerald-600';
                    iconEmoji = '⚡';
                  } else if (catId === 'ambulances') {
                    badgeBg = 'bg-red-600';
                    iconEmoji = '🚨';
                  } else if (catId === 'emergency-shelters' || catId === 'relief-centres') {
                    badgeBg = 'bg-amber-600';
                    iconEmoji = '🏕️';
                  } else if (catId === 'hospitals') {
                    badgeBg = 'bg-rose-600';
                    iconEmoji = '🏥';
                  } else if (catId === 'pharmacies') {
                    badgeBg = 'bg-teal-600';
                    iconEmoji = '💊';
                  } else if (catId === 'garages') {
                    badgeBg = 'bg-amber-800';
                    iconEmoji = '🔧';
                  } else if (catId === 'petrol-pumps') {
                    badgeBg = 'bg-slate-700';
                    iconEmoji = '⛽';
                  } else if (service.isEmergencyService) {
                    badgeBg = 'bg-red-600';
                    iconEmoji = '🚨';
                  }

                  return (
                    <AdvancedMarker
                      key={service.id || idx}
                      position={{ lat: service.latitude, lng: service.longitude }}
                      onClick={() => setSelectedProvider(service)}
                      zIndex={isSelected ? 999 : 100 - idx}
                    >
                      <div
                        className={`flex items-center gap-1 px-2 py-1 rounded-full text-white font-bold text-xs shadow-md border-2 border-white transition-transform ${badgeBg} ${
                          isSelected ? 'scale-125 ring-2 ring-slate-900' : 'hover:scale-110'
                        }`}
                      >
                        <span className="text-[11px] leading-none">{iconEmoji}</span>
                        <Star className="w-3 h-3 fill-amber-300 text-amber-300" />
                        <span>{service.googleRating ? service.googleRating.toFixed(1) : '4.5'}</span>
                      </div>
                    </AdvancedMarker>
                  );
                })}

                {/* InfoWindow for Selected Provider */}
                {selectedProvider && (
                  <InfoWindow
                    position={{
                      lat: selectedProvider.latitude,
                      lng: selectedProvider.longitude,
                    }}
                    onCloseClick={() => setSelectedProvider(null)}
                  >
                    <div className="p-2 max-w-xs text-slate-900">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
                          {selectedProvider.primaryCategoryId.replace('-', ' ')}
                        </span>
                        {selectedProvider.ratingWiseRank && (
                          <span className="text-[10px] font-black text-amber-900 bg-amber-100 px-1.5 py-0.5 rounded">
                            #{selectedProvider.ratingWiseRank} Rated
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm font-bold leading-tight">{selectedProvider.businessName}</h4>
                      <p className="text-xs text-slate-500 mt-1">{selectedProvider.address}</p>

                      <div className="flex items-center gap-2 my-2 text-xs">
                        {typeof selectedProvider.googleRating === 'number' && (
                          <span className="flex items-center gap-1 font-bold text-amber-900 bg-amber-50 px-1.5 py-0.5 rounded">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                            <span>{selectedProvider.googleRating.toFixed(1)}</span>
                            <span className="text-slate-400 font-normal">
                              ({selectedProvider.googleReviewCount ?? 0} reviews)
                            </span>
                          </span>
                        )}
                        {selectedProvider.distanceKm !== undefined && (
                          <span className="font-mono text-slate-600 font-semibold">
                            {selectedProvider.distanceKm.toFixed(1)} km
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100 flex-wrap">
                        {onOpenSos && (
                          <button
                            type="button"
                            onClick={() => onOpenSos(selectedProvider)}
                            className="flex-1 py-1 text-center text-xs font-bold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-md cursor-pointer"
                            title="Dispatch Emergency SOS for this service"
                          >
                            🚨 SOS
                          </button>
                        )}
                        {selectedProvider.phone && (
                          <a
                            href={`tel:${selectedProvider.phone}`}
                            className="flex-1 py-1 text-center text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md"
                          >
                            Call
                          </a>
                        )}
                        <a
                          href={
                            selectedProvider.googleMapsUri ||
                            `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                              `${selectedProvider.businessName} ${selectedProvider.address}`
                            )}`
                          }
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1 py-1 text-center text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-md"
                        >
                          Directions
                        </a>
                        <button
                          type="button"
                          onClick={() => onSelectService(selectedProvider)}
                          className="flex-1 py-1 text-center text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md"
                        >
                          Details
                        </button>
                      </div>
                    </div>
                  </InfoWindow>
                )}
              </Map>
            </APIProvider>
          ) : (
            // Leaflet fallback container
            <div ref={leafletContainerRef} className="w-full h-full z-0" />
          )}

          {/* Floating Selected Provider Bottom Drawer (when not in split view or on mobile) */}
          {selectedProvider && viewMode === 'map' && (
            <div className="absolute bottom-4 left-4 right-4 z-20 bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-2xl border border-slate-200 max-w-md mx-auto animate-in fade-in slide-in-from-bottom-2">
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900">{selectedProvider.businessName}</h4>
                    {selectedProvider.isOpenNow && (
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-sm font-medium">
                        Open Now
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{selectedProvider.address}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedProvider(null)}
                  className="text-slate-400 hover:text-slate-600 p-1"
                >
                  ✕
                </button>
              </div>

              <div className="flex items-center gap-3 text-xs text-slate-500 mb-3">
                {typeof selectedProvider.googleRating === 'number' ? (
                  <span className="flex items-center gap-1 font-semibold text-slate-900">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                    <span>{selectedProvider.googleRating.toFixed(1)}</span>
                    <span className="text-slate-400 font-normal">
                      ({selectedProvider.googleReviewCount ?? 0} reviews on Google Maps)
                    </span>
                  </span>
                ) : (
                  <span className="text-slate-400 italic">Verified Service</span>
                )}
                {selectedProvider.distanceKm !== undefined && (
                  <>
                    <span>·</span>
                    <span className="font-mono">{selectedProvider.distanceKm.toFixed(1)} km away</span>
                  </>
                )}
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-slate-100 flex-wrap">
                {onOpenSos && (
                  <button
                    type="button"
                    onClick={() => onOpenSos(selectedProvider)}
                    className="flex-1 py-2 text-center text-xs font-bold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg flex items-center justify-center gap-1 cursor-pointer"
                    title={`Send SOS requesting ${selectedProvider.businessName}`}
                  >
                    <span>🚨 SOS</span>
                  </button>
                )}
                <a
                  href={`tel:${selectedProvider.phone}`}
                  className="flex-1 py-2 text-center text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center gap-1"
                >
                  <Phone className="w-3.5 h-3.5 text-slate-500" />
                  <span>Call</span>
                </a>
                <a
                  href={
                    selectedProvider.googleMapsUri ||
                    `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                      `${selectedProvider.businessName} ${selectedProvider.address}`
                    )}`
                  }
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2 text-center text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg flex items-center justify-center gap-1"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Directions</span>
                </a>
                <button
                  type="button"
                  onClick={() => onSelectService(selectedProvider)}
                  className="flex-1 py-2 text-center text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
                >
                  Details
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
