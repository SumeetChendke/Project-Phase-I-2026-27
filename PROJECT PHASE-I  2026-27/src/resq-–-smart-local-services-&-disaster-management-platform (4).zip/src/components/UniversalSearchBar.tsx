import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  MapPin,
  Clock,
  Sparkles,
  ArrowRight,
  Building2,
  Wrench,
  Fuel,
  Pill,
  Shield,
  Ambulance,
  LifeBuoy,
  Zap,
} from 'lucide-react';
import { useLocation } from '../context/LocationContext';
import { api } from '../services/api';
import { ServiceCategory, ServiceProvider } from '../types';

interface UniversalSearchBarProps {
  onSelectService: (service: ServiceProvider) => void;
  onSelectCategory: (categoryId: string) => void;
  onOpenMap: () => void;
}

const POPULAR_QUICK_CATEGORIES = [
  { id: 'hospitals', name: 'Hospitals', icon: Building2, color: 'text-red-600 bg-red-50 hover:bg-red-100' },
  { id: 'ambulances', name: 'Ambulance', icon: Ambulance, color: 'text-rose-600 bg-rose-50 hover:bg-rose-100' },
  { id: 'garages', name: 'Car & Bike Garages', icon: Wrench, color: 'text-amber-600 bg-amber-50 hover:bg-amber-100' },
  { id: 'petrol-pumps', name: 'Petrol Pumps', icon: Fuel, color: 'text-blue-600 bg-blue-50 hover:bg-blue-100' },
  { id: 'pharmacies', name: '24/7 Pharmacies', icon: Pill, color: 'text-emerald-600 bg-emerald-50 hover:bg-emerald-100' },
  { id: 'police-stations', name: 'Police Stations', icon: Shield, color: 'text-indigo-600 bg-indigo-50 hover:bg-indigo-100' },
  { id: 'emergency-shelters', name: 'Shelters & Relief', icon: LifeBuoy, color: 'text-purple-600 bg-purple-50 hover:bg-purple-100' },
  { id: 'ev-charging', name: 'EV Charging', icon: Zap, color: 'text-teal-600 bg-teal-50 hover:bg-teal-100' },
];

export const UniversalSearchBar: React.FC<UniversalSearchBarProps> = ({
  onSelectService,
  onSelectCategory,
  onOpenMap,
}) => {
  const { location } = useLocation();
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [searchResults, setSearchResults] = useState<{ categories: ServiceCategory[]; services: ServiceProvider[] }>({
    categories: [],
    services: [],
  });
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    const saved = localStorage.getItem('resq_recent_searches');
    return saved ? JSON.parse(saved) : ['AIIMS Hospital', '24/7 Garage Connaught Place', 'Petrol pump near me'];
  });
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Debounced live search
  useEffect(() => {
    if (!query.trim()) {
      setSearchResults({ categories: [], services: [] });
      return;
    }

    const timer = setTimeout(async () => {
      try {
        const data = await api.searchServices(query, location.lat, location.lng);
        setSearchResults(data);
      } catch (e) {
        console.error('Search error', e);
      }
    }, 200);

    return () => clearTimeout(timer);
  }, [query, location.lat, location.lng]);

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setIsFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectRecent = (term: string) => {
    setQuery(term);
  };

  const handleSaveRecent = (term: string) => {
    const updated = [term, ...recentSearches.filter((s) => s.toLowerCase() !== term.toLowerCase())].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('resq_recent_searches', JSON.stringify(updated));
  };

  return (
    <section className="bg-white border-b border-slate-200 py-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-6">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Find Local Services &amp; Emergency Aid
          </h1>
          <p className="text-sm text-slate-500 mt-1 max-w-xl mx-auto">
            Real nearby hospitals, garages, petrol stations, verified disaster shelters, and essential utilities near{' '}
            <span className="font-semibold text-slate-700">{location.name}</span>.
          </p>
        </div>

        {/* Universal Search Box */}
        <div ref={searchContainerRef} className="relative">
          <div className="relative flex items-center shadow-sm rounded-2xl border-2 border-slate-300 focus-within:border-slate-800 focus-within:ring-4 focus-within:ring-slate-900/5 transition-all bg-white overflow-hidden">
            <div className="pl-4 pr-2 text-slate-400">
              <Search className="w-5 h-5" />
            </div>

            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setIsFocused(true)}
              placeholder="Search hospitals, petrol pumps, garages, police stations and more..."
              className="w-full py-4 text-sm sm:text-base text-slate-900 placeholder-slate-400 focus:outline-none"
            />

            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="px-3 text-xs text-slate-400 hover:text-slate-600 font-medium"
              >
                Clear
              </button>
            )}

            <button
              type="button"
              onClick={onOpenMap}
              className="hidden sm:flex items-center gap-1.5 px-4 py-2 mr-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors whitespace-nowrap"
            >
              <MapPin className="w-3.5 h-3.5 text-red-600" />
              <span>Map View</span>
            </button>
          </div>

          {/* Autocomplete & Suggestions Dropdown */}
          {isFocused && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-50 divide-y divide-slate-100 max-h-96 overflow-y-auto">
              {/* If no query: show recent searches and top categories */}
              {!query && (
                <div className="p-4 space-y-4">
                  {recentSearches.length > 0 && (
                    <div>
                      <div className="flex items-center justify-between text-xs font-semibold text-slate-400 mb-2">
                        <span className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Recent Searches</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setRecentSearches([]);
                            localStorage.removeItem('resq_recent_searches');
                          }}
                          className="hover:text-slate-600"
                        >
                          Clear
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {recentSearches.map((term) => (
                          <button
                            key={term}
                            type="button"
                            onClick={() => handleSelectRecent(term)}
                            className="px-3 py-1.5 text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors"
                          >
                            {term}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <span className="block text-xs font-semibold text-slate-400 mb-2">Popular Searches</span>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {POPULAR_QUICK_CATEGORIES.slice(0, 4).map((cat) => (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => {
                            onSelectCategory(cat.id);
                            setIsFocused(false);
                          }}
                          className="text-left p-2.5 rounded-xl border border-slate-100 hover:border-slate-200 hover:bg-slate-50 transition-colors flex items-center gap-2"
                        >
                          <cat.icon className="w-4 h-4 text-slate-700 shrink-0" />
                          <span className="text-xs font-medium text-slate-800 truncate">{cat.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* If query entered: display live matches */}
              {query && (
                <div>
                  {/* Matching categories */}
                  {searchResults.categories.length > 0 && (
                    <div className="p-3 bg-slate-50 border-b border-slate-100">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                        Categories
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {searchResults.categories.map((c) => (
                          <button
                            key={c.id}
                            type="button"
                            onClick={() => {
                              handleSaveRecent(c.name);
                              onSelectCategory(c.id);
                              setIsFocused(false);
                            }}
                            className="px-2.5 py-1 text-xs bg-white border border-slate-200 hover:border-slate-400 rounded-md text-slate-800 font-medium flex items-center gap-1"
                          >
                            <span>{c.name}</span>
                            <ArrowRight className="w-3 h-3 text-slate-400" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Matching verified providers */}
                  {searchResults.services.length > 0 ? (
                    <div className="p-2 space-y-1">
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block px-3 py-1">
                        Verified Nearby Providers
                      </span>
                      {searchResults.services.slice(0, 6).map((service) => (
                        <button
                          key={service.id}
                          type="button"
                          onClick={() => {
                            handleSaveRecent(service.businessName);
                            onSelectService(service);
                            setIsFocused(false);
                          }}
                          className="w-full text-left p-2.5 hover:bg-slate-50 rounded-xl transition-colors flex items-start justify-between gap-3"
                        >
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-semibold text-slate-900">{service.businessName}</span>
                              {service.isOpenNow && (
                                <span className="text-[10px] text-emerald-700 font-medium">Open 24/7</span>
                              )}
                            </div>
                            <p className="text-xs text-slate-500 mt-0.5">{service.address}</p>
                            <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                              <span>Rating: {service.googleRating ?? 'N/A'}</span>
                              <span>·</span>
                              <span className="tabular-nums font-mono">{service.distanceKm} km away</span>
                            </div>
                          </div>
                          <span className="text-xs text-blue-600 font-medium shrink-0 pt-1">View</span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    searchResults.categories.length === 0 && (
                      <div className="p-6 text-center text-xs text-slate-500">
                        No verified services found matching "{query}" within the current radius. Try searching for a broader term like "hospital" or "garage".
                      </div>
                    )
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Popular Service Categories Quick Grid */}
        <div className="mt-6">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider text-center mb-3">
            Frequently Needed Services
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {POPULAR_QUICK_CATEGORIES.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectCategory(item.id)}
                className={`p-3 rounded-xl border border-slate-200/60 transition-all flex items-center gap-3 text-left ${item.color}`}
              >
                <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-xs shrink-0">
                  <item.icon className="w-4 h-4" />
                </div>
                <div className="truncate">
                  <span className="block text-xs font-bold text-slate-900 truncate">{item.name}</span>
                  <span className="text-[11px] text-slate-500">Nearby</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
