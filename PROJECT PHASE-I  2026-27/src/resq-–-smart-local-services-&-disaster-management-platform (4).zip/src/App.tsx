import React, { useState } from 'react';
import { LocationProvider } from './context/LocationContext';
import { AuthProvider } from './context/AuthContext';
import { Header } from './components/Header';
import { UniversalSearchBar } from './components/UniversalSearchBar';
import { EmergencyAssistancePanel } from './components/EmergencyAssistancePanel';
import { PopularHospitalsSection } from './components/PopularHospitalsSection';
import { PopularServicesSection } from './components/PopularServicesSection';
import { AllCategoriesSection } from './components/AllCategoriesSection';
import { DisasterManagementSection } from './components/DisasterManagementSection';
import { AlertsSection } from './components/AlertsSection';
import { Footer } from './components/Footer';
import { ServiceDetailModal } from './components/ServiceDetailModal';
import { CategoryDetailModal } from './components/CategoryDetailModal';
import { MapView } from './components/MapView';
import { GeminiAssistantModal } from './components/GeminiAssistantModal';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { UserAccountModal } from './components/UserAccountModal';
import { EmergencySosModal } from './components/EmergencySosModal';
import { ReliefSheltersModal } from './components/ReliefSheltersModal';
import { ServiceProvider } from './types';
import { SEED_PROVIDERS } from './data/seedProvidersData';

function AppContent() {
  // Modal states
  const [selectedService, setSelectedService] = useState<ServiceProvider | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [showFullMap, setShowFullMap] = useState(false);
  const [showAiAssistant, setShowAiAssistant] = useState(false);
  const [aiInitialPrompt, setAiInitialPrompt] = useState<string | undefined>(undefined);
  const [showAdminDashboard, setShowAdminDashboard] = useState(false);
  const [showUserAccount, setShowUserAccount] = useState(false);
  const [userAccountInitialTab, setUserAccountInitialTab] = useState('favorites');
  const [showEmergencySos, setShowEmergencySos] = useState(false);
  const [showReliefShelters, setShowReliefShelters] = useState(false);
  const [sosTargetService, setSosTargetService] = useState<ServiceProvider | null>(null);
  const [sosTargetCategory, setSosTargetCategory] = useState<string | null>(null);

  const handleOpenSosForService = (service: ServiceProvider, category?: string) => {
    setSosTargetService(service);
    setSosTargetCategory(category || service.primaryCategoryId);
    setShowEmergencySos(true);
  };

  const handleOpenGeneralSos = () => {
    setSosTargetService(null);
    setSosTargetCategory(null);
    setShowEmergencySos(true);
  };

  const handleOpenAiWithPrompt = (prompt: string) => {
    setAiInitialPrompt(prompt);
    setShowAiAssistant(true);
  };

  const handleBookService = (service: ServiceProvider) => {
    setSelectedService(service);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafc] text-slate-900">
      {/* Section 1: Header and location */}
      <Header
        onOpenSearch={() => {
          const searchInput = document.querySelector('input[placeholder*="Search hospitals"]') as HTMLInputElement;
          if (searchInput) {
            searchInput.focus();
            searchInput.scrollIntoView({ behavior: 'smooth' });
          }
        }}
        onOpenAiAssistant={() => {
          setAiInitialPrompt(undefined);
          setShowAiAssistant(true);
        }}
        onOpenAdmin={() => setShowAdminDashboard(true)}
        onOpenUserAccount={(tab) => {
          setUserAccountInitialTab(tab || 'favorites');
          setShowUserAccount(true);
        }}
        onOpenEmergencySos={handleOpenGeneralSos}
        onSelectCategory={(catId) => setSelectedCategoryId(catId)}
        onOpenMap={() => setShowFullMap(true)}
      />

      <main className="flex-1">
        {/* Section 2: Universal service search */}
        <UniversalSearchBar
          onSelectService={(service) => setSelectedService(service)}
          onSelectCategory={(categoryId) => setSelectedCategoryId(categoryId)}
          onOpenMap={() => setShowFullMap(true)}
        />

        {/* Section 3: Emergency assistance panel */}
        <EmergencyAssistancePanel
          onSelectCategory={(categoryId) => setSelectedCategoryId(categoryId)}
          onOpenSosModal={handleOpenGeneralSos}
        />

        {/* Section 3.5: Google Maps Live Services Explorer (Rating-Wise & Live GPS) */}
        <section id="map-section" className="py-10 bg-slate-100 border-b border-slate-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                    Live Google Maps Services Explorer
                  </h2>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 mt-1">
                  Click <strong className="text-blue-700">🎯 Fetch Live Location</strong> to center the Google Map on your GPS coordinates and view actual services listed on Google Maps ranked rating-wise.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                  Live Google Places & Real Ratings
                </span>
              </div>
            </div>

            <MapView
              onSelectService={(service) => setSelectedService(service)}
              onOpenSos={(service) => handleOpenSosForService(service)}
              initialSortBy="rating"
            />
          </div>
        </section>

        {/* Section 4: Popular hospitals near the user (Mandatory) */}
        <PopularHospitalsSection
          onSelectHospital={(hospital) => setSelectedService(hospital)}
          onBookAppointment={(hospital) => handleBookService(hospital)}
          onOpenSos={(hospital) => handleOpenSosForService(hospital, 'Hospitals & Trauma Care')}
        />

        {/* Section 5: Popular nearby services (Garages, Petrol, Pharmacies, Utilities) */}
        <PopularServicesSection
          onSelectService={(service) => setSelectedService(service)}
          onOpenCategory={(categoryId) => setSelectedCategoryId(categoryId)}
          onOpenSos={(service, categoryLabel) => handleOpenSosForService(service, categoryLabel)}
        />

        {/* Section 6: Browse all 44 services */}
        <AllCategoriesSection
          onSelectCategory={(categoryId) => setSelectedCategoryId(categoryId)}
        />

        {/* Section 7: Disaster management centre (16 disasters, preparedness, recovery) */}
        <DisasterManagementSection
          onOpenReliefShelters={() => setShowReliefShelters(true)}
          onAskAiSafety={(disasterName) =>
            handleOpenAiWithPrompt(`What are the step-by-step safety actions for ${disasterName}?`)
          }
        />

        {/* Section 8: Alerts and official announcements */}
        <AlertsSection />
      </main>

      {/* Footer */}
      <Footer
        onOpenSos={handleOpenGeneralSos}
        onSelectCategory={(catId) => setSelectedCategoryId(catId)}
        onOpenShelters={() => setShowReliefShelters(true)}
      />

      {/* MODALS */}

      {/* 1. Service Detail Modal */}
      {selectedService && (
        <ServiceDetailModal
          provider={selectedService}
          onClose={() => setSelectedService(null)}
          onOpenSos={(service) => handleOpenSosForService(service)}
        />
      )}

      {/* 2. Category Detail Modal */}
      {selectedCategoryId && (
        <CategoryDetailModal
          categoryId={selectedCategoryId}
          onClose={() => setSelectedCategoryId(null)}
          onSelectService={(service) => setSelectedService(service)}
          onBookAppointment={(service) => handleBookService(service)}
          onOpenSos={(service, cat) => handleOpenSosForService(service, cat)}
        />
      )}

      {/* 3. Full Map Modal */}
      {showFullMap && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-5xl w-full border border-slate-200 overflow-hidden flex flex-col h-[85vh]">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold">ResQ Interactive Service Map</h3>
                <p className="text-xs text-slate-400">
                  Visualizing verified hospitals, garages, ambulances, and police stations
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowFullMap(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 p-4">
              <MapView
                services={SEED_PROVIDERS}
                onSelectService={(service) => {
                  setShowFullMap(false);
                  setSelectedService(service);
                }}
                onOpenSos={(service) => {
                  setShowFullMap(false);
                  handleOpenSosForService(service);
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* 4. Gemini Flash AI Assistant */}
      {showAiAssistant && (
        <GeminiAssistantModal
          onClose={() => setShowAiAssistant(false)}
          onSelectService={(service) => {
            setShowAiAssistant(false);
            setSelectedService(service);
          }}
          initialPrompt={aiInitialPrompt}
        />
      )}

      {/* 5. Admin Dashboard Modal */}
      {showAdminDashboard && (
        <AdminDashboardModal
          onClose={() => setShowAdminDashboard(false)}
          onAlertBroadcasted={() => {
            // alert updated
          }}
        />
      )}

      {/* 6. User Account Modal */}
      {showUserAccount && (
        <UserAccountModal
          initialTab={userAccountInitialTab}
          onClose={() => setShowUserAccount(false)}
          onSelectService={(service) => {
            setShowUserAccount(false);
            setSelectedService(service);
          }}
        />
      )}

      {/* 7. Emergency SOS Modal */}
      {showEmergencySos && (
        <EmergencySosModal
          targetService={sosTargetService}
          targetCategory={sosTargetCategory}
          onClose={() => {
            setShowEmergencySos(false);
            setSosTargetService(null);
            setSosTargetCategory(null);
          }}
          onOpenShelters={() => {
            setShowEmergencySos(false);
            setSosTargetService(null);
            setSosTargetCategory(null);
            setShowReliefShelters(true);
          }}
        />
      )}

      {/* 8. Relief Shelters Modal */}
      {showReliefShelters && (
        <ReliefSheltersModal onClose={() => setShowReliefShelters(false)} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <LocationProvider>
        <AppContent />
      </LocationProvider>
    </AuthProvider>
  );
}
