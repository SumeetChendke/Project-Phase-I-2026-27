-- Migration: 20261022000001_initial_schema.sql
-- ResQ - All-in-One Local Services and Disaster Management Platform

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Profiles Table
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'provider', 'moderator', 'admin')),
  avatar_url TEXT,
  selected_location JSONB DEFAULT '{"name": "Connaught Place, New Delhi", "lat": 28.6304, "lng": 77.2177, "city": "New Delhi", "state": "Delhi"}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Service Categories Table (at least 35, here 44 organized in 7 groups)
CREATE TABLE IF NOT EXISTS service_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  group_name TEXT NOT NULL,
  icon TEXT NOT NULL,
  description TEXT,
  is_emergency BOOLEAN DEFAULT FALSE,
  display_order INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 3. Provider Profiles Table
CREATE TABLE IF NOT EXISTS provider_profiles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  business_name TEXT NOT NULL,
  primary_category_id TEXT NOT NULL REFERENCES service_categories(id),
  description TEXT,
  phone TEXT NOT NULL,
  email TEXT,
  website TEXT,
  address TEXT NOT NULL,
  locality TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  postal_code TEXT,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  is_verified BOOLEAN DEFAULT FALSE,
  is_emergency_service BOOLEAN DEFAULT FALSE,
  operating_hours JSONB,
  google_place_id TEXT,
  google_rating DOUBLE PRECISION,
  google_review_count INT DEFAULT 0,
  platform_rating DOUBLE PRECISION DEFAULT 0.0,
  platform_review_count INT DEFAULT 0,
  image_url TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'pending', 'suspended')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. Provider Services / Offerings
CREATE TABLE IF NOT EXISTS provider_services (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id) ON DELETE CASCADE,
  service_name TEXT NOT NULL,
  description TEXT,
  price_estimated NUMERIC(10, 2),
  is_bookable BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. User Favorites
CREATE TABLE IF NOT EXISTS user_favorites (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES provider_profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, provider_id)
);

-- 6. Service Bookings
CREATE TABLE IF NOT EXISTS service_bookings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES provider_profiles(id) ON DELETE CASCADE,
  service_title TEXT NOT NULL,
  booking_date DATE NOT NULL,
  booking_time TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'cancelled', 'completed')),
  notes TEXT,
  contact_phone TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. Service Reviews (Store separate from third-party Google ratings)
CREATE TABLE IF NOT EXISTS service_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  provider_id UUID NOT NULL REFERENCES provider_profiles(id) ON DELETE CASCADE,
  rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT NOT NULL,
  is_verified_visit BOOLEAN DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'approved' CHECK (status IN ('approved', 'pending_moderation', 'flagged', 'rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id, provider_id)
);

-- 8. Emergency Contacts
CREATE TABLE IF NOT EXISTS emergency_contacts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  service_type TEXT NOT NULL,
  phone_number TEXT NOT NULL,
  alternate_number TEXT,
  region TEXT NOT NULL DEFAULT 'India (National)',
  is_national BOOLEAN DEFAULT TRUE,
  description TEXT,
  display_order INT DEFAULT 0
);

-- 9. Preparedness Plans
CREATE TABLE IF NOT EXISTS preparedness_plans (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  disaster_type TEXT NOT NULL,
  plan_title TEXT NOT NULL,
  checklist_items JSONB NOT NULL DEFAULT '[]'::jsonb,
  meeting_point TEXT,
  emergency_notes TEXT,
  is_completed BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. Emergency Reports (Citizen hazard & incorrect listing reporting)
CREATE TABLE IF NOT EXISTS emergency_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  report_type TEXT NOT NULL CHECK (report_type IN ('disaster_hazard', 'road_block', 'incorrect_listing', 'shortage', 'other')),
  target_provider_id UUID REFERENCES provider_profiles(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  location_name TEXT NOT NULL,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'investigating', 'resolved', 'dismissed')),
  urgency TEXT NOT NULL DEFAULT 'medium' CHECK (urgency IN ('low', 'medium', 'high', 'critical')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. Disaster Guides (Before, During, After)
CREATE TABLE IF NOT EXISTS disaster_guides (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  severity_level TEXT NOT NULL DEFAULT 'high',
  icon TEXT NOT NULL,
  summary TEXT NOT NULL,
  before_steps JSONB NOT NULL DEFAULT '[]'::jsonb,
  during_steps JSONB NOT NULL DEFAULT '[]'::jsonb,
  after_steps JSONB NOT NULL DEFAULT '[]'::jsonb,
  emergency_kit JSONB NOT NULL DEFAULT '[]'::jsonb,
  vital_contacts JSONB NOT NULL DEFAULT '[]'::jsonb,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. Alerts and Official Announcements
CREATE TABLE IF NOT EXISTS alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  hazard_type TEXT NOT NULL,
  title TEXT NOT NULL,
  affected_area TEXT NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('warning', 'severe', 'critical', 'advisory')),
  source TEXT NOT NULL,
  details TEXT NOT NULL,
  instructions TEXT NOT NULL,
  issue_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expiry_time TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT TRUE,
  verified_status BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 13. Relief Resources (Food, shelter, drinking water, medical camps)
CREATE TABLE IF NOT EXISTS relief_resources (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  resource_type TEXT NOT NULL CHECK (resource_type IN ('shelter', 'food_distribution', 'drinking_water', 'medical_camp', 'evacuation_point')),
  address TEXT NOT NULL,
  locality TEXT NOT NULL,
  city TEXT NOT NULL,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  contact_person TEXT,
  contact_phone TEXT NOT NULL,
  capacity INT,
  current_occupancy INT DEFAULT 0,
  operating_status TEXT NOT NULL DEFAULT 'open' CHECK (operating_status IN ('open', 'full', 'standby', 'closed')),
  supplies_available JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 14. Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  actor_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_table TEXT NOT NULL,
  target_id TEXT,
  payload JSONB,
  ip_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for fast geospatial, category, and user queries
CREATE INDEX IF NOT EXISTS idx_provider_category ON provider_profiles(primary_category_id);
CREATE INDEX IF NOT EXISTS idx_provider_city ON provider_profiles(city);
CREATE INDEX IF NOT EXISTS idx_provider_lat_lng ON provider_profiles(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_bookings_user ON service_bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_provider ON service_bookings(provider_id);
CREATE INDEX IF NOT EXISTS idx_reviews_provider ON service_reviews(provider_id);
CREATE INDEX IF NOT EXISTS idx_reports_status ON emergency_reports(status);
CREATE INDEX IF NOT EXISTS idx_alerts_active ON alerts(is_active);

-- Enable Row Level Security (RLS)
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE preparedness_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Public can read active providers, categories, disaster guides, alerts, relief resources, and public emergency contacts
ALTER TABLE service_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE provider_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE provider_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE disaster_guides ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE relief_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE emergency_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read service categories" ON service_categories FOR SELECT USING (true);
CREATE POLICY "Public read active provider profiles" ON provider_profiles FOR SELECT USING (status = 'active');
CREATE POLICY "Public read provider services" ON provider_services FOR SELECT USING (true);
CREATE POLICY "Public read disaster guides" ON disaster_guides FOR SELECT USING (true);
CREATE POLICY "Public read active alerts" ON alerts FOR SELECT USING (is_active = true);
CREATE POLICY "Public read relief resources" ON relief_resources FOR SELECT USING (true);
CREATE POLICY "Public read emergency contacts" ON emergency_contacts FOR SELECT USING (true);
CREATE POLICY "Public read approved reviews" ON service_reviews FOR SELECT USING (status = 'approved');

-- User Profiles policies
CREATE POLICY "Users read own profile" ON profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users update own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

-- User Favorites policies
CREATE POLICY "Users manage own favorites" ON user_favorites FOR ALL USING (auth.uid() = user_id);

-- Bookings policies
CREATE POLICY "Users view own bookings" ON service_bookings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users create bookings" ON service_bookings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own bookings" ON service_bookings FOR UPDATE USING (auth.uid() = user_id);

-- Preparedness plans policies
CREATE POLICY "Users manage own preparedness plans" ON preparedness_plans FOR ALL USING (auth.uid() = user_id);

-- Reviews policies
CREATE POLICY "Users create own review" ON service_reviews FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own review" ON service_reviews FOR UPDATE USING (auth.uid() = user_id);

-- Reports policies
CREATE POLICY "Users can create reports" ON emergency_reports FOR INSERT WITH CHECK (true);
CREATE POLICY "Users view own reports" ON emergency_reports FOR SELECT USING (auth.uid() = user_id);
