import React, { useState } from 'react';
import {
  Building2,
  Stethoscope,
  UserCheck,
  Pill,
  Ambulance,
  HeartPulse,
  PawPrint,
  Shield,
  Flame,
  AlertTriangle,
  LifeBuoy,
  Home,
  Sparkles,
  Landmark,
  Fuel,
  Zap,
  Wrench,
  Settings,
  Truck,
  Bus,
  TrainTrack,
  KeyRound,
  ShoppingBag,
  UtensilsCrossed,
  Droplet,
  Apple,
  Bath,
  Package,
  Recycle,
  CreditCard,
  Building,
  Scale,
  Mail,
  FileCheck,
  ZapOff,
  Hammer,
  Wifi,
  BedDouble,
  GraduationCap,
  Trees,
  Soup,
  Cat,
  BatteryCharging,
  Search,
  ChevronRight,
} from 'lucide-react';
import { SERVICE_CATEGORIES, SERVICE_GROUPS } from '../data/categoriesData';
import { ServiceCategory, ServiceGroup } from '../types';

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  Building2,
  Stethoscope,
  UserCheck,
  Pill,
  Ambulance,
  HeartPulse,
  PawPrint,
  Shield,
  Flame,
  AlertTriangle,
  LifeBuoy,
  Home,
  Sparkles,
  Landmark,
  Fuel,
  Zap,
  Wrench,
  Settings,
  Truck,
  Bus,
  TrainTrack,
  KeyRound,
  ShoppingBag,
  UtensilsCrossed,
  Droplet,
  Apple,
  Bath,
  Package,
  Recycle,
  CreditCard,
  Building,
  Scale,
  Mail,
  FileCheck,
  ZapOff,
  Hammer,
  Wifi,
  BedDouble,
  GraduationCap,
  Trees,
  Soup,
  Cat,
  BatteryCharging,
};

interface AllCategoriesSectionProps {
  onSelectCategory: (categoryId: string) => void;
}

export const AllCategoriesSection: React.FC<AllCategoriesSectionProps> = ({ onSelectCategory }) => {
  const [selectedGroup, setSelectedGroup] = useState<ServiceGroup | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCategories = SERVICE_CATEGORIES.filter((cat) => {
    const matchesGroup = selectedGroup === 'All' || cat.group === selectedGroup;
    const matchesSearch =
      cat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cat.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGroup && matchesSearch;
  });

  return (
    <section id="services" className="py-14 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Browse All 44 Service Modules
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
              Complete catalog organized across Healthcare, Public Safety, Vehicles, Daily Essentials, and Home Utilities.
            </p>
          </div>

          {/* Quick Search inside categories */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter 44 categories..."
              className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-400"
            />
          </div>
        </div>

        {/* Group Filter Tabs (Interactive filter control) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-6 scrollbar-none">
          <button
            type="button"
            onClick={() => setSelectedGroup('All')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              selectedGroup === 'All'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-600 hover:text-slate-900'
            }`}
          >
            All Categories ({SERVICE_CATEGORIES.length})
          </button>
          {SERVICE_GROUPS.map((group) => {
            const count = SERVICE_CATEGORIES.filter((c) => c.group === group).length;
            const isSelected = selectedGroup === group;
            return (
              <button
                key={group}
                type="button"
                onClick={() => setSelectedGroup(group)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  isSelected
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>{group}</span>
                <span className="ml-1 opacity-70">({count})</span>
              </button>
            );
          })}
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredCategories.map((cat) => {
            const IconComponent = ICON_MAP[cat.icon] || Building2;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => onSelectCategory(cat.id)}
                className="group p-4 rounded-xl border border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs transition-all text-left flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2.5">
                    <div
                      className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 transition-transform group-hover:scale-105 ${
                        cat.isEmergency ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      <IconComponent className="w-4 h-4" />
                    </div>
                    {cat.isEmergency && (
                      <span className="text-[10px] text-red-600 font-semibold tracking-wide">
                        Emergency
                      </span>
                    )}
                  </div>

                  <h3 className="text-xs sm:text-sm font-bold text-slate-900 leading-snug group-hover:text-blue-600 transition-colors">
                    {cat.name}
                  </h3>

                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {cat.description}
                  </p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                  <span>{cat.group}</span>
                  <span className="font-semibold text-blue-600 flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                    <span>Explore</span>
                    <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {filteredCategories.length === 0 && (
          <div className="p-10 text-center bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500">
            No service categories match your filter "{searchQuery}".
          </div>
        )}
      </div>
    </section>
  );
};
