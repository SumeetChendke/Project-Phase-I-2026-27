import { ServiceProvider } from '../types';
import { calculateDistanceKm } from './db';

interface ReverseGeocodeResult {
  name: string;
  city: string;
  state: string;
  country: string;
  lat: number;
  lng: number;
  postcode?: string;
  isGps: boolean;
}

// In-memory cache for live places to eliminate redundant external calls
const placesCache = new Map<string, { timestamp: number; data: ServiceProvider[] }>();
const CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes

// Reverse geocode live coordinates using OpenStreetMap Nominatim
export async function reverseGeocode(lat: number, lng: number): Promise<ReverseGeocodeResult> {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
    const response = await fetch(url, {
      signal: AbortSignal.timeout(3000),
      headers: {
        'User-Agent': 'ResQ-Emergency-Platform/1.0 (contact: support@resq.in)',
        'Accept-Language': 'en',
      },
    });

    if (!response.ok) {
      throw new Error(`Nominatim reverse error: ${response.status}`);
    }

    const data = await response.json();
    const addr = data.address || {};

    const locality =
      addr.suburb ||
      addr.neighbourhood ||
      addr.residential ||
      addr.village ||
      addr.road ||
      addr.county ||
      '';

    const city =
      addr.city ||
      addr.town ||
      addr.municipality ||
      addr.state_district ||
      addr.county ||
      'Local Area';

    const state = addr.state || addr.region || '';
    const country = addr.country || '';
    const postcode = addr.postcode || '';

    let formattedName = '';
    if (locality && city && locality !== city) {
      formattedName = `${locality}, ${city}`;
    } else if (city && state) {
      formattedName = `${city}, ${state}`;
    } else {
      formattedName =
        data.display_name?.split(',').slice(0, 2).join(',') ||
        `Live Location (${lat.toFixed(3)}, ${lng.toFixed(3)})`;
    }

    return {
      name: formattedName,
      city,
      state,
      country,
      lat,
      lng,
      postcode,
      isGps: true,
    };
  } catch (_error) {
    // Graceful fallback on network timeout or offline state
    return {
      name: `Live Location (${lat.toFixed(3)}, ${lng.toFixed(3)})`,
      city: 'Local Area',
      state: '',
      country: '',
      lat,
      lng,
      isGps: true,
    };
  }
}

// Forward search any village, town, city, district or PIN code
export async function searchLocations(query: string): Promise<ReverseGeocodeResult[]> {
  try {
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
      query
    )}&limit=6&addressdetails=1`;

    const response = await fetch(url, {
      signal: AbortSignal.timeout(3000),
      headers: {
        'User-Agent': 'ResQ-Emergency-Platform/1.0 (contact: support@resq.in)',
        'Accept-Language': 'en',
      },
    });

    if (!response.ok) {
      return [];
    }

    const list = await response.json();
    return list.map((item: any) => {
      const addr = item.address || {};
      const locality = addr.suburb || addr.neighbourhood || addr.village || addr.road || '';
      const city = addr.city || addr.town || addr.county || item.name || '';
      const state = addr.state || '';
      const country = addr.country || '';

      const name = item.display_name?.split(',').slice(0, 3).join(',') || item.name;

      return {
        name,
        city: city || item.name,
        state,
        country,
        lat: parseFloat(item.lat),
        lng: parseFloat(item.lon),
        postcode: addr.postcode,
        isGps: false,
      };
    });
  } catch (_error) {
    // Graceful silent fallback
    return [];
  }
}

// Fetch live amenities around user's live coordinates using fast Nominatim bounded search
// Helper to call Google Places searchNearby API (New)
async function callGooglePlacesSearchNearby(
  apiKey: string,
  lat: number,
  lng: number,
  radiusMeters: number,
  includedTypes: string[]
): Promise<any[]> {
  try {
    const endpoint = 'https://places.googleapis.com/v1/places:searchNearby';
    const requestBody = {
      includedTypes,
      maxResultCount: 20,
      locationRestriction: {
        circle: {
          center: { latitude: lat, longitude: lng },
          radius: Math.min(radiusMeters, 50000),
        },
      },
      rankPreference: 'POPULARITY',
    };

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': apiKey,
        'X-Goog-FieldMask':
          'places.id,places.displayName,places.formattedAddress,places.location,places.rating,places.userRatingCount,places.primaryType,places.types,places.nationalPhoneNumber,places.googleMapsUri,places.regularOpeningHours',
      },
      body: JSON.stringify(requestBody),
      signal: AbortSignal.timeout(6000),
    });

    if (!response.ok) {
      console.warn(`[Google Places searchNearby] HTTP ${response.status}: ${await response.text()}`);
      return [];
    }

    const data = await response.json();
    return Array.isArray(data.places) ? data.places : [];
  } catch (err) {
    console.warn('[Google Places searchNearby error]', err);
    return [];
  }
}

// Helper to call Google Places searchText API (New)
async function callGooglePlacesSearchText(
  apiKey: string,
  lat: number,
  lng: number,
  radiusMeters: number,
  textQuery: string
): Promise<any[]> {
  try {
    const endpoint = 'https://places.googleapis.com/v1/places:searchText';
    const requestBody = {
      textQuery,
      maxResultCount: 15,
      locationBias: {
        circle: {
          center: { latitude: lat, longitude: lng },
          radius: Math.min(radiusMeters, 50000),
        },
      },
    };

    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': apiKey,
        'X-Goog-FieldMask':
          'places.id,places.displayName,places.formattedAddress,places.location,places.rating,places.userRatingCount,places.primaryType,places.types,places.nationalPhoneNumber,places.googleMapsUri,places.regularOpeningHours',
      },
      body: JSON.stringify(requestBody),
      signal: AbortSignal.timeout(6000),
    });

    if (!response.ok) {
      console.warn(`[Google Places searchText] HTTP ${response.status}: ${await response.text()}`);
      return [];
    }

    const data = await response.json();
    return Array.isArray(data.places) ? data.places : [];
  } catch (err) {
    console.warn('[Google Places searchText error]', err);
    return [];
  }
}

// Maps raw Google Place result to ResQ ServiceProvider
function parseGooglePlace(
  p: any,
  originLat: number,
  originLng: number,
  requestedCategory?: string
): ServiceProvider {
  const pLat = p.location?.latitude ?? originLat;
  const pLng = p.location?.longitude ?? originLng;
  const types: string[] = Array.isArray(p.types) ? p.types : [];
  const primaryType: string = p.primaryType || types[0] || '';
  const name: string = p.displayName?.text || 'Google Maps Verified Service';
  const nameLower = name.toLowerCase();

  let primaryCategory = 'hospitals';
  let isEmergency = false;

  const reqCat = requestedCategory ? requestedCategory.toLowerCase().trim() : '';

  // If a specific category was requested by the user, prioritize assigning that category
  if (reqCat && reqCat !== 'all') {
    if (reqCat === 'police-stations' || reqCat === 'police') {
      primaryCategory = 'police-stations';
      isEmergency = true;
    } else if (reqCat === 'ev-charging' || reqCat === 'charging' || reqCat === 'ev') {
      primaryCategory = 'ev-charging';
      isEmergency = false;
    } else if (reqCat === 'ambulances' || reqCat === 'ambulance') {
      primaryCategory = 'ambulances';
      isEmergency = true;
    } else if (
      reqCat === 'emergency-shelters' ||
      reqCat === 'shelter' ||
      reqCat === 'shelters' ||
      reqCat === 'relief-centres' ||
      reqCat === 'relief'
    ) {
      primaryCategory = reqCat === 'relief-centres' ? 'relief-centres' : 'emergency-shelters';
      isEmergency = true;
    } else if (reqCat.includes('hosp')) {
      primaryCategory = 'hospitals';
      isEmergency = true;
    } else if (reqCat.includes('pharm')) {
      primaryCategory = 'pharmacies';
      isEmergency = true;
    } else if (reqCat.includes('garag') || reqCat.includes('repair')) {
      primaryCategory = 'garages';
      isEmergency = false;
    } else if (reqCat.includes('petrol') || reqCat.includes('gas') || reqCat.includes('fuel')) {
      primaryCategory = 'petrol-pumps';
      isEmergency = false;
    } else if (reqCat.includes('fire')) {
      primaryCategory = 'fire-stations';
      isEmergency = true;
    } else if (reqCat.includes('clinic') || reqCat.includes('doctor')) {
      primaryCategory = 'clinics';
      isEmergency = false;
    }
  } else {
    // In 'all' mode: automatically classify by types and name keywords
    // 1. Police
    if (
      primaryType === 'police' ||
      types.includes('police') ||
      nameLower.includes('police station') ||
      nameLower.includes('thana') ||
      nameLower.includes('police post') ||
      nameLower.includes('chowki')
    ) {
      primaryCategory = 'police-stations';
      isEmergency = true;
    }
    // 2. EV Charging (Check before gas station because chargers are often at fuel stations)
    else if (
      primaryType === 'electric_vehicle_charging_station' ||
      types.includes('electric_vehicle_charging_station') ||
      nameLower.includes('ev charging') ||
      nameLower.includes('charging station') ||
      nameLower.includes('chargezone') ||
      nameLower.includes('eesl charging') ||
      nameLower.includes('tata power ez') ||
      nameLower.includes('zeon charging') ||
      nameLower.includes('statiq')
    ) {
      primaryCategory = 'ev-charging';
      isEmergency = false;
    }
    // 3. Ambulance Services
    else if (
      types.includes('ambulance_service') ||
      nameLower.includes('ambulance') ||
      nameLower.includes('paramedic') ||
      nameLower.includes('emergency medical transport')
    ) {
      primaryCategory = 'ambulances';
      isEmergency = true;
    }
    // 4. Emergency Shelters & Relief Centres
    else if (
      nameLower.includes('shelter') ||
      nameLower.includes('relief') ||
      nameLower.includes('rain basera') ||
      nameLower.includes('aashray') ||
      nameLower.includes('homeless') ||
      nameLower.includes('evacuation') ||
      nameLower.includes('refuge') ||
      primaryType === 'community_center' ||
      types.includes('community_center')
    ) {
      primaryCategory = 'emergency-shelters';
      isEmergency = true;
    }
    // 5. Fire Stations
    else if (
      primaryType === 'fire_station' ||
      types.includes('fire_station') ||
      nameLower.includes('fire station') ||
      nameLower.includes('fire brigade')
    ) {
      primaryCategory = 'fire-stations';
      isEmergency = true;
    }
    // 6. Hospitals
    else if (
      primaryType === 'hospital' ||
      types.includes('hospital') ||
      types.includes('general_hospital') ||
      nameLower.includes('hospital')
    ) {
      primaryCategory = 'hospitals';
      isEmergency = true;
    }
    // 7. Pharmacies
    else if (
      primaryType === 'pharmacy' ||
      types.includes('pharmacy') ||
      types.includes('drugstore') ||
      nameLower.includes('pharmacy') ||
      nameLower.includes('chemist') ||
      nameLower.includes('medical store')
    ) {
      primaryCategory = 'pharmacies';
      isEmergency = true;
    }
    // 8. Garages
    else if (
      primaryType === 'car_repair' ||
      types.includes('car_repair') ||
      types.includes('auto_repair') ||
      nameLower.includes('garage') ||
      nameLower.includes('puncture') ||
      nameLower.includes('car repair') ||
      nameLower.includes('automobile workshop')
    ) {
      primaryCategory = 'garages';
      isEmergency = false;
    }
    // 9. Petrol Pumps & Fuel Stations
    else if (
      primaryType === 'gas_station' ||
      types.includes('gas_station') ||
      nameLower.includes('petrol pump') ||
      nameLower.includes('fuel station')
    ) {
      primaryCategory = 'petrol-pumps';
      isEmergency = false;
    }
    // 10. Clinics & Doctors
    else if (
      primaryType === 'medical_clinic' ||
      types.includes('doctor') ||
      types.includes('medical_clinic')
    ) {
      primaryCategory = 'clinics';
      isEmergency = false;
    }
  }

  const addressParts = (p.formattedAddress || '').split(',').map((s: string) => s.trim());
  const city = addressParts.length > 2 ? addressParts[addressParts.length - 3] : 'Local Area';
  const locality = addressParts.length > 1 ? addressParts[0] : city;
  const distanceKm = calculateDistanceKm(originLat, originLng, pLat, pLng);

  return {
    id: `google-${p.id}`,
    googlePlaceId: p.id,
    businessName: name,
    primaryCategoryId: primaryCategory,
    description: `Authentic verified listing on Google Maps. ${
      p.userRatingCount ? `Backed by ${p.userRatingCount.toLocaleString()} Google reviews.` : ''
    }`,
    phone: p.nationalPhoneNumber || 'Contact via Google Maps',
    address: p.formattedAddress || `${locality}, ${city}`,
    locality,
    city,
    state: addressParts.length > 1 ? addressParts[addressParts.length - 2] : '',
    latitude: pLat,
    longitude: pLng,
    distanceKm,
    isVerified: true,
    isEmergencyService: isEmergency,
    operatingHours: {
      open24Hours: isEmergency,
    },
    isOpenNow: p.regularOpeningHours?.openNow ?? true,
    googleRating: typeof p.rating === 'number' ? p.rating : null,
    googleReviewCount: typeof p.userRatingCount === 'number' ? p.userRatingCount : null,
    googleMapsUri: p.googleMapsUri,
    platformRating: typeof p.rating === 'number' ? p.rating : 4.5,
    platformReviewCount: p.userRatingCount ? Math.min(p.userRatingCount, 150) : 10,
    status: 'active',
  };
}

// Fetch authentic services listed on Google Maps using Google Places API (New)
export async function fetchGooglePlacesAround(params: {
  lat: number;
  lng: number;
  radiusMeters?: number;
  category?: string;
}): Promise<ServiceProvider[]> {
  const { lat, lng, radiusMeters = 25000, category } = params;
  const apiKey =
    process.env.GOOGLE_MAPS_API_KEY ||
    process.env.VITE_GOOGLE_MAPS_API_KEY ||
    'AIzaSyA2ngfPYpWKParBoiwkZCkig-PTFBr2GV8';

  if (!apiKey || apiKey === 'your-google-maps-api-key') {
    return [];
  }

  const rawPlacesMap = new Map<string, any>();
  const cat = category ? category.toLowerCase().trim() : '';

  try {
    // 1. Police stations requested
    if (cat === 'police-stations' || cat === 'police') {
      const [nearby, text] = await Promise.all([
        callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, ['police']),
        callGooglePlacesSearchText(apiKey, lat, lng, radiusMeters, 'Police Station'),
      ]);
      [...nearby, ...text].forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 2. EV Charging requested
    else if (cat === 'ev-charging' || cat === 'charging' || cat === 'ev') {
      const [nearby, text] = await Promise.all([
        callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, [
          'electric_vehicle_charging_station',
        ]),
        callGooglePlacesSearchText(apiKey, lat, lng, radiusMeters, 'EV Charging Station'),
      ]);
      [...nearby, ...text].forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 3. Ambulance services requested
    else if (cat === 'ambulances' || cat === 'ambulance') {
      const text = await callGooglePlacesSearchText(
        apiKey,
        lat,
        lng,
        radiusMeters,
        'Emergency Ambulance Services'
      );
      text.forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 4. Emergency Shelters & Relief requested
    else if (
      cat === 'emergency-shelters' ||
      cat === 'shelter' ||
      cat === 'shelters' ||
      cat === 'relief-centres' ||
      cat === 'relief'
    ) {
      const [nearby, text] = await Promise.all([
        callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, ['community_center']),
        callGooglePlacesSearchText(
          apiKey,
          lat,
          lng,
          radiusMeters,
          'Emergency shelter or relief camp or homeless shelter'
        ),
      ]);
      [...nearby, ...text].forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 5. Hospitals
    else if (cat.includes('hosp')) {
      const nearby = await callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, [
        'hospital',
      ]);
      nearby.forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 6. Pharmacies
    else if (cat.includes('pharm')) {
      const nearby = await callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, [
        'pharmacy',
        'drugstore',
      ]);
      nearby.forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 7. Garages
    else if (cat.includes('garag') || cat.includes('repair')) {
      const nearby = await callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, [
        'car_repair',
      ]);
      nearby.forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 8. Fuel & Gas
    else if (cat.includes('petrol') || cat.includes('gas') || cat.includes('fuel')) {
      const nearby = await callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, [
        'gas_station',
      ]);
      nearby.forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 9. Fire Stations
    else if (cat.includes('fire')) {
      const nearby = await callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, [
        'fire_station',
      ]);
      nearby.forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 10. Clinics
    else if (cat.includes('clinic') || cat.includes('doctor')) {
      const nearby = await callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, [
        'medical_clinic',
        'doctor',
      ]);
      nearby.forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }
    // 11. All services (Default comprehensive live location query covering police, ev, ambulance, shelters, hospitals)
    else {
      const [nearbyPlaces, ambulancePlaces, shelterPlaces, evPlaces] = await Promise.all([
        callGooglePlacesSearchNearby(apiKey, lat, lng, radiusMeters, [
          'hospital',
          'police',
          'pharmacy',
          'fire_station',
          'electric_vehicle_charging_station',
          'car_repair',
          'gas_station',
          'community_center',
        ]),
        callGooglePlacesSearchText(apiKey, lat, lng, radiusMeters, 'Emergency Ambulance Service'),
        callGooglePlacesSearchText(
          apiKey,
          lat,
          lng,
          radiusMeters,
          'Emergency shelter or relief camp or homeless refuge'
        ),
        callGooglePlacesSearchText(apiKey, lat, lng, radiusMeters, 'EV Charging Station'),
      ]);

      [...nearbyPlaces, ...ambulancePlaces, ...shelterPlaces, ...evPlaces].forEach((p) => {
        if (p?.id && !rawPlacesMap.has(p.id)) rawPlacesMap.set(p.id, p);
      });
    }

    const services: ServiceProvider[] = Array.from(rawPlacesMap.values()).map((p) =>
      parseGooglePlace(p, lat, lng, category)
    );

    // Sort rating-wise: highest Google rating first, tie-break by review count
    services.sort((a, b) => {
      const rateA = a.googleRating ?? 0;
      const rateB = b.googleRating ?? 0;
      if (rateB !== rateA) return rateB - rateA;
      const countA = a.googleReviewCount ?? 0;
      const countB = b.googleReviewCount ?? 0;
      return countB - countA;
    });

    services.forEach((s, idx) => {
      s.ratingWiseRank = idx + 1;
    });

    return services;
  } catch (err) {
    console.warn('[Google Places Search Warning]', err);
    return [];
  }
}

// Fetch live amenities around user's live coordinates (prioritizing Google Places with OSM fallback)
export async function fetchLivePlacesAround(params: {
  lat: number;
  lng: number;
  radiusMeters?: number;
  category?: string;
}): Promise<ServiceProvider[]> {
  const { lat, lng, radiusMeters = 20000, category } = params;

  // Round coordinates to ~1km precision for cache key
  const cacheKey = `${lat.toFixed(2)},${lng.toFixed(2)}-${category || 'all'}`;
  const cached = placesCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    return cached.data;
  }

  // 1. First attempt: Official Google Places API (New) for authentic Google ratings and reviews
  try {
    const googlePlaces = await fetchGooglePlacesAround({
      lat,
      lng,
      radiusMeters,
      category,
    });

    if (googlePlaces && googlePlaces.length > 0) {
      placesCache.set(cacheKey, {
        timestamp: Date.now(),
        data: googlePlaces,
      });
      return googlePlaces;
    }
  } catch (gErr) {
    console.warn('[Live Places] Google Places fetch skipped or failed, trying OSM fallback:', gErr);
  }

  // 2. Fallback: OpenStreetMap Nominatim bounded amenity search
  const radKm = Math.min(Math.max(radiusMeters / 1000, 5), 35);
  const dLat = radKm / 111.0;
  const dLng = radKm / (111.0 * Math.max(0.1, Math.cos((lat * Math.PI) / 180)));

  const minLon = (lng - dLng).toFixed(5);
  const maxLon = (lng + dLng).toFixed(5);
  const minLat = (lat - dLat).toFixed(5);
  const maxLat = (lat + dLat).toFixed(5);
  const viewbox = `${minLon},${maxLat},${maxLon},${minLat}`;

  const amenities = ['hospital', 'pharmacy', 'police', 'fuel', 'fire_station', 'charging_station', 'social_facility'];
  const results: ServiceProvider[] = [];

  try {
    const fetchPromises = amenities.map(async (amenity) => {
      try {
        const url = `https://nominatim.openstreetmap.org/search?amenity=${amenity}&format=json&limit=5&viewbox=${viewbox}&bounded=1&addressdetails=1`;
        const res = await fetch(url, {
          signal: AbortSignal.timeout(2500),
          headers: {
            'User-Agent': 'ResQ-Emergency-Platform/1.0 (contact: support@resq.in)',
            'Accept-Language': 'en',
          },
        });

        if (!res.ok) return [];
        const items = await res.json();
        return Array.isArray(items) ? items : [];
      } catch (_err) {
        return [];
      }
    });

    const settled = await Promise.allSettled(fetchPromises);
    const seenIds = new Set<string>();

    for (const res of settled) {
      if (res.status !== 'fulfilled') continue;
      for (const item of res.value) {
        const pLat = parseFloat(item.lat);
        const pLng = parseFloat(item.lon);
        if (isNaN(pLat) || isNaN(pLng)) continue;

        const id = `osm-${item.osm_type || 'node'}-${item.osm_id || item.place_id}`;
        if (seenIds.has(id)) continue;
        seenIds.add(id);

        const addr = item.address || {};
        const rawName = item.name || addr.amenity || addr.hospital || addr.pharmacy || '';
        if (!rawName) continue;

        let primaryCategory = 'hospitals';
        let isEmergency = false;

        const itemType = item.type || item.class;
        const rawLower = rawName.toLowerCase();
        if (itemType === 'hospital') {
          primaryCategory = 'hospitals';
          isEmergency = true;
        } else if (itemType === 'pharmacy') {
          primaryCategory = 'pharmacies';
        } else if (itemType === 'police' || rawLower.includes('police')) {
          primaryCategory = 'police-stations';
          isEmergency = true;
        } else if (itemType === 'charging_station' || rawLower.includes('charging')) {
          primaryCategory = 'ev-charging';
        } else if (
          itemType === 'social_facility' ||
          rawLower.includes('shelter') ||
          rawLower.includes('relief') ||
          rawLower.includes('rain basera')
        ) {
          primaryCategory = 'emergency-shelters';
          isEmergency = true;
        } else if (rawLower.includes('ambulance')) {
          primaryCategory = 'ambulances';
          isEmergency = true;
        } else if (itemType === 'fuel') {
          primaryCategory = 'petrol-pumps';
        } else if (itemType === 'fire_station') {
          primaryCategory = 'fire-stations';
          isEmergency = true;
        } else if (itemType === 'clinic' || itemType === 'doctors') {
          primaryCategory = 'clinics';
        }

        const street = addr.road || addr.suburb || addr.quarter || '';
        const city = addr.city || addr.town || addr.municipality || addr.county || 'Local Area';
        const fullAddress = item.display_name || (street ? `${street}, ${city}` : `${rawName}, ${city}`);

        results.push({
          id,
          businessName: rawName,
          primaryCategoryId: primaryCategory,
          description: `Verified local ${primaryCategory.replace('-', ' ')} in ${city}. Source: OpenStreetMap.`,
          phone: addr.phone || 'Direct Navigation Available',
          address: fullAddress,
          locality: street || city,
          city,
          state: addr.state || '',
          postalCode: addr.postcode,
          latitude: pLat,
          longitude: pLng,
          isVerified: true,
          isEmergencyService: isEmergency,
          operatingHours: {
            open24Hours: isEmergency,
          },
          googleRating: null,
          googleReviewCount: 0,
          platformRating: 0.0,
          platformReviewCount: 0,
          status: 'active',
        });
      }
    }

    // Save to cache
    placesCache.set(cacheKey, {
      timestamp: Date.now(),
      data: results,
    });

    return results;
  } catch (_outerErr) {
    return placesCache.get(cacheKey)?.data || [];
  }
}

