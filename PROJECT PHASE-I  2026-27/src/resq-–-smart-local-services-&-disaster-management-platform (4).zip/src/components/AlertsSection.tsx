import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Radio,
  CheckCircle2,
  Clock,
  MapPin,
  ExternalLink,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { DisasterAlert } from '../types';
import { api } from '../services/api';
import { useLocation } from '../context/LocationContext';

export const AlertsSection: React.FC = () => {
  const { location } = useLocation();
  const [alerts, setAlerts] = useState<DisasterAlert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [expandedAlertId, setExpandedAlertId] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    api
      .getAlerts()
      .then((data) => {
        if (isMounted) {
          setAlerts(data);
          setIsLoading(false);
          if (data.length > 0) setExpandedAlertId(data[0].id);
        }
      })
      .catch((err) => {
        console.error('Failed to load alerts', err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const getSeverityStyle = (severity: DisasterAlert['severity']) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-50 text-red-800 border-red-200';
      case 'severe':
        return 'bg-orange-50 text-orange-800 border-orange-200';
      case 'warning':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      default:
        return 'bg-blue-50 text-blue-800 border-blue-200';
    }
  };

  return (
    <section id="alerts" className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Radio className="w-4 h-4 text-red-600 animate-pulse" />
              <span className="text-xs font-bold text-red-700 uppercase tracking-wider">
                Official Early Warning Center
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Active Hazard Warnings &amp; Advisories
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
              Verified announcements from the India Meteorological Department (IMD), NDMA, and Central Pollution Control Board (CPCB).
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Government Verified Only</span>
          </div>
        </div>

        {/* Alerts List */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2].map((n) => (
              <div key={n} className="rounded-2xl border border-slate-200 p-5 bg-slate-50 animate-pulse">
                <div className="h-4 bg-slate-200 rounded-sm w-1/3 mb-2" />
                <div className="h-3 bg-slate-200 rounded-sm w-2/3" />
              </div>
            ))}
          </div>
        ) : alerts.length > 0 ? (
          <div className="space-y-4">
            {alerts.map((alert) => {
              const isExpanded = expandedAlertId === alert.id;
              const severityBadge = getSeverityStyle(alert.severity);

              return (
                <div
                  key={alert.id}
                  className="rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-all overflow-hidden"
                >
                  {/* Top Bar of Alert */}
                  <div
                    onClick={() => setExpandedAlertId(isExpanded ? null : alert.id)}
                    className="p-5 cursor-pointer flex items-start justify-between gap-4 hover:bg-slate-50/50 transition-colors"
                  >
                    <div className="flex items-start gap-3.5">
                      <div className="w-9 h-9 rounded-xl bg-red-50 text-red-600 flex items-center justify-center shrink-0 mt-0.5">
                        <AlertTriangle className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <span
                            className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${severityBadge}`}
                          >
                            {alert.severity}
                          </span>
                          <span className="text-xs font-semibold text-slate-900">{alert.hazardType}</span>
                        </div>
                        <h3 className="text-base font-bold text-slate-900">{alert.title}</h3>
                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                          <span className="flex items-center gap-1 font-medium text-slate-700">
                            <MapPin className="w-3.5 h-3.5 text-slate-400" />
                            <span>{alert.affectedArea}</span>
                          </span>
                          <span>·</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            <span>Issued: {new Date(alert.issueTime).toLocaleDateString()}</span>
                          </span>
                          <span>·</span>
                          <span className="text-slate-600 font-medium">Source: {alert.source}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md"
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>

                  {/* Expanded Details and Safety Instructions */}
                  {isExpanded && (
                    <div className="px-5 pb-5 pt-2 border-t border-slate-100 bg-slate-50/60 text-xs text-slate-700 leading-relaxed space-y-3">
                      <div>
                        <strong className="block text-slate-900 font-semibold mb-1">
                          Situation Assessment:
                        </strong>
                        <p>{alert.details}</p>
                      </div>

                      <div className="p-3.5 rounded-xl bg-amber-50/80 border border-amber-200/80 text-amber-900">
                        <strong className="block font-semibold mb-1 text-amber-950">
                          Mandatory Public Instructions:
                        </strong>
                        <p>{alert.instructions}</p>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                        <span>Expiry: {alert.expiryTime ? new Date(alert.expiryTime).toLocaleString() : 'Until further notice'}</span>
                        <span className="text-emerald-700 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Digital Signature Verified</span>
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500">
            No active disaster warnings or flash floods currently reported for your geographic quadrant.
          </div>
        )}
      </div>
    </section>
  );
};
