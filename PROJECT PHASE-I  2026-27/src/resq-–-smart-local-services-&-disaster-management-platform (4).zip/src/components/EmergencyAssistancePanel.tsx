import React, { useState } from 'react';
import {
  PhoneCall,
  AlertTriangle,
  Building2,
  Ambulance,
  Shield,
  Flame,
  LifeBuoy,
  Wrench,
  Fuel,
  Info,
  ExternalLink,
} from 'lucide-react';

interface EmergencyAssistancePanelProps {
  onSelectCategory: (categoryId: string) => void;
  onOpenSosModal: () => void;
}

export const EmergencyAssistancePanel: React.FC<EmergencyAssistancePanelProps> = ({
  onSelectCategory,
  onOpenSosModal,
}) => {
  const [showExplanation, setShowExplanation] = useState(false);

  return (
    <section className="bg-red-50/70 border-b border-red-100 py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Left: Emergency SOS headline & action */}
          <div className="max-w-xl">
            <div className="flex items-center gap-2 mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
              <span className="text-xs font-bold text-red-700 uppercase tracking-wider">
                Emergency &amp; Immediate Assistance
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              In an emergency? Call SOS Helpline (+91 9373783496) &amp; Forward Live Location.
            </h2>
            <p className="text-xs text-slate-600 mt-1">
              Direct emergency calling to <strong className="text-slate-900">+91 9373783496</strong> and instant dispatch of your live GPS coordinates &amp; shortest driving route to <strong className="text-slate-900">sumeetchendke@gmail.com</strong>.
            </p>

            <div className="mt-3 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={onOpenSosModal}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-black text-white bg-red-600 hover:bg-red-700 active:bg-red-800 rounded-lg shadow-sm transition-colors animate-pulse"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>🚨 Trigger SOS: Call 9373783496 &amp; Send Live Route</span>
              </button>

              <button
                type="button"
                onClick={() => setShowExplanation(!showExplanation)}
                className="text-xs text-slate-500 hover:text-slate-800 underline decoration-slate-300 flex items-center gap-1"
              >
                <Info className="w-3 h-3" />
                <span>How does SOS work?</span>
              </button>
            </div>

            {showExplanation && (
              <div className="mt-3 p-3 bg-white rounded-xl border border-red-200 text-xs text-slate-600 leading-relaxed shadow-xs">
                <strong className="text-slate-900 block mb-1">SOS Protocol &amp; Location Forwarding:</strong>
                Clicking SOS immediately calls emergency responder <strong>+91 9373783496</strong> and sends an emergency email alert to <strong>sumeetchendke@gmail.com</strong> containing your exact live GPS coordinates and a Google Maps turn-by-turn driving link with the shortest path directly to your location. Backup national lines (112, 108, 100) are also available.
              </div>
            )}
          </div>

          {/* Right: Quick action shortcuts */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => onSelectCategory('hospitals')}
              className="p-3 bg-white rounded-xl border border-slate-200 hover:border-red-300 hover:shadow-xs transition-all text-left flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center shrink-0">
                <Building2 className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="block text-xs font-bold text-slate-900 truncate">Hospitals</span>
                <span className="text-[11px] text-slate-500">Trauma ICU</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory('ambulances')}
              className="p-3 bg-white rounded-xl border border-slate-200 hover:border-red-300 hover:shadow-xs transition-all text-left flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                <Ambulance className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="block text-xs font-bold text-slate-900 truncate">Ambulances</span>
                <span className="text-[11px] text-slate-500">Call 108 / 102</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory('police-stations')}
              className="p-3 bg-white rounded-xl border border-slate-200 hover:border-red-300 hover:shadow-xs transition-all text-left flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                <Shield className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="block text-xs font-bold text-slate-900 truncate">Police</span>
                <span className="text-[11px] text-slate-500">Call 100 / PCR</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory('fire-stations')}
              className="p-3 bg-white rounded-xl border border-slate-200 hover:border-red-300 hover:shadow-xs transition-all text-left flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                <Flame className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="block text-xs font-bold text-slate-900 truncate">Fire Rescue</span>
                <span className="text-[11px] text-slate-500">Call 101</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory('emergency-shelters')}
              className="p-3 bg-white rounded-xl border border-slate-200 hover:border-red-300 hover:shadow-xs transition-all text-left flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                <LifeBuoy className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="block text-xs font-bold text-slate-900 truncate">Shelters</span>
                <span className="text-[11px] text-slate-500">Refuge Points</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory('garages')}
              className="p-3 bg-white rounded-xl border border-slate-200 hover:border-red-300 hover:shadow-xs transition-all text-left flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <Wrench className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="block text-xs font-bold text-slate-900 truncate">Garages</span>
                <span className="text-[11px] text-slate-500">Breakdown Aid</span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => onSelectCategory('petrol-pumps')}
              className="p-3 bg-white rounded-xl border border-slate-200 hover:border-red-300 hover:shadow-xs transition-all text-left flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                <Fuel className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="block text-xs font-bold text-slate-900 truncate">Petrol Pumps</span>
                <span className="text-[11px] text-slate-500">24/7 Fuel</span>
              </div>
            </button>

            <a
              href="tel:112"
              className="p-3 bg-red-600 text-white rounded-xl shadow-xs hover:bg-red-700 transition-all text-left flex items-center gap-2.5"
            >
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center shrink-0 text-white">
                <PhoneCall className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="block text-xs font-black truncate">Call 112</span>
                <span className="text-[11px] text-white/80">Direct Dial</span>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
