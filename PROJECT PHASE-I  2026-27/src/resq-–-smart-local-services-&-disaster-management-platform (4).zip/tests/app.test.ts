import { describe, it, expect } from 'vitest';
import { db, calculateDistanceKm } from '../src/server/db';
import { SERVICE_CATEGORIES } from '../src/data/categoriesData';
import { DISASTER_GUIDES } from '../src/data/disasterGuidesData';
import { EMERGENCY_CONTACTS } from '../src/data/emergencyContactsData';
import { handleGeminiAssistantChat } from '../src/server/gemini';
import { dispatchDirectSos } from '../src/server/sosDispatcher';

describe('ResQ Platform Architecture & Core Functionality', () => {
  it('loads all 44 mandatory service categories without authentication', () => {
    const categories = db.getCategories();
    expect(categories.length).toBe(44);
    expect(SERVICE_CATEGORIES.length).toBe(44);

    const hospitalCat = categories.find((c) => c.id === 'hospitals');
    expect(hospitalCat).toBeDefined();
    expect(hospitalCat?.isEmergency).toBe(true);

    const garageCat = categories.find((c) => c.id === 'garages');
    expect(garageCat).toBeDefined();

    const petrolCat = categories.find((c) => c.id === 'petrol-pumps');
    expect(petrolCat).toBeDefined();
  });

  it('calculates accurate geographical distance using Haversine formula', () => {
    // Connaught Place (28.6304, 77.2177) to AIIMS (28.5672, 77.2100) is approx ~7.1 km
    const dist = calculateDistanceKm(28.6304, 77.2177, 28.5672, 77.2100);
    expect(dist).toBeGreaterThan(6.0);
    expect(dist).toBeLessThan(8.5);
  });

  it('ranks popular hospitals accurately without fabricating missing ratings', () => {
    const hospitals = db.getPopularHospitals({
      lat: 28.6304,
      lng: 77.2177,
      sortBy: 'rating',
    });

    expect(hospitals.length).toBeGreaterThan(0);

    // AIIMS should have genuine Google rating and reviews
    const aiims = hospitals.find((h) => h.businessName.includes('AIIMS'));
    expect(aiims).toBeDefined();
    expect(aiims?.googleRating).toBe(4.7);
    expect(aiims?.googleReviewCount).toBeGreaterThan(20000);

    // Clinic with null rating should preserve null (never manufactured)
    const unratedClinic = db.providers.find((p) => p.googleRating === null);
    expect(unratedClinic).toBeDefined();
    expect(unratedClinic?.googleRating).toBeNull();
  });

  it('sorts hospitals by distance, review count, and rating', () => {
    const sortedByReviews = db.getPopularHospitals({
      lat: 28.6304,
      lng: 77.2177,
      sortBy: 'reviews',
    });

    for (let i = 0; i < sortedByReviews.length - 1; i++) {
      const revA = sortedByReviews[i].googleReviewCount ?? 0;
      const revB = sortedByReviews[i + 1].googleReviewCount ?? 0;
      expect(revA).toBeGreaterThanOrEqual(revB);
    }

    const sortedByDistance = db.getPopularHospitals({
      lat: 28.6304,
      lng: 77.2177,
      sortBy: 'distance',
    });

    for (let i = 0; i < sortedByDistance.length - 1; i++) {
      const distA = sortedByDistance[i].distanceKm ?? 0;
      const distB = sortedByDistance[i + 1].distanceKm ?? 0;
      expect(distA).toBeLessThanOrEqual(distB);
    }
  });

  it('manages user favorites with duplicate protection', () => {
    const userId = 'test-user-999';
    const providerId = 'hosp-001';

    // Add favorite
    const added = db.addFavorite(userId, providerId);
    expect(added).toBe(true);

    // Duplicate add should return false
    const duplicate = db.addFavorite(userId, providerId);
    expect(duplicate).toBe(false);

    // Get favorites
    const favs = db.getFavoritesByUser(userId);
    expect(favs.length).toBe(1);
    expect(favs[0].id).toBe(providerId);

    // Remove favorite
    const removed = db.removeFavorite(userId, providerId);
    expect(removed).toBe(true);
    expect(db.getFavoritesByUser(userId).length).toBe(0);
  });

  it('validates booking workflow and updates status', () => {
    const newBooking = db.createBooking({
      userId: 'test-user-123',
      providerId: 'garage-001',
      providerName: 'CityAuto 24-Hour Garage',
      categoryName: 'garages',
      serviceTitle: 'Emergency Brake Inspection',
      bookingDate: '2026-10-25',
      bookingTime: '11:00 AM',
      contactPhone: '+91-9876543210',
      status: 'pending',
    });

    expect(newBooking.id).toBeDefined();
    expect(newBooking.status).toBe('pending');

    const updated = db.updateBookingStatus(newBooking.id, 'accepted');
    expect(updated?.status).toBe('accepted');
  });

  it('distinguishes platform user reviews from Google ratings', () => {
    const provider = db.getProviderById('hosp-001');
    expect(provider).toBeDefined();

    const previousCount = provider?.platformReviewCount ?? 0;

    const newRev = db.createReview({
      userId: 'user-reviewer-1',
      userName: 'Siddharth Sen',
      providerId: 'hosp-001',
      rating: 5,
      comment: 'Excellent cardiology trauma care team on night duty.',
      isVerifiedVisit: true,
    });

    expect(newRev.id).toBeDefined();
    const updatedProvider = db.getProviderById('hosp-001');
    expect(updatedProvider?.platformReviewCount).toBe(previousCount + 1);
    // Google review count should remain untouched
    expect(updatedProvider?.googleReviewCount).toBe(24890);
  });

  it('contains complete verified protocols for all 16 disasters', () => {
    expect(DISASTER_GUIDES.length).toBe(16);

    const requiredDisasters = [
      'floods',
      'earthquakes',
      'cyclones',
      'tsunamis',
      'landslides',
      'fires',
      'heatwaves',
      'droughts',
      'lightning-storms',
      'cloudbursts',
      'industrial-accidents',
      'chemical-leaks',
      'road-accidents',
      'building-collapse',
      'dam-failure',
      'forest-fires',
    ];

    for (const d of requiredDisasters) {
      const guide = DISASTER_GUIDES.find((g) => g.id === d);
      expect(guide).toBeDefined();
      expect(guide?.beforeSteps.length).toBeGreaterThan(0);
      expect(guide?.duringSteps.length).toBeGreaterThan(0);
      expect(guide?.afterSteps.length).toBeGreaterThan(0);
      expect(guide?.emergencyKit.length).toBeGreaterThan(0);
    }
  });

  it('provides verified emergency contacts including 112 universal ERSS', () => {
    const contacts = db.getEmergencyContacts();
    const erss = contacts.find((c) => c.phoneNumber === '112');
    expect(erss).toBeDefined();
    expect(erss?.isNational).toBe(true);

    const ambulance = contacts.find((c) => c.phoneNumber === '108');
    expect(ambulance).toBeDefined();

    const police = contacts.find((c) => c.phoneNumber === '100');
    expect(police).toBeDefined();
  });

  it('provides reliable fallback safety guidance when Gemini API key is offline', async () => {
    const result = await handleGeminiAssistantChat({
      message: 'What should I do during a flood?',
      userLat: 28.6304,
      userLng: 77.2177,
      locationName: 'Connaught Place, New Delhi',
      forceFallback: true,
    });

    expect(result.reply).toBeDefined();
    expect(result.reply.toLowerCase()).toContain('flood');
    expect(result.safetyBanner).toBeDefined();
  });

  it('dynamically adds and indexes live discovered providers for any coordinate', () => {
    const livePlace = {
      id: 'live-test-hosp-1',
      businessName: 'Ruby Hall Clinic, Pune',
      primaryCategoryId: 'hospitals',
      description: 'Live discovered tertiary trauma hospital.',
      phone: '+91-20-66455100',
      address: '40 Sassoon Road, Sangamvadi, Pune',
      locality: 'Sangamvadi',
      city: 'Pune',
      state: 'Maharashtra',
      latitude: 18.5314,
      longitude: 73.8746,
      isVerified: true,
      isEmergencyService: true,
      operatingHours: { open24Hours: true },
      googleRating: null,
      googleReviewCount: 0,
      platformRating: 0,
      platformReviewCount: 0,
      status: 'active' as const,
    };

    db.addProviders([livePlace]);

    const nearbyInPune = db.getNearbyServices({
      lat: 18.5314,
      lng: 73.8746,
      categoryId: 'hospitals',
      radiusKm: 15,
    });

    expect(nearbyInPune.some((p) => p.id === 'live-test-hosp-1')).toBe(true);
  });

  it('correctly ranks live Google services rating-wise (highest rating and reviews first)', () => {
    const highRated = {
      id: 'google-test-1',
      businessName: 'Apex Super Specialty Hospital',
      primaryCategoryId: 'hospitals',
      description: 'Verified listing on Google Maps.',
      phone: '+91-11-23456789',
      address: 'Sector 5, New Delhi',
      locality: 'Connaught Place',
      city: 'New Delhi',
      state: 'Delhi',
      latitude: 28.6300,
      longitude: 77.2170,
      isVerified: true,
      isEmergencyService: true,
      operatingHours: { open24Hours: true },
      googleRating: 4.8,
      googleReviewCount: 1540,
      platformRating: 4.8,
      platformReviewCount: 15,
      status: 'active' as const,
    };

    const midRated = {
      id: 'google-test-2',
      businessName: 'Community Medical Center',
      primaryCategoryId: 'hospitals',
      description: 'Verified listing on Google Maps.',
      phone: '+91-11-23456780',
      address: 'Sector 4, New Delhi',
      locality: 'Connaught Place',
      city: 'New Delhi',
      state: 'Delhi',
      latitude: 28.6310,
      longitude: 77.2180,
      isVerified: true,
      isEmergencyService: true,
      operatingHours: { open24Hours: true },
      googleRating: 4.2,
      googleReviewCount: 300,
      platformRating: 4.2,
      platformReviewCount: 5,
      status: 'active' as const,
    };

    db.addProviders([midRated, highRated]);

    const results = db.getNearbyServices({
      lat: 28.6304,
      lng: 77.2177,
      categoryId: 'hospitals',
      sortBy: 'rating',
    });

    // High rated hospital should rank ahead of lower rated one
    const idxHigh = results.findIndex((p) => p.id === 'google-test-1');
    const idxMid = results.findIndex((p) => p.id === 'google-test-2');
    expect(idxHigh).toBeLessThan(idxMid);
  });

  it('correctly manages police stations, ev-charging, ambulances, and relief shelters', () => {
    const police = {
      id: 'google-police-01',
      businessName: 'Connaught Place Police Station',
      primaryCategoryId: 'police-stations',
      description: 'Authentic police station listing on Google Maps.',
      phone: '112',
      address: 'Near Outer Circle, New Delhi',
      locality: 'Connaught Place',
      city: 'New Delhi',
      state: 'Delhi',
      latitude: 28.6305,
      longitude: 77.2185,
      isVerified: true,
      isEmergencyService: true,
      operatingHours: { open24Hours: true },
      googleRating: 4.6,
      googleReviewCount: 195,
      platformRating: 4.6,
      platformReviewCount: 20,
      status: 'active' as const,
    };

    const ev = {
      id: 'google-ev-01',
      businessName: 'Tata Power EZ EV Fast Charging Station',
      primaryCategoryId: 'ev-charging',
      description: 'Authentic EV fast charger on Google Maps.',
      phone: '+91-1800-209-5161',
      address: 'Barakhamba Road, New Delhi',
      locality: 'Barakhamba',
      city: 'New Delhi',
      state: 'Delhi',
      latitude: 28.6295,
      longitude: 77.2240,
      isVerified: true,
      isEmergencyService: false,
      operatingHours: { open24Hours: true },
      googleRating: 4.5,
      googleReviewCount: 88,
      platformRating: 4.5,
      platformReviewCount: 10,
      status: 'active' as const,
    };

    const amb = {
      id: 'google-amb-01',
      businessName: 'QuickLife Emergency Ambulance Services',
      primaryCategoryId: 'ambulances',
      description: '24/7 ALS/BLS Ambulance on Google Maps.',
      phone: '102',
      address: 'Janpath, New Delhi',
      locality: 'Janpath',
      city: 'New Delhi',
      state: 'Delhi',
      latitude: 28.6250,
      longitude: 77.2190,
      isVerified: true,
      isEmergencyService: true,
      operatingHours: { open24Hours: true },
      googleRating: 4.9,
      googleReviewCount: 64,
      platformRating: 4.9,
      platformReviewCount: 15,
      status: 'active' as const,
    };

    const shelter = {
      id: 'google-shelter-01',
      businessName: 'Delhi Rain Basera & Emergency Night Shelter',
      primaryCategoryId: 'emergency-shelters',
      description: 'Municipal disaster relief and overnight refuge.',
      phone: '1077',
      address: 'Minto Road, New Delhi',
      locality: 'Minto Road',
      city: 'New Delhi',
      state: 'Delhi',
      latitude: 28.6360,
      longitude: 77.2280,
      isVerified: true,
      isEmergencyService: true,
      operatingHours: { open24Hours: true },
      googleRating: 4.4,
      googleReviewCount: 42,
      platformRating: 4.4,
      platformReviewCount: 8,
      status: 'active' as const,
    };

    db.addProviders([police, ev, amb, shelter]);

    // Check Police query
    const policeResults = db.getNearbyServices({
      lat: 28.6304,
      lng: 77.2177,
      categoryId: 'police-stations',
    });
    expect(policeResults.some((p) => p.id === 'google-police-01')).toBe(true);

    // Check EV Charging query
    const evResults = db.getNearbyServices({
      lat: 28.6304,
      lng: 77.2177,
      categoryId: 'ev-charging',
    });
    expect(evResults.some((p) => p.id === 'google-ev-01')).toBe(true);

    // Check Ambulance query
    const ambResults = db.getNearbyServices({
      lat: 28.6304,
      lng: 77.2177,
      categoryId: 'ambulances',
    });
    expect(ambResults.some((p) => p.id === 'google-amb-01')).toBe(true);

    // Check Shelter query
    const shelterResults = db.getNearbyServices({
      lat: 28.6304,
      lng: 77.2177,
      categoryId: 'emergency-shelters',
    });
    expect(shelterResults.some((p) => p.id === 'google-shelter-01')).toBe(true);
  });

  it('configures designated emergency responder 9373783496 and sumeetchendke@gmail.com with shortest path routing', () => {
    const contacts = db.getEmergencyContacts();
    const primarySos = contacts.find((c) => c.phoneNumber === '9373783496');
    expect(primarySos).toBeDefined();
    expect(primarySos?.name).toContain('SOS');
    expect(primarySos?.region).toContain('sumeetchendke@gmail.com');

    // Test shortest path routing link generation for victim coordinates
    const lat = 28.6304;
    const lng = 77.2177;
    const shortestPathUrl = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;
    expect(shortestPathUrl).toBe('https://www.google.com/maps/dir/?api=1&destination=28.6304,77.2177&travelmode=driving');

    // Verify alert creation with shortest path
    const alert = db.createAlert({
      hazardType: 'sos_emergency',
      title: '🚨 EMERGENCY SOS Test',
      affectedArea: 'Connaught Place, New Delhi',
      severity: 'critical',
      source: 'ResQ SOS Dispatch Engine',
      details: `Call forwarded to 9373783496 and email to sumeetchendke@gmail.com. Route: ${shortestPathUrl}`,
      instructions: `Follow shortest path: ${shortestPathUrl}`,
      issueTime: new Date().toISOString(),
      verifiedStatus: true,
    });

    expect(alert).toBeDefined();
    expect(alert.details).toContain('9373783496');
    expect(alert.details).toContain('sumeetchendke@gmail.com');
    expect(alert.details).toContain(shortestPathUrl);
  });

  it('executes 100% in-app direct SOS dispatch without requiring external apps or desktop clients', async () => {
    const dispatchResult = await dispatchDirectSos({
      userName: 'Sumeet User',
      locationName: 'FC Road, Shivaji Nagar, Pune',
      latitude: 18.5204,
      longitude: 73.8567,
      targetPhone: '9373783496',
      targetEmail: 'sumeetchendke@gmail.com',
      emergencyType: 'Critical SOS Assistance',
    });

    expect(dispatchResult.success).toBe(true);
    expect(dispatchResult.dispatchedInApp).toBe(true);
    expect(dispatchResult.noExternalAppsNeeded).toBe(true);
    expect(dispatchResult.targetPhone).toBe('9373783496');
    expect(dispatchResult.targetEmail).toBe('sumeetchendke@gmail.com');
    expect(dispatchResult.shortestPathUrl).toContain('destination=18.5204,73.8567');
    expect(dispatchResult.shortestPathUrl).toContain('travelmode=driving');
    expect(dispatchResult.emailDelivery).toBeDefined();
    expect(dispatchResult.emailDelivery.recipient).toBe('sumeetchendke@gmail.com');
    expect(dispatchResult.telephonyDelivery).toBeDefined();
    expect(dispatchResult.telephonyDelivery.recipient).toContain('9373783496');
  });

  it('verifies SOS gateway configuration status and update lifecycle', async () => {
    const { getSosGatewayStatus, updateSosGatewayConfig } = await import('../src/server/sosDispatcher');
    const initialStatus = getSosGatewayStatus();
    expect(initialStatus).toBeDefined();
    expect(initialStatus.email.targetEmail).toBe('sumeetchendke@gmail.com');
    expect(initialStatus.telephony.targetMobile).toContain('9373783496');

    // Test updating config
    const updated = updateSosGatewayConfig({
      smtpHost: 'smtp.gmail.com',
      smtpUser: 'sumeetchendke@gmail.com',
      fast2smsApiKey: 'test-fast2sms-key',
    });
    expect(updated.success).toBe(true);
    expect(updated.status.telephony.configured).toBe(true);
    expect(['twilio_voice_sms', 'fast2sms']).toContain(updated.status.telephony.provider);
  });

  it('dispatches service-specific emergency SOS with facility name, shortest path, and emergency contacts', async () => {
    const dispatchResult = await dispatchDirectSos({
      userName: 'Rahul Patil',
      userPhone: '+91 98220 12345',
      locationName: 'Shivaji Nagar, Pune',
      latitude: 18.5308,
      longitude: 73.8475,
      targetPhone: '9373783496',
      targetEmail: 'sumeetchendke@gmail.com',
      serviceType: 'Hospitals & Trauma Care',
      selectedFacility: {
        id: 'ankur-hospital',
        name: 'Ankur Superspeciality Hospital',
        category: 'hospitals',
        address: 'FC Road, Deccan Gymkhana, Pune',
        phone: '+91-20-2565-1122',
        latitude: 18.5204,
        longitude: 73.8567,
        distanceKm: 1.4,
      },
      notes: 'Severe chest discomfort and respiratory distress, need immediate ICU trauma prep',
    });

    expect(dispatchResult.success).toBe(true);
    expect(dispatchResult.serviceType).toBe('Hospitals & Trauma Care');
    expect(dispatchResult.selectedFacility).toBeDefined();
    expect(dispatchResult.selectedFacility?.name).toBe('Ankur Superspeciality Hospital');
    expect(dispatchResult.selectedFacility?.phone).toBe('+91-20-2565-1122');
    expect(dispatchResult.selectedFacility?.distanceKm).toBe(1.4);
    expect(dispatchResult.facilityRouteUrl).toBeDefined();
    expect(dispatchResult.facilityRouteUrl).toContain('origin=18.5308,73.8475');
    expect(dispatchResult.facilityRouteUrl).toContain('destination=18.5204,73.8567');
    expect(dispatchResult.facilityRouteUrl).toContain('travelmode=driving');
    expect(dispatchResult.emailDelivery.subject).toContain('Ankur Superspeciality Hospital');
    expect(dispatchResult.emailDelivery.subject).toContain('Hospitals & Trauma Care');
    expect(dispatchResult.telephonyDelivery.smsBody).toContain('Ankur Superspeciality Hospital');
  });
});
