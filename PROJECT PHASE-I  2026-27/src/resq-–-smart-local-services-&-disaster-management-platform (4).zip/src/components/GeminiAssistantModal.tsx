import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  X,
  PhoneCall,
  ShieldAlert,
  Building2,
  Wrench,
  Fuel,
  MapPin,
  Bot,
  User,
  ArrowRight,
  HelpCircle,
} from 'lucide-react';
import { api } from '../services/api';
import { useLocation } from '../context/LocationContext';
import { ServiceProvider } from '../types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  toolResults?: any[];
  safetyBanner?: string;
}

interface GeminiAssistantModalProps {
  onClose: () => void;
  onSelectService: (service: ServiceProvider) => void;
  initialPrompt?: string;
}

const QUICK_PROMPTS = [
  'Find highest-rated hospitals near me',
  'My car broke down; find a garage',
  'What should I do during a flood?',
  'Find 24/7 pharmacies nearby',
  'Nearest emergency shelters',
  'Earthquake preparedness checklist',
];

export const GeminiAssistantModal: React.FC<GeminiAssistantModalProps> = ({
  onClose,
  onSelectService,
  initialPrompt,
}) => {
  const { location } = useLocation();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: `Hello! I am your ResQ Assistant powered by Gemini 3.8 Flash. I can search real verified hospitals, garages, petrol stations, or provide official disaster preparedness guides for ${location.name}. How can I assist you?`,
    },
  ]);
  const [inputText, setInputText] = useState(initialPrompt || '');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    if (initialPrompt) {
      handleSendMessage(initialPrompt);
    }
  }, []);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isLoading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      text,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const history = messages.slice(-4).map((m) => ({
        role: m.role,
        text: m.text,
      }));

      const res = await api.askGeminiAssistant({
        message: text,
        userLat: location.lat,
        userLng: location.lng,
        locationName: location.name,
        conversationHistory: history,
      });

      const assistantMsg: Message = {
        id: `ai-${Date.now()}`,
        role: 'assistant',
        text: res.reply,
        toolResults: res.toolResults,
        safetyBanner: res.safetyBanner,
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `ai-err-${Date.now()}`,
          role: 'assistant',
          text: 'Unable to reach the assistant service right now. For immediate life-safety emergencies, please dial 112 directly.',
          safetyBanner: 'In an immediate life emergency, call 112 or 108.',
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full h-[620px] border border-slate-200 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold">ResQ Assistant</h3>
                <span className="text-[10px] bg-blue-900/80 text-blue-200 px-1.5 py-0.5 rounded-sm font-mono">
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                <MapPin className="w-3 h-3 text-red-400" />
                <span className="truncate max-w-[240px]">{location.name}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Log */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 text-xs leading-relaxed ${
                msg.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.role === 'assistant' && (
                <div className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-3.5 h-3.5" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 space-y-2 shadow-2xs ${
                  msg.role === 'user'
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-800 border border-slate-200'
                }`}
              >
                {/* Safety Banner */}
                {msg.safetyBanner && (
                  <div className="p-2.5 rounded-lg bg-red-50 border border-red-200 text-red-800 text-[11px] font-medium flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
                    <span>{msg.safetyBanner}</span>
                  </div>
                )}

                <div className="whitespace-pre-wrap">{msg.text}</div>

                {/* Tool calling real results badges */}
                {msg.toolResults && msg.toolResults.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-slate-100 space-y-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                      Verified Tool Executions:
                    </span>
                    {msg.toolResults.map((t, idx) => (
                      <div key={idx} className="space-y-1.5">
                        {t.results &&
                          t.results.map((prov: any) => (
                            <button
                              key={prov.id}
                              type="button"
                              onClick={() => onSelectService(prov)}
                              className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 flex items-center justify-between text-[11px] transition-colors"
                            >
                              <div className="truncate">
                                <span className="font-bold text-slate-900">{prov.businessName || prov.name}</span>
                                <span className="text-slate-500 block truncate">{prov.address}</span>
                              </div>
                              <span className="font-semibold text-blue-600 shrink-0 ml-2">Open</span>
                            </button>
                          ))}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {msg.role === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-slate-300 text-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 text-xs">
              <div className="w-7 h-7 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0">
                <Bot className="w-3.5 h-3.5" />
              </div>
              <div className="bg-white p-3 rounded-2xl border border-slate-200 text-slate-500 flex items-center gap-2 shadow-2xs">
                <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-spin" />
                <span>Consulting Gemini Flash &amp; local databases...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="px-4 py-2 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          {QUICK_PROMPTS.map((prompt) => (
            <button
              key={prompt}
              type="button"
              onClick={() => handleSendMessage(prompt)}
              className="px-2.5 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-md transition-colors whitespace-nowrap shrink-0"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask about hospitals, flood precautions, garages, or shelters..."
              className="flex-1 px-4 py-2.5 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-400"
            />
            <button
              type="submit"
              disabled={isLoading || !inputText.trim()}
              className="p-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white rounded-xl transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
