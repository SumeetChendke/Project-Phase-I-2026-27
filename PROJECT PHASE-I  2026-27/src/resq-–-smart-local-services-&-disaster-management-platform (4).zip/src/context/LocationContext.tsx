import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { UserLocation } from '../types';
import { api } from '../services/api';

export const PRESET_LOCATIONS: UserLocation[] = [
  { name: 'Connaught Place, New Delhi', lat: 28.6304, lng: 77.2177, city: 'New Delhi', state: 'Delhi', isGps: false },
  { name: 'Bandra Reclamation, Mumbai', lat: 19.0519, lng: 72.8295, city: 'Mumbai', state: 'Maharashtra', isGps: false },
  { name: 'Indiranagar / HAL, Bengaluru', lat: 12.9587, lng: 77.6496, city: 'Bengaluru', state: 'Karnataka', isGps: false },
  { name: 'Thousand Lights, Chennai', lat: 13.0569, lng: 80.2505, city: 'Chennai', state: 'Tamil Nadu', isGps: false },
  { name: 'Park Street, Kolkata', lat: 22.5535, lng: 88.3518, city: 'Kolkata', state: 'West Bengal', isGps: false },
  { name: 'Shivajinagar, Pune', lat: 18.5314, lng: 73.8446, city: 'Pune', state: 'Maharashtra', isGps: false },
  { name: 'Banjara Hills, Hyderabad', lat: 17.4156, lng: 78.4350, city: 'Hyderabad', state: 'Telangana', isGps: false },
  { name: 'Rajpur Road, Dehradun', lat: 30.3165, lng: 78.0322, city: 'Dehradun', state: 'Uttarakhand', isGps: false },
  { name: 'Puri Coastal Zone, Odisha', lat: 19.8135, lng: 85.8312, city: 'Puri', state: 'Odisha', isGps: false },
];

interface LocationContextType {
  location: UserLocation;
  setLocation: (loc: UserLocation) => void;
  detectGpsLocation: () => Promise<void>;
  isDetecting: boolean;
  gpsError: string | null;
  clearGpsError: () => void;
  isLiveGps: boolean;
  gpsAccuracyMeters: number | null;
  lastUpdated: string | null;
  toggleLiveTracking: () => void;
  isLiveTracking: boolean;
}

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export const LocationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [location, setLocationState] = useState<UserLocation>(() => {
    const saved = localStorage.getItem('resq_selected_location');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return {
      name: 'Detecting Live Location...',
      lat: 28.6304,
      lng: 77.2177,
      city: 'Live Area',
      state: '',
      isGps: false,
    };
  });

  const [isDetecting, setIsDetecting] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [gpsAccuracyMeters, setGpsAccuracyMeters] = useState<number | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [isLiveTracking, setIsLiveTracking] = useState(false);
  const watchIdRef = useRef<number | null>(null);

  const setLocation = (loc: UserLocation) => {
    setLocationState(loc);
    localStorage.setItem('resq_selected_location', JSON.stringify(loc));
    setGpsError(null);
  };

  // Reverse geocodes coordinates and updates state
  const handlePositionSuccess = async (position: GeolocationPosition) => {
    const lat = position.coords.latitude;
    const lng = position.coords.longitude;
    const accuracy = position.coords.accuracy ? Math.round(position.coords.accuracy) : null;
    setGpsAccuracyMeters(accuracy);
    setLastUpdated(new Date().toLocaleTimeString());

    try {
      // Reverse geocode to get actual street / neighborhood / city
      const geo = await api.reverseGeocode(lat, lng);
      const liveLoc: UserLocation = {
        name: `📍 ${geo.name}`,
        lat,
        lng,
        city: geo.city || 'Live Area',
        state: geo.state || '',
        isGps: true,
      };
      setLocation(liveLoc);
    } catch (err) {
      // Fallback display if reverse geocoding API encounters network blip
      const fallbackLoc: UserLocation = {
        name: `📍 Live GPS (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
        lat,
        lng,
        city: 'Current Location',
        state: 'GPS Detected',
        isGps: true,
      };
      setLocation(fallbackLoc);
    } finally {
      setIsDetecting(false);
    }
  };

  const handlePositionError = async (error?: GeolocationPositionError) => {
    setIsDetecting(false);

    // Fallback: Try browser client-side IP location first, then server
    try {
      const res = await fetch('https://ipapi.co/json/', { signal: AbortSignal.timeout(3000) });
      if (res.ok) {
        const data = await res.json();
        if (data.latitude && data.longitude) {
          const clientLoc: UserLocation = {
            name: `📍 ${data.city || data.region || 'Live Area'}, ${data.country_name || ''}`,
            lat: data.latitude,
            lng: data.longitude,
            city: data.city || 'Live Area',
            state: data.region || '',
            isGps: true,
          };
          setLocation(clientLoc);
          return;
        }
      }
    } catch (_clientIpErr) {
      // Try server fallback
      try {
        const ipLoc = await api.getIpLocation();
        if (ipLoc.lat && ipLoc.lng) {
          setLocation({
            name: `📍 ${ipLoc.name} (Detected Location)`,
            lat: ipLoc.lat,
            lng: ipLoc.lng,
            city: ipLoc.city,
            state: ipLoc.state,
            isGps: true,
          });
          return;
        }
      } catch (_e) {
        // fallback to preset
      }
    }

    if (error?.code === error?.PERMISSION_DENIED) {
      setGpsError('GPS permission was denied by browser. Please enable location permissions or select your city.');
    } else if (error?.code === error?.POSITION_UNAVAILABLE) {
      setGpsError('GPS position unavailable. Using nearest detected regional center.');
    } else {
      setGpsError('Location request timed out. Click "Detect Live GPS Location Now" to retry.');
    }
  };

  // Live GPS detection function with two-tier accuracy fallback
  const detectGpsLocation = async () => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      handlePositionError();
      return;
    }

    setIsDetecting(true);
    setGpsError(null);

    // Tier 1: Try high accuracy (mobile GPS / wifi tri-angulation)
    navigator.geolocation.getCurrentPosition(
      handlePositionSuccess,
      (err) => {
        // Tier 2: If high accuracy times out or fails (common on desktop/laptops), retry with standard accuracy
        navigator.geolocation.getCurrentPosition(
          handlePositionSuccess,
          (err2) => {
            handlePositionError(err2);
          },
          {
            timeout: 10000,
            enableHighAccuracy: false,
            maximumAge: 0,
          }
        );
      },
      {
        timeout: 8000,
        enableHighAccuracy: true,
        maximumAge: 0,
      }
    );
  };

  // Continuous live GPS tracking toggle
  const toggleLiveTracking = () => {
    if (isLiveTracking) {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      setIsLiveTracking(false);
    } else {
      if (!navigator.geolocation) {
        setGpsError('Geolocation is not supported by your browser.');
        return;
      }

      setIsLiveTracking(true);
      watchIdRef.current = navigator.geolocation.watchPosition(
        handlePositionSuccess,
        (err) => {
          console.warn('WatchPosition error', err);
        },
        { enableHighAccuracy: true, maximumAge: 10000 }
      );
    }
  };

  // Auto-request live location on mount
  useEffect(() => {
    detectGpsLocation();

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  return (
    <LocationContext.Provider
      value={{
        location,
        setLocation,
        detectGpsLocation,
        isDetecting,
        gpsError,
        clearGpsError: () => setGpsError(null),
        isLiveGps: location.isGps,
        gpsAccuracyMeters,
        lastUpdated,
        toggleLiveTracking,
        isLiveTracking,
      }}
    >
      {children}
    </LocationContext.Provider>
  );
};

export const useLocation = () => {
  const context = useContext(LocationContext);
  if (!context) throw new Error('useLocation must be used within a LocationProvider');
  return context;
};
