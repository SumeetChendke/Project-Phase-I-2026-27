export type ServiceGroup =
  | 'Healthcare'
  | 'Emergency & Safety'
  | 'Vehicles & Transport'
  | 'Daily Essentials'
  | 'Finance & Government'
  | 'Home & Utilities'
  | 'Community & Lifestyle';

export interface ServiceCategory {
  id: string;
  name: string;
  group: ServiceGroup;
  icon: string;
  description: string;
  isEmergency: boolean;
  displayOrder: number;
}

export interface OperatingHours {
  open24Hours?: boolean;
  schedule?: {
    [day: string]: string;
  };
}

export interface ServiceProvider {
  id: string;
  businessName: string;
  primaryCategoryId: string;
  description: string;
  phone: string;
  alternatePhone?: string;
  email?: string;
  website?: string;
  address: string;
  locality: string;
  city: string;
  state: string;
  postalCode?: string;
  latitude: number;
  longitude: number;
  isVerified: boolean;
  isEmergencyService: boolean;
  operatingHours: OperatingHours;
  isOpenNow?: boolean;
  googlePlaceId?: string;
  googleRating?: number | null; // e.g., 4.7
  googleReviewCount?: number | null; // e.g., 850
  googleMapsUri?: string;
  ratingWiseRank?: number;
  platformRating?: number; // e.g., 4.9
  platformReviewCount: number; // e.g., 14
  status: 'active' | 'pending' | 'suspended';
  distanceKm?: number;
  imageUrl?: string;
  servicesOffered?: string[];
}

export interface ServiceBooking {
  id: string;
  userId: string;
  providerId: string;
  providerName: string;
  categoryName: string;
  serviceTitle: string;
  bookingDate: string;
  bookingTime: string;
  status: 'pending' | 'accepted' | 'rejected' | 'cancelled' | 'completed';
  notes?: string;
  contactPhone: string;
  createdAt: string;
}

export interface ServiceReview {
  id: string;
  userId: string;
  userName: string;
  providerId: string;
  rating: number; // 1 to 5
  comment: string;
  isVerifiedVisit: boolean;
  status: 'approved' | 'pending_moderation' | 'flagged' | 'rejected';
  createdAt: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  serviceType: string;
  phoneNumber: string;
  alternateNumber?: string;
  region: string;
  isNational: boolean;
  description: string;
  displayOrder: number;
}

export interface DisasterGuide {
  id: string;
  name: string;
  severityLevel: 'critical' | 'severe' | 'high' | 'advisory';
  icon: string;
  summary: string;
  beforeSteps: string[];
  duringSteps: string[];
  afterSteps: string[];
  emergencyKit: string[];
  vitalContacts: { label: string; number: string }[];
}

export interface DisasterAlert {
  id: string;
  hazardType: string;
  title: string;
  affectedArea: string;
  severity: 'warning' | 'severe' | 'critical' | 'advisory';
  source: string;
  details: string;
  instructions: string;
  issueTime: string;
  expiryTime?: string;
  isActive: boolean;
  verifiedStatus: boolean;
}

export interface ReliefResource {
  id: string;
  name: string;
  resourceType: 'shelter' | 'food_distribution' | 'drinking_water' | 'medical_camp' | 'evacuation_point';
  address: string;
  locality: string;
  city: string;
  latitude: number;
  longitude: number;
  contactPerson?: string;
  contactPhone: string;
  capacity?: number;
  currentOccupancy?: number;
  operatingStatus: 'open' | 'full' | 'standby' | 'closed';
  suppliesAvailable: string[];
  distanceKm?: number;
}

export interface EmergencyReport {
  id: string;
  userId?: string;
  userName?: string;
  reportType: 'disaster_hazard' | 'road_block' | 'incorrect_listing' | 'shortage' | 'other';
  targetProviderId?: string;
  title: string;
  description: string;
  locationName: string;
  latitude?: number;
  longitude?: number;
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  urgency: 'low' | 'medium' | 'high' | 'critical';
  createdAt: string;
}

export interface PreparednessPlan {
  id: string;
  userId: string;
  disasterType: string;
  planTitle: string;
  checklistItems: { id: string; task: string; completed: boolean }[];
  meetingPoint: string;
  emergencyNotes: string;
  isCompleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface UserLocation {
  name: string;
  lat: number;
  lng: number;
  city: string;
  state: string;
  isGps: boolean;
}

export interface AppUser {
  id: string;
  email: string;
  fullName: string;
  role: 'user' | 'provider' | 'moderator' | 'admin';
  phone?: string;
  selectedLocation?: UserLocation;
}
