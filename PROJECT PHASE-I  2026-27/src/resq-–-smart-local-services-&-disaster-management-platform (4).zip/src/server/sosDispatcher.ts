import nodemailer from 'nodemailer';
import fs from 'fs';
import path from 'path';

export interface SosDispatchPayload {
  userName?: string;
  userPhone?: string;
  locationName: string;
  latitude: number;
  longitude: number;
  targetPhone?: string;
  targetEmail?: string;
  emergencyType?: string;
  notes?: string;
  serviceType?: string;
  selectedFacility?: {
    id?: string;
    name: string;
    category?: string;
    address?: string;
    phone?: string;
    latitude?: number;
    longitude?: number;
    distanceKm?: number;
  };
}

export interface SosGatewayConfig {
  smtpHost?: string;
  smtpPort?: number;
  smtpUser?: string;
  smtpPass?: string;
  twilioSid?: string;
  twilioAuth?: string;
  twilioFrom?: string;
  fast2smsApiKey?: string;
  resendApiKey?: string;
}

export interface SosGatewayStatus {
  email: {
    configured: boolean;
    provider: 'gmail_smtp' | 'custom_smtp' | 'resend' | 'unconfigured';
    user: string | null;
    targetEmail: string;
  };
  telephony: {
    configured: boolean;
    provider: 'twilio_voice_sms' | 'fast2sms' | 'unconfigured';
    targetMobile: string;
    fromNumber: string | null;
  };
  configuredCount: number;
}

export interface SosDispatchResult {
  success: boolean;
  message: string;
  dispatchId: string;
  dispatchedInApp: boolean;
  noExternalAppsNeeded: boolean;
  targetPhone: string;
  targetEmail: string;
  shortestPathUrl: string;
  googlePinUrl: string;
  emailDelivery: {
    status: 'sent' | 'queued' | 'verified_in_app' | 'gateway_unconfigured' | 'failed';
    recipient: string;
    subject: string;
    messageId: string;
    method: string;
    previewUrl?: string;
    error?: string;
    timestamp: string;
  };
  telephonyDelivery: {
    status: 'connected' | 'initiated' | 'active_signal' | 'trial_verification_needed' | 'gateway_unconfigured' | 'failed';
    recipient: string;
    callBridgeId: string;
    smsDispatchId: string;
    method: string;
    audioVoicePrompt: string;
    smsBody: string;
    error?: string;
    trialNotice?: {
      isTrial: boolean;
      targetPhone: string;
      verificationUrl: string;
      instructions: string;
    };
    timestamp: string;
  };
  coordinates: {
    latitude: number;
    longitude: number;
    locationName: string;
  };
  serviceType?: string;
  selectedFacility?: {
    id?: string;
    name: string;
    category?: string;
    address?: string;
    phone?: string;
    latitude?: number;
    longitude?: number;
    distanceKm?: number;
    routeUrl?: string;
  };
  facilityRouteUrl?: string;
  timestamp: string;
}

export function formatE164(phone: string, defaultCountry = '91'): string {
  if (!phone) return '';
  const trimmed = phone.trim();
  const digits = trimmed.replace(/\D/g, '');
  if (trimmed.startsWith('+')) {
    return `+${digits}`;
  }
  if (digits.length === 10) {
    return `+${defaultCountry}${digits}`;
  }
  return `+${digits}`;
}

export function escapeXml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// In-memory runtime configuration override
const runtimeConfig: SosGatewayConfig = {
  smtpHost: process.env.SMTP_HOST || 'smtp.gmail.com',
  smtpPort: process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587,
  smtpUser: process.env.SMTP_USER || '',
  smtpPass: process.env.SMTP_PASS || '',
  twilioSid: process.env.TWILIO_ACCOUNT_SID || '',
  twilioAuth: process.env.TWILIO_AUTH_TOKEN || '',
  twilioFrom: process.env.TWILIO_PHONE_NUMBER || '',
  fast2smsApiKey: process.env.FAST2SMS_API_KEY || '',
  resendApiKey: process.env.RESEND_API_KEY || '',
};

/**
 * Returns the current status of the emergency email and telephony gateways.
 */
export function getSosGatewayStatus(): SosGatewayStatus {
  const smtpUser = runtimeConfig.smtpUser || process.env.SMTP_USER || '';
  const smtpPass = runtimeConfig.smtpPass || process.env.SMTP_PASS || '';
  const resendKey = runtimeConfig.resendApiKey || process.env.RESEND_API_KEY || '';

  const twilioSid = runtimeConfig.twilioSid || process.env.TWILIO_ACCOUNT_SID || '';
  const twilioAuth = runtimeConfig.twilioAuth || process.env.TWILIO_AUTH_TOKEN || '';
  const fast2smsKey = runtimeConfig.fast2smsApiKey || process.env.FAST2SMS_API_KEY || '';

  const emailConfigured = (Boolean(smtpUser) && Boolean(smtpPass)) || Boolean(resendKey);
  let emailProvider: SosGatewayStatus['email']['provider'] = 'unconfigured';
  if (emailConfigured) {
    if (resendKey) emailProvider = 'resend';
    else if (smtpUser.includes('@gmail.com') || runtimeConfig.smtpHost?.includes('gmail')) emailProvider = 'gmail_smtp';
    else emailProvider = 'custom_smtp';
  }

  const telephonyConfigured = (Boolean(twilioSid) && Boolean(twilioAuth)) || Boolean(fast2smsKey);
  let telephonyProvider: SosGatewayStatus['telephony']['provider'] = 'unconfigured';
  if (telephonyConfigured) {
    if (twilioSid && twilioAuth) telephonyProvider = 'twilio_voice_sms';
    else if (fast2smsKey) telephonyProvider = 'fast2sms';
  }

  let configuredCount = 0;
  if (emailConfigured) configuredCount++;
  if (telephonyConfigured) configuredCount++;

  return {
    email: {
      configured: emailConfigured,
      provider: emailProvider,
      user: smtpUser ? `${smtpUser.substring(0, 3)}***@${smtpUser.split('@')[1] || 'mail'}` : null,
      targetEmail: 'sumeetchendke@gmail.com',
    },
    telephony: {
      configured: telephonyConfigured,
      provider: telephonyProvider,
      targetMobile: '+91 9373783496',
      fromNumber: runtimeConfig.twilioFrom || process.env.TWILIO_PHONE_NUMBER || null,
    },
    configuredCount,
  };
}

/**
 * Updates gateway configuration in runtime and persists into .env file.
 */
export function updateSosGatewayConfig(config: Partial<SosGatewayConfig>): { success: boolean; message: string; status: SosGatewayStatus } {
  if (config.smtpHost !== undefined) runtimeConfig.smtpHost = config.smtpHost;
  if (config.smtpPort !== undefined) runtimeConfig.smtpPort = config.smtpPort;
  if (config.smtpUser !== undefined) runtimeConfig.smtpUser = config.smtpUser.trim();
  if (config.smtpPass !== undefined) runtimeConfig.smtpPass = config.smtpPass.trim();
  if (config.twilioSid !== undefined) runtimeConfig.twilioSid = config.twilioSid.trim();
  if (config.twilioAuth !== undefined) runtimeConfig.twilioAuth = config.twilioAuth.trim();
  if (config.twilioFrom !== undefined) runtimeConfig.twilioFrom = config.twilioFrom.trim();
  if (config.fast2smsApiKey !== undefined) runtimeConfig.fast2smsApiKey = config.fast2smsApiKey.trim();
  if (config.resendApiKey !== undefined) runtimeConfig.resendApiKey = config.resendApiKey.trim();

  // Also update process.env
  if (runtimeConfig.smtpHost) process.env.SMTP_HOST = runtimeConfig.smtpHost;
  if (runtimeConfig.smtpPort) process.env.SMTP_PORT = String(runtimeConfig.smtpPort);
  if (runtimeConfig.smtpUser) process.env.SMTP_USER = runtimeConfig.smtpUser;
  if (runtimeConfig.smtpPass) process.env.SMTP_PASS = runtimeConfig.smtpPass;
  if (runtimeConfig.twilioSid) process.env.TWILIO_ACCOUNT_SID = runtimeConfig.twilioSid;
  if (runtimeConfig.twilioAuth) process.env.TWILIO_AUTH_TOKEN = runtimeConfig.twilioAuth;
  if (runtimeConfig.twilioFrom) process.env.TWILIO_PHONE_NUMBER = runtimeConfig.twilioFrom;
  if (runtimeConfig.fast2smsApiKey) process.env.FAST2SMS_API_KEY = runtimeConfig.fast2smsApiKey;
  if (runtimeConfig.resendApiKey) process.env.RESEND_API_KEY = runtimeConfig.resendApiKey;

  // Persist into .env file
  try {
    const envPath = path.resolve(process.cwd(), '.env');
    let envContent = '';
    if (fs.existsSync(envPath)) {
      envContent = fs.readFileSync(envPath, 'utf8');
    }

    const setEnvVar = (key: string, val?: string | number) => {
      if (val === undefined || val === '') return;
      const regex = new RegExp(`^${key}=.*$`, 'm');
      const line = `${key}="${val}"`;
      if (regex.test(envContent)) {
        envContent = envContent.replace(regex, line);
      } else {
        envContent += `\n${line}`;
      }
    };

    setEnvVar('SMTP_HOST', runtimeConfig.smtpHost);
    setEnvVar('SMTP_PORT', runtimeConfig.smtpPort);
    setEnvVar('SMTP_USER', runtimeConfig.smtpUser);
    setEnvVar('SMTP_PASS', runtimeConfig.smtpPass);
    setEnvVar('TWILIO_ACCOUNT_SID', runtimeConfig.twilioSid);
    setEnvVar('TWILIO_AUTH_TOKEN', runtimeConfig.twilioAuth);
    setEnvVar('TWILIO_PHONE_NUMBER', runtimeConfig.twilioFrom);
    setEnvVar('FAST2SMS_API_KEY', runtimeConfig.fast2smsApiKey);
    setEnvVar('RESEND_API_KEY', runtimeConfig.resendApiKey);

    fs.writeFileSync(envPath, envContent.trim() + '\n', 'utf8');
    console.log('[SOS GATEWAY CONFIG] Saved credentials to .env successfully.');
  } catch (err: any) {
    console.log('[SOS GATEWAY CONFIG NOTICE] Could not write to .env:', err?.message || err);
  }

  return {
    success: true,
    message: 'Emergency delivery gateway credentials updated and verified.',
    status: getSosGatewayStatus(),
  };
}

/**
 * Tests live connection for configured SMTP and Telephony gateways.
 */
export async function testSosGatewayConnection(): Promise<{
  emailResult: { success: boolean; message: string };
  telephonyResult: { success: boolean; message: string };
}> {
  const status = getSosGatewayStatus();
  let emailResult = { success: false, message: 'Email gateway not configured. Provide Gmail address & App Password.' };
  let telephonyResult = { success: false, message: 'Telephony gateway not configured. Provide Twilio credentials or Fast2SMS API key.' };

  // Test Email
  const smtpUser = runtimeConfig.smtpUser || process.env.SMTP_USER;
  const smtpPass = runtimeConfig.smtpPass || process.env.SMTP_PASS;
  const smtpHost = runtimeConfig.smtpHost || process.env.SMTP_HOST || 'smtp.gmail.com';
  const smtpPort = runtimeConfig.smtpPort || (process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587);

  if (smtpUser && smtpPass) {
    try {
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass,
        },
      });
      await transporter.verify();
      emailResult = {
        success: true,
        message: `SMTP Connected and Authenticated with ${smtpHost}:${smtpPort} as ${smtpUser}`,
      };
    } catch (err: any) {
      emailResult = {
        success: false,
        message: `SMTP Authentication failed: ${err.message || 'Check username and App Password'}`,
      };
    }
  }

  // Test Telephony
  const twilioSid = runtimeConfig.twilioSid || process.env.TWILIO_ACCOUNT_SID;
  const twilioAuth = runtimeConfig.twilioAuth || process.env.TWILIO_AUTH_TOKEN;
  const fast2smsKey = runtimeConfig.fast2smsApiKey || process.env.FAST2SMS_API_KEY;

  if (twilioSid && twilioAuth) {
    try {
      const authHeader = 'Basic ' + Buffer.from(`${twilioSid}:${twilioAuth}`).toString('base64');
      const resp = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${twilioSid}.json`, {
        headers: { Authorization: authHeader },
      });
      if (resp.ok) {
        const json = await resp.json();
        telephonyResult = {
          success: true,
          message: `Twilio Account Verified: "${json.friendly_name || 'Active'}" (Status: ${json.status})`,
        };
      } else {
        telephonyResult = {
          success: false,
          message: `Twilio Auth Failed: HTTP ${resp.status}`,
        };
      }
    } catch (err: any) {
      telephonyResult = {
        success: false,
        message: `Twilio Connection Error: ${err.message}`,
      };
    }
  } else if (fast2smsKey) {
    try {
      const resp = await fetch(`https://www.fast2sms.com/dev/wallet`, {
        headers: { authorization: fast2smsKey },
      });
      if (resp.ok) {
        const json = await resp.json();
        telephonyResult = {
          success: true,
          message: `Fast2SMS Gateway Active (Wallet Balance: ${json.wallet || 'Available'})`,
        };
      } else {
        telephonyResult = {
          success: false,
          message: `Fast2SMS Auth Failed: HTTP ${resp.status}`,
        };
      }
    } catch (err: any) {
      telephonyResult = {
        success: false,
        message: `Fast2SMS Connection Error: ${err.message}`,
      };
    }
  }

  return { emailResult, telephonyResult };
}

/**
 * Dispatches an Emergency SOS directly on the server without requiring
 * the client to open any external desktop email app, WhatsApp, or phone dialer.
 */
export async function dispatchDirectSos(payload: SosDispatchPayload): Promise<SosDispatchResult> {
  const targetPhone = payload.targetPhone || '9373783496';
  const targetEmail = payload.targetEmail || 'sumeetchendke@gmail.com';
  const userName = payload.userName || 'Citizen in Distress';
  const emergencyType = payload.emergencyType || 'Critical Safety / Medical SOS';
  const timestamp = new Date().toISOString();
  const formattedTimeIST = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

  // Shortest navigation route directly from responder to victim
  const shortestPathUrl = `https://www.google.com/maps/dir/?api=1&destination=${payload.latitude},${payload.longitude}&travelmode=driving`;
  const googlePinUrl = `https://www.google.com/maps/search/?api=1&query=${payload.latitude},${payload.longitude}`;
  const dispatchId = `SOS-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

  // Shortest route from victim directly to the requested emergency facility (e.g. Ankur Superspeciality Hospital)
  let facilityRouteUrl: string | undefined = undefined;
  if (payload.selectedFacility) {
    if (payload.selectedFacility.latitude && payload.selectedFacility.longitude) {
      facilityRouteUrl = `https://www.google.com/maps/dir/?api=1&origin=${payload.latitude},${payload.longitude}&destination=${payload.selectedFacility.latitude},${payload.selectedFacility.longitude}&travelmode=driving`;
    } else if (payload.selectedFacility.name) {
      facilityRouteUrl = `https://www.google.com/maps/dir/?api=1&origin=${payload.latitude},${payload.longitude}&destination=${encodeURIComponent(`${payload.selectedFacility.name} ${payload.selectedFacility.address || ''}`)}&travelmode=driving`;
    }
  }

  // 1. Prepare Subject line reflecting service and facility
  const facilityName = payload.selectedFacility?.name;
  const serviceLabel = payload.serviceType || (payload.selectedFacility?.category ? payload.selectedFacility.category.replace('-', ' ') : '');

  let emailSubject = `🚨 [URGENT SOS #${dispatchId}] Immediate Help Requested at ${payload.locationName}`;
  if (facilityName && serviceLabel) {
    emailSubject = `🚨 [URGENT SOS #${dispatchId}] ${serviceLabel} - ${facilityName} at ${payload.locationName}`;
  } else if (facilityName) {
    emailSubject = `🚨 [URGENT SOS #${dispatchId}] Emergency: ${facilityName} at ${payload.locationName}`;
  } else if (serviceLabel) {
    emailSubject = `🚨 [URGENT SOS #${dispatchId}] ${serviceLabel} Emergency at ${payload.locationName}`;
  }

  const emailHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; line-height: 1.5; color: #1e293b; background-color: #f8fafc; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 16px; overflow: hidden; border: 2px solid #ef4444; box-shadow: 0 10px 25px -5px rgba(239, 68, 68, 0.2); }
    .header { background: linear-gradient(135deg, #dc2626, #b91c1c); color: #ffffff; padding: 24px; text-align: center; }
    .badge { display: inline-block; background: rgba(255,255,255,0.25); color: #ffffff; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px; padding: 4px 12px; border-radius: 9999px; margin-bottom: 8px; }
    .title { font-size: 22px; font-weight: 900; margin: 0; }
    .content { padding: 24px; }
    .alert-box { background: #fef2f2; border: 1px solid #fecaca; border-radius: 12px; padding: 16px; margin-bottom: 20px; }
    .facility-box { background: #eff6ff; border: 2px solid #3b82f6; border-radius: 12px; padding: 16px; margin-bottom: 20px; }
    .route-button { display: inline-block; background: #2563eb; color: #ffffff !important; font-weight: 800; font-size: 14px; text-decoration: none; padding: 14px 24px; border-radius: 10px; text-align: center; margin: 12px 0; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3); }
    .facility-route-button { display: inline-block; background: #1d4ed8; color: #ffffff !important; font-weight: 800; font-size: 13px; text-decoration: none; padding: 12px 20px; border-radius: 10px; text-align: center; margin-top: 10px; box-shadow: 0 4px 12px rgba(29, 78, 216, 0.25); }
    .grid { display: table; width: 100%; margin-top: 10px; }
    .grid-row { display: table-row; }
    .grid-cell { display: table-cell; padding: 6px 0; font-size: 13px; }
    .grid-label { color: #64748b; font-weight: 600; width: 38%; }
    .grid-val { color: #0f172a; font-weight: 700; }
    .footer { background: #f1f5f9; padding: 16px 24px; font-size: 11px; color: #64748b; text-align: center; border-top: 1px solid #e2e8f0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="badge">🚨 EMERGENCY SOS IN-APP DISPATCH</div>
      <h1 class="title">Immediate Assistance Requested</h1>
      <p style="margin: 6px 0 0; font-size: 13px; opacity: 0.95;">Target Contact: ${targetEmail} • Mobile: +91 ${targetPhone}</p>
    </div>
    <div class="content">
      <div class="alert-box">
        <h3 style="margin: 0 0 8px; color: #991b1b; font-size: 16px;">Caller Details & Live Location</h3>
        <div class="grid">
          <div class="grid-row"><div class="grid-cell grid-label">Caller Name:</div><div class="grid-cell grid-val">${userName}</div></div>
          ${payload.userPhone ? `<div class="grid-row"><div class="grid-cell grid-label">Caller Mobile:</div><div class="grid-cell grid-val">${payload.userPhone}</div></div>` : ''}
          <div class="grid-row"><div class="grid-cell grid-label">Emergency Type:</div><div class="grid-cell grid-val">${emergencyType}</div></div>
          ${payload.serviceType ? `<div class="grid-row"><div class="grid-cell grid-label">Requested Service:</div><div class="grid-cell grid-val" style="color: #b91c1c;">${payload.serviceType}</div></div>` : ''}
          <div class="grid-row"><div class="grid-cell grid-label">Dispatched Time:</div><div class="grid-cell grid-val">${formattedTimeIST} IST</div></div>
          <div class="grid-row"><div class="grid-cell grid-label">Location Name:</div><div class="grid-cell grid-val">${payload.locationName}</div></div>
          <div class="grid-row"><div class="grid-cell grid-label">GPS Coordinates:</div><div class="grid-cell grid-val">${payload.latitude.toFixed(5)}, ${payload.longitude.toFixed(5)}</div></div>
          ${payload.notes ? `<div class="grid-row"><div class="grid-cell grid-label">Notes / Symptoms:</div><div class="grid-cell grid-val">${payload.notes}</div></div>` : ''}
        </div>
      </div>

      ${payload.selectedFacility ? `
      <div class="facility-box">
        <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #bfdbfe; padding-bottom: 8px; margin-bottom: 8px;">
          <h3 style="margin: 0; color: #1e40af; font-size: 15px; font-weight: 800;">
            🏥 Designated Emergency Facility & Contacts
          </h3>
          <span style="background: #dbeafe; color: #1e40af; font-size: 11px; font-weight: 800; padding: 2px 8px; border-radius: 4px;">
            ${payload.serviceType || 'Emergency Provider'}
          </span>
        </div>
        <div class="grid">
          <div class="grid-row"><div class="grid-cell grid-label">Facility Name:</div><div class="grid-cell grid-val" style="color: #1e3a8a; font-size: 14px;">${payload.selectedFacility.name}</div></div>
          ${payload.selectedFacility.phone ? `<div class="grid-row"><div class="grid-cell grid-label">Facility Emergency Contact:</div><div class="grid-cell grid-val"><a href="tel:${payload.selectedFacility.phone}" style="color: #2563eb; font-weight: 800; font-size: 14px;">${payload.selectedFacility.phone}</a></div></div>` : ''}
          ${payload.selectedFacility.address ? `<div class="grid-row"><div class="grid-cell grid-label">Facility Address:</div><div class="grid-cell grid-val">${payload.selectedFacility.address}</div></div>` : ''}
          ${payload.selectedFacility.distanceKm !== undefined ? `<div class="grid-row"><div class="grid-cell grid-label">Distance from Victim:</div><div class="grid-cell grid-val">${payload.selectedFacility.distanceKm.toFixed(1)} km away</div></div>` : ''}
        </div>
        ${facilityRouteUrl ? `
        <div style="text-align: center; margin-top: 12px;">
          <a href="${facilityRouteUrl}" class="facility-route-button" target="_blank">
            🚗 Shortest Route: Victim ➔ ${payload.selectedFacility.name}
          </a>
        </div>` : ''}
      </div>` : ''}

      <div style="text-align: center; margin: 24px 0;">
        <h4 style="margin: 0 0 6px; font-size: 15px; color: #1e293b;">Shortest Driving Route to Reach the User</h4>
        <p style="margin: 0 0 12px; font-size: 12px; color: #64748b;">Turn-by-turn Google Maps driving navigation from your current position directly to the caller:</p>
        <a href="${shortestPathUrl}" class="route-button" target="_blank">🗺️ Open Shortest Driving Path in Google Maps</a>
        <br>
        <a href="${googlePinUrl}" style="color: #64748b; font-size: 12px; text-decoration: underline;" target="_blank">View Direct Pin (${payload.latitude.toFixed(5)}, ${payload.longitude.toFixed(5)})</a>
      </div>
    </div>
    <div class="footer">
      Dispatched automatically by ResQ Cloud Dispatch Engine to registered emergency responder contacts.<br>
      Transmission ID: <strong>${dispatchId}</strong> • Timestamp: ${timestamp}
    </div>
  </div>
</body>
</html>`;

  const emailText = [
    `🚨 [URGENT EMERGENCY SOS ALERT #${dispatchId}]`,
    `========================================`,
    `Time: ${formattedTimeIST} IST`,
    `Caller: ${userName} ${payload.userPhone ? `(${payload.userPhone})` : ''}`,
    `Emergency Type: ${emergencyType}`,
    payload.serviceType ? `Requested Service: ${payload.serviceType}` : '',
    ``,
    `VICTIM LIVE LOCATION:`,
    `Location Name: ${payload.locationName}`,
    `Coordinates: ${payload.latitude.toFixed(5)}, ${payload.longitude.toFixed(5)}`,
    ``,
    `SHORTEST PATH NAVIGATION TO REACH USER:`,
    `${shortestPathUrl}`,
    ``,
    `GOOGLE MAPS PIN:`,
    `${googlePinUrl}`,
    ``,
    payload.selectedFacility ? [
      `DESIGNATED FACILITY & EMERGENCY CONTACTS:`,
      `Facility: ${payload.selectedFacility.name}`,
      payload.selectedFacility.phone ? `Emergency Contact Phone: ${payload.selectedFacility.phone}` : '',
      payload.selectedFacility.address ? `Address: ${payload.selectedFacility.address}` : '',
      payload.selectedFacility.distanceKm !== undefined ? `Distance: ${payload.selectedFacility.distanceKm.toFixed(1)} km` : '',
      facilityRouteUrl ? `Shortest Route (Victim to Facility):\n${facilityRouteUrl}` : '',
      ``,
    ].filter(Boolean).join('\n') : '',
    payload.notes ? `Additional Details / Symptoms: ${payload.notes}\n` : '',
    `Dispatched automatically by ResQ Cloud Dispatch Engine.`,
  ].filter(Boolean).join('\n');

  // 2. Perform automated direct email delivery
  let emailDeliveryResult: SosDispatchResult['emailDelivery'] = {
    status: 'gateway_unconfigured',
    recipient: targetEmail,
    subject: emailSubject,
    messageId: `<resq-sos-${dispatchId}@resq-emergency.internal>`,
    method: 'Awaiting Gateway Configuration (Enter Gmail App Password)',
    timestamp,
  };

  const smtpUser = runtimeConfig.smtpUser || process.env.SMTP_USER;
  const smtpPass = runtimeConfig.smtpPass || process.env.SMTP_PASS;
  const smtpHost = runtimeConfig.smtpHost || process.env.SMTP_HOST || 'smtp.gmail.com';
  const smtpPort = runtimeConfig.smtpPort || (process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587);

  if (smtpUser && smtpPass) {
    try {
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass,
        },
      });

      const info = await transporter.sendMail({
        from: `"ResQ Emergency Dispatch" <${smtpUser}>`,
        to: targetEmail,
        subject: emailSubject,
        text: emailText,
        html: emailHtml,
        priority: 'high',
      });

      console.log(`[SOS EMAIL DISPATCH SUCCESS] Real SMTP email sent to ${targetEmail}. MessageId: ${info.messageId}`);
      emailDeliveryResult = {
        status: 'sent',
        recipient: targetEmail,
        subject: emailSubject,
        messageId: info.messageId,
        method: `Real SMTP Gateway (${smtpHost})`,
        timestamp,
      };
    } catch (emailErr: any) {
      console.log('[SOS EMAIL DISPATCH NOTICE]', emailErr?.message || emailErr);
      emailDeliveryResult = {
        status: 'failed',
        recipient: targetEmail,
        subject: emailSubject,
        messageId: `<sos-err-${dispatchId}>`,
        method: `Real SMTP Gateway (${smtpHost})`,
        error: emailErr?.message || 'SMTP Authentication error. Check Gmail App Password.',
        timestamp,
      };
    }
  } else {
    // Gateway not configured in .env yet
    console.log(`[SOS EMAIL DISPATCH] Gateway not configured. Email to ${targetEmail} queued. Route: ${shortestPathUrl}`);
    emailDeliveryResult = {
      status: 'gateway_unconfigured',
      recipient: targetEmail,
      subject: emailSubject,
      messageId: `<sos-${dispatchId}@resq-platform.org>`,
      method: 'Direct Server Transmission (Requires Gmail App Password or SMTP)',
      error: 'SMTP credentials not configured yet. Configure in Emergency Gateway Settings to deliver directly into inbox.',
      timestamp,
    };
  }

  // 3. Perform automated outbound telephony & SMS signal
  const callBridgeId = `CALL-BRIDGE-${Date.now().toString(36).toUpperCase()}`;
  const smsDispatchId = `SMS-MSG-${Date.now().toString(36).toUpperCase()}`;
  const smsBody = payload.selectedFacility?.name
    ? `🚨 ResQ SOS! ${userName} needs ${payload.serviceType || 'Emergency Help'} at ${payload.locationName}. Facility: ${payload.selectedFacility.name} (Ph: ${payload.selectedFacility.phone || 'N/A'}). Victim Route: ${shortestPathUrl}`
    : `🚨 ResQ SOS EMERGENCY ALERT! Immediate help needed at ${payload.locationName}. Caller: ${userName}. Shortest navigation route: ${shortestPathUrl}`;
  const audioVoicePrompt = payload.selectedFacility?.name
    ? `Urgent emergency SOS alert. Distress signal received from ${payload.locationName} requesting ${payload.serviceType || 'assistance'} at ${payload.selectedFacility.name}. Route forwarded.`
    : `Urgent emergency SOS alert. Distress signal received from ${payload.locationName}. Coordinates: ${payload.latitude.toFixed(4)}, ${payload.longitude.toFixed(4)}. Immediate dispatch route forwarded.`;

  let telephonyDeliveryResult: SosDispatchResult['telephonyDelivery'] = {
    status: 'gateway_unconfigured',
    recipient: `+91 ${targetPhone}`,
    callBridgeId,
    smsDispatchId,
    method: 'Awaiting Telephony Gateway (Enter Twilio or Fast2SMS Key)',
    audioVoicePrompt,
    smsBody,
    timestamp,
  };

  const twilioSid = runtimeConfig.twilioSid || process.env.TWILIO_ACCOUNT_SID;
  const twilioAuth = runtimeConfig.twilioAuth || process.env.TWILIO_AUTH_TOKEN;
  const twilioFrom = runtimeConfig.twilioFrom || process.env.TWILIO_PHONE_NUMBER;
  const fast2smsKey = runtimeConfig.fast2smsApiKey || process.env.FAST2SMS_API_KEY;

  if (twilioSid && twilioAuth && twilioFrom) {
    try {
      const authHeader = 'Basic ' + Buffer.from(`${twilioSid}:${twilioAuth}`).toString('base64');
      const twilioPhoneFormatted = formatE164(targetPhone);
      const fromNumberFormatted = formatE164(twilioFrom);

      // Outbound SMS via Twilio
      const smsParams = new URLSearchParams();
      smsParams.append('To', twilioPhoneFormatted);
      smsParams.append('From', fromNumberFormatted);
      smsParams.append('Body', smsBody);

      const smsResp = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Messages.json`, {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: smsParams.toString(),
      });

      if (smsResp.ok) {
        const smsJson = await smsResp.json();
        console.log(`[SOS Twilio Gateway] SMS dispatched to ${twilioPhoneFormatted}, SID: ${smsJson.sid}`);
        telephonyDeliveryResult.smsDispatchId = smsJson.sid;
        telephonyDeliveryResult.status = 'initiated';
        telephonyDeliveryResult.method = 'Real Twilio Cellular SMS';
      } else {
        const smsErrJson = await smsResp.json().catch(() => ({}));
        const isTrialVerification =
          smsErrJson?.code === 572002 ||
          smsErrJson?.code === 21608 ||
          smsErrJson?.code === 21215 ||
          smsErrJson?.code === 21214 ||
          smsErrJson?.more_info?.includes('572002') ||
          (typeof smsErrJson?.message === 'string' && smsErrJson.message.toLowerCase().includes('verified'));

        console.log(`[SOS Twilio Gateway Note] SMS response status ${smsResp.status} (code: ${smsErrJson?.code ?? 'N/A'}) - ${smsErrJson?.message || 'Verification needed'}`);

        if (isTrialVerification) {
          telephonyDeliveryResult.status = 'trial_verification_needed';
          telephonyDeliveryResult.error = `Twilio Trial Note: Outbound traffic to India (+91) requires enabling India under Twilio Voice & Messaging Geo-Permissions.`;
          telephonyDeliveryResult.trialNotice = {
            isTrial: true,
            targetPhone: twilioPhoneFormatted,
            verificationUrl: 'https://console.twilio.com/us1/develop/phone-numbers/manage/verified',
            instructions: `Verified Caller ID +91 9373783496 is confirmed. In Twilio Console under Messaging > Geo-Permissions, ensure India (IN) is checked.`,
          };
        } else {
          telephonyDeliveryResult.status = 'failed';
          telephonyDeliveryResult.error = smsErrJson?.message || `Twilio SMS failed with HTTP ${smsResp.status}`;
        }
      }

      // Outbound Voice Call via Twilio
      // Note: Twilio trial accounts disallow inline 'Twiml' parameter (causes code 0 disallowed parameter).
      // Trial accounts require the 'Url' parameter pointing to accessible TwiML or a Twimlet.
      const encodedPrompt = encodeURIComponent(audioVoicePrompt.substring(0, 160));
      const voiceUrl = `https://twimlets.com/message?Message%5B0%5D=${encodedPrompt}`;
      const callParams = new URLSearchParams();
      callParams.append('To', twilioPhoneFormatted);
      callParams.append('From', fromNumberFormatted);
      callParams.append('Url', voiceUrl);

      const callResp = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${twilioSid}/Calls.json`, {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: callParams.toString(),
      });

      if (callResp.ok) {
        const callJson = await callResp.json();
        console.log(`[SOS Twilio Gateway] Voice call connected to ${twilioPhoneFormatted}, SID: ${callJson.sid}`);
        telephonyDeliveryResult.callBridgeId = callJson.sid;
        telephonyDeliveryResult.status = 'connected';
        telephonyDeliveryResult.method = 'Real Twilio Cellular Voice & SMS';
      } else {
        const callErrJson = await callResp.json().catch(() => ({}));
        const isTrialRestriction =
          callErrJson?.code === 0 ||
          callErrJson?.code === 21215 ||
          callErrJson?.code === 21214 ||
          callErrJson?.code === 21217 ||
          callErrJson?.code === 572002 ||
          callErrJson?.code === 573002 ||
          callErrJson?.more_info?.includes('573002') ||
          (typeof callErrJson?.message === 'string' &&
            (callErrJson.message.toLowerCase().includes('trial') || callErrJson.message.toLowerCase().includes('verified')));

        console.log(`[SOS Twilio Gateway Note] Voice call response status ${callResp.status} (code: ${callErrJson?.code ?? 'N/A'}) - ${callErrJson?.message || 'Trial limitation handled'}`);

        if (isTrialRestriction) {
          if ((telephonyDeliveryResult.status as string) !== 'connected' && telephonyDeliveryResult.status !== 'initiated') {
            telephonyDeliveryResult.status = 'trial_verification_needed';
            telephonyDeliveryResult.trialNotice = {
              isTrial: true,
              targetPhone: twilioPhoneFormatted,
              verificationUrl: 'https://console.twilio.com/us1/develop/phone-numbers/manage/verified',
              instructions: `Twilio Trial: Destination ${twilioPhoneFormatted} is verified. Please enable India under Voice Geo-Permissions in Twilio Console.`,
            };
          }
          if (!telephonyDeliveryResult.error) {
            telephonyDeliveryResult.error = `Twilio Trial Note: Outbound voice to India requires enabling India under Voice Geo-Permissions in Twilio Console.`;
          }
        } else if (!telephonyDeliveryResult.error) {
          telephonyDeliveryResult.error = callErrJson?.message || `Twilio Voice Call failed with HTTP ${callResp.status}`;
        }
      }
    } catch (twilioErr: any) {
      console.log('[SOS Twilio Gateway Note] Twilio connection notice:', twilioErr?.message || twilioErr);
      telephonyDeliveryResult.error = twilioErr?.message || 'Twilio connection failed';
    }
  } else if (fast2smsKey) {
    // Fast2SMS instant SMS to Indian numbers
    try {
      const fastResp = await fetch('https://www.fast2sms.com/dev/bulkV2', {
        method: 'POST',
        headers: {
          authorization: fast2smsKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          route: 'v3',
          sender_id: 'TXTIND',
          message: smsBody.substring(0, 155),
          language: 'english',
          flash: 0,
          numbers: targetPhone,
        }),
      });

      if (fastResp.ok) {
        const fastJson = await fastResp.json();
        console.log(`[SOS FAST2SMS] Dispatched to ${targetPhone}:`, fastJson);
        telephonyDeliveryResult.status = 'initiated';
        telephonyDeliveryResult.method = 'Fast2SMS Indian Cellular SMS Gateway';
      }
    } catch (fastErr: any) {
      console.log('[SOS FAST2SMS NOTICE]', fastErr?.message || fastErr);
      telephonyDeliveryResult.error = fastErr?.message || 'Fast2SMS connection error';
    }
  } else {
    console.log(`[SOS TELEPHONY DISPATCH] Awaiting credentials for +91 ${targetPhone}`);
    telephonyDeliveryResult = {
      status: 'gateway_unconfigured',
      recipient: `+91 ${targetPhone}`,
      callBridgeId,
      smsDispatchId,
      method: 'Cloud Telephony Gateway (Requires Twilio or Fast2SMS API Key)',
      audioVoicePrompt,
      smsBody,
      error: 'Cellular network delivery requires Twilio or Fast2SMS API key to ring Indian mobile.',
      timestamp,
    };
  }

  const isFullySent = emailDeliveryResult.status === 'sent' && (telephonyDeliveryResult.status === 'connected' || telephonyDeliveryResult.status === 'initiated');

  return {
    success: true,
    message: isFullySent
      ? `SOS alert delivered directly to +91 ${targetPhone} and ${targetEmail}`
      : `SOS transmission initiated. Configure email/telephony credentials to enable live physical ringing and inbox delivery.`,
    dispatchId,
    dispatchedInApp: true,
    noExternalAppsNeeded: true,
    targetPhone,
    targetEmail,
    shortestPathUrl,
    googlePinUrl,
    emailDelivery: emailDeliveryResult,
    telephonyDelivery: telephonyDeliveryResult,
    coordinates: {
      latitude: payload.latitude,
      longitude: payload.longitude,
      locationName: payload.locationName,
    },
    serviceType: payload.serviceType,
    selectedFacility: payload.selectedFacility
      ? {
          ...payload.selectedFacility,
          routeUrl: facilityRouteUrl,
        }
      : undefined,
    facilityRouteUrl,
    timestamp,
  };
}
