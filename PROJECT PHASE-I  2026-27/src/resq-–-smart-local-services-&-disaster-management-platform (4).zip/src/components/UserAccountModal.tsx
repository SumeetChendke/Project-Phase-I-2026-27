import React, { useState, useEffect } from 'react';
import {
  X,
  Bookmark,
  Calendar,
  Star,
  ShieldAlert,
  Phone,
  Clock,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  User,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { ServiceProvider, ServiceBooking, ServiceReview, EmergencyReport } from '../types';

interface UserAccountModalProps {
  initialTab?: string;
  onClose: () => void;
  onSelectService: (service: ServiceProvider) => void;
}

export const UserAccountModal: React.FC<UserAccountModalProps> = ({
  initialTab = 'favorites',
  onClose,
  onSelectService,
}) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'favorites' | 'bookings' | 'reports' | 'plan'>(
    (initialTab as any) || 'favorites'
  );

  const [favorites, setFavorites] = useState<ServiceProvider[]>([]);
  const [bookings, setBookings] = useState<ServiceBooking[]>([]);
  const [reports, setReports] = useState<EmergencyReport[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    Promise.all([
      api.getFavorites(user?.id),
      api.getBookings(user?.id),
      api.getAdminOverview(),
    ])
      .then(([favs, bks, adminData]) => {
        if (isMounted) {
          setFavorites(favs);
          setBookings(bks);
          setReports(adminData.recentReports || []);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error(err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [user?.id]);

  const handleRemoveFavorite = async (providerId: string) => {
    await api.removeFavorite(providerId, user?.id);
    setFavorites((prev) => prev.filter((p) => p.id !== providerId));
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-white font-bold">
              {user?.fullName?.charAt(0) || 'U'}
            </div>
            <div>
              <h3 className="text-base font-bold">{user?.fullName}</h3>
              <p className="text-xs text-slate-400">
                {user?.email} · Role: {user?.role.toUpperCase()}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-200 px-6 bg-slate-50 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('favorites')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'favorites'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span>Saved Favorites ({favorites.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('bookings')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'bookings'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>My Bookings ({bookings.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('reports')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'reports'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Hazard Reports</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('plan')}
            className={`py-3 px-4 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'plan'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Disaster Plan</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1">
          {isLoading ? (
            <div className="text-xs text-slate-400 py-8 text-center">Loading account records...</div>
          ) : (
            <>
              {/* 1. FAVORITES */}
              {activeTab === 'favorites' && (
                <div>
                  {favorites.length > 0 ? (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {favorites.map((fav) => (
                        <div
                          key={fav.id}
                          className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col justify-between hover:border-slate-300"
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2 mb-1">
                              <h4 className="text-sm font-bold text-slate-900">{fav.businessName}</h4>
                              <button
                                type="button"
                                onClick={() => handleRemoveFavorite(fav.id)}
                                className="text-slate-400 hover:text-red-600 p-1"
                                title="Remove favorite"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                            <p className="text-xs text-slate-500">{fav.address}</p>
                            <span className="text-[11px] font-mono text-slate-400 mt-1 block">
                              Phone: {fav.phone}
                            </span>
                          </div>

                          <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between">
                            <span className="text-xs font-semibold text-slate-800">
                              ★ {fav.googleRating ?? 'N/A'}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                onClose();
                                onSelectService(fav);
                              }}
                              className="text-xs font-semibold text-blue-600 hover:underline"
                            >
                              Open Details
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-10 text-xs text-slate-500">
                      No saved favorite services yet. Click "Save to Favorites" on any hospital, garage, or pharmacy.
                    </div>
                  )}
                </div>
              )}

              {/* 2. BOOKINGS */}
              {activeTab === 'bookings' && (
                <div className="space-y-3">
                  {bookings.length > 0 ? (
                    bookings.map((b) => (
                      <div
                        key={b.id}
                        className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                      >
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="text-sm font-bold text-slate-900">{b.providerName}</h4>
                            <span
                              className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md ${
                                b.status === 'accepted'
                                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                                  : b.status === 'pending'
                                  ? 'bg-amber-50 text-amber-800 border border-amber-200'
                                  : 'bg-slate-100 text-slate-700'
                              }`}
                            >
                              {b.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600">{b.serviceTitle}</p>
                          <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 font-mono">
                            <span>Date: {b.bookingDate}</span>
                            <span>·</span>
                            <span>Time: {b.bookingTime}</span>
                          </div>
                        </div>

                        <div className="text-xs text-slate-500 text-right shrink-0">
                          <span className="block font-medium">Contact: {b.contactPhone}</span>
                          <span className="text-[11px] text-slate-400">
                            ID: {b.id.slice(0, 12)}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-10 text-xs text-slate-500">
                      No service appointments placed yet.
                    </div>
                  )}
                </div>
              )}

              {/* 3. REPORTS */}
              {activeTab === 'reports' && (
                <div className="space-y-3">
                  {reports.map((rep) => (
                    <div key={rep.id} className="p-4 rounded-xl border border-slate-200 bg-white">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-slate-900">{rep.title}</span>
                        <span
                          className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-md ${
                            rep.status === 'investigating'
                              ? 'bg-blue-50 text-blue-700'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {rep.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600">{rep.description}</p>
                      <span className="text-[11px] text-slate-400 mt-1 block font-mono">
                        Location: {rep.locationName}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* 4. PLAN */}
              {activeTab === 'plan' && (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 leading-relaxed">
                    <h4 className="font-bold text-slate-900 text-sm mb-1">
                      Family Emergency Evacuation Plan
                    </h4>
                    <p>
                      Keep this emergency meeting checklist synced with your family. In case cellular towers are impaired during earthquakes or floods, assemble at your predefined open assembly park.
                    </p>
                    <div className="mt-3 space-y-1.5 font-medium text-slate-800">
                      <div>• Safe Meeting Point: Shivaji Stadium Municipal Grounds / Connaught Place Central Park</div>
                      <div>• Out-of-Area Emergency Contact: +91-98765-43210</div>
                      <div>• Bug-Out Bag: Water tablets, LED torch, power bank, N95 masks, dry rations</div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
