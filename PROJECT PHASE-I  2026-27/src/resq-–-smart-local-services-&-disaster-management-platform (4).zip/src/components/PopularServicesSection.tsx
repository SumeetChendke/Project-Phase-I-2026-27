import React, { useState, useEffect } from 'react';
import {
  Wrench,
  Fuel,
  Pill,
  Zap,
  Star,
  MapPin,
  Phone,
  Navigation,
  ChevronRight,
  LifeBuoy,
  ZapOff,
} from 'lucide-react';
import { ServiceProvider } from '../types';
import { api } from '../services/api';
import { useLocation } from '../context/LocationContext';

interface PopularServicesSectionProps {
  onSelectService: (service: ServiceProvider) => void;
  onOpenCategory: (categoryId: string) => void;
  onOpenSos?: (service: ServiceProvider, categoryLabel?: string) => void;
}

export const PopularServicesSection: React.FC<PopularServicesSectionProps> = ({
  onSelectService,
  onOpenCategory,
  onOpenSos,
}) => {
  const { location } = useLocation();
  const [activeTab, setActiveTab] = useState<'garages' | 'petrolPumps' | 'pharmacies' | 'shelters' | 'electricians'>('garages');
  const [data, setData] = useState<{
    garages: ServiceProvider[];
    petrolPumps: ServiceProvider[];
    pharmacies: ServiceProvider[];
    shelters: ServiceProvider[];
    electricians: ServiceProvider[];
  }>({
    garages: [],
    petrolPumps: [],
    pharmacies: [],
    shelters: [],
    electricians: [],
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    api
      .getPopularServices(location.lat, location.lng)
      .then((res) => {
        if (isMounted) {
          setData(res);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error('Error fetching popular services', err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [location.lat, location.lng]);

  const tabs = [
    { key: 'garages', label: 'Garages & Mechanics', icon: Wrench, categoryId: 'garages' },
    { key: 'petrolPumps', label: 'Petrol & Fuel', icon: Fuel, categoryId: 'petrol-pumps' },
    { key: 'pharmacies', label: '24/7 Pharmacies', icon: Pill, categoryId: 'pharmacies' },
    { key: 'shelters', label: 'Relief Shelters', icon: LifeBuoy, categoryId: 'emergency-shelters' },
    { key: 'electricians', label: 'Electricians', icon: ZapOff, categoryId: 'electricians' },
  ] as const;

  const currentList = data[activeTab] || [];
  const activeTabMeta = tabs.find((t) => t.key === activeTab)!;

  return (
    <section className="py-12 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Popular Nearby Essentials
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Top verified utilities, repair stations, pharmacies, and refilling points near {location.name}.
            </p>
          </div>

          {/* Interactive filter tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.key;
              const Icon = tab.icon;
              return (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => setActiveTab(tab.key)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Content Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className="rounded-xl border border-slate-200 bg-white p-4 animate-pulse">
                <div className="h-4 bg-slate-200 rounded-sm w-2/3 mb-2" />
                <div className="h-3 bg-slate-100 rounded-sm w-1/3 mb-3" />
                <div className="h-10 bg-slate-100 rounded-sm mb-3" />
                <div className="h-7 bg-slate-200 rounded-md" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {currentList.map((service) => {
              const hasRating = typeof service.googleRating === 'number';
              const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                `${service.businessName} ${service.address}`
              )}`;

              return (
                <div
                  key={service.id}
                  className="rounded-xl border border-slate-200 bg-white p-4 flex flex-col justify-between hover:border-slate-300 hover:shadow-xs transition-all"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="text-[11px] font-mono text-slate-500 tabular-nums">
                        {service.distanceKm} km away
                      </span>
                      {service.isOpenNow && (
                        <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-sm border border-emerald-200 font-medium">
                          Open
                        </span>
                      )}
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 leading-snug line-clamp-1">
                      {service.businessName}
                    </h4>

                    {/* Unboxed metadata */}
                    <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1 mb-2">
                      {hasRating ? (
                        <span className="flex items-center gap-1 font-semibold text-slate-900 tabular-nums">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-500" />
                          <span>{service.googleRating?.toFixed(1)}</span>
                          <span className="text-slate-400 font-normal">({service.googleReviewCount ?? 0})</span>
                        </span>
                      ) : (
                        <span className="text-slate-400 italic">No rating</span>
                      )}
                      <span>·</span>
                      <span className="truncate">{service.locality}</span>
                    </div>

                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {service.description}
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-1.5 flex-wrap">
                    <a
                      href={mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1 font-medium"
                    >
                      <Navigation className="w-3 h-3 text-blue-600" />
                      <span>Route</span>
                    </a>

                    <div className="flex items-center gap-1">
                      {onOpenSos && (
                        <button
                          type="button"
                          onClick={() => onOpenSos(service, activeTabMeta.label)}
                          className="px-2 py-1 text-xs font-bold text-red-700 bg-red-50 hover:bg-red-100 active:bg-red-200 border border-red-200 rounded-md transition-colors cursor-pointer"
                          title={`Send SOS requesting ${service.businessName}`}
                        >
                          🚨 SOS
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => onSelectService(service)}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                      >
                        Details
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* View All Button for Active Category */}
        <div className="mt-6 text-center">
          <button
            type="button"
            onClick={() => onOpenCategory(activeTabMeta.categoryId)}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg shadow-2xs transition-colors"
          >
            <span>Browse All {activeTabMeta.label}</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>
      </div>
    </section>
  );
};
