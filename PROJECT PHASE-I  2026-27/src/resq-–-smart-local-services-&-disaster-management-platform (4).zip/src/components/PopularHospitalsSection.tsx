import React, { useState, useEffect } from 'react';
import {
  Building2,
  Star,
  MapPin,
  Phone,
  Navigation,
  Clock,
  CalendarPlus,
  Info,
  SlidersHorizontal,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { ServiceProvider } from '../types';
import { api } from '../services/api';
import { useLocation } from '../context/LocationContext';

interface PopularHospitalsSectionProps {
  onSelectHospital: (hospital: ServiceProvider) => void;
  onBookAppointment: (hospital: ServiceProvider) => void;
  onOpenSos?: (hospital: ServiceProvider) => void;
}

export const PopularHospitalsSection: React.FC<PopularHospitalsSectionProps> = ({
  onSelectHospital,
  onBookAppointment,
  onOpenSos,
}) => {
  const { location } = useLocation();
  const [hospitals, setHospitals] = useState<ServiceProvider[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'rating' | 'reviews' | 'distance'>('rating');
  const [showRankingInfo, setShowRankingInfo] = useState(false);

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    api
      .getPopularHospitals({
        lat: location.lat,
        lng: location.lng,
        sort: sortBy,
        limit: 8,
      })
      .then((data) => {
        if (isMounted) {
          setHospitals(data.hospitals);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error('Error fetching popular hospitals', err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [location.lat, location.lng, sortBy]);

  return (
    <section id="hospitals" className="py-12 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header & Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Building2 className="w-4 h-4 text-red-600" />
              <span className="text-xs font-bold text-red-700 uppercase tracking-wider">
                Mandatory Healthcare Directory
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Popular Hospitals Near You
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
              Verified hospital facilities near <span className="font-semibold text-slate-700">{location.name}</span>.
              Ranked with genuine Google Maps review counts, authentic ratings, and distance.
            </p>
          </div>

          {/* Sort Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Sort by:</span>
            <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50 text-xs">
              <button
                type="button"
                onClick={() => setSortBy('rating')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  sortBy === 'rating' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Highest Rated
              </button>
              <button
                type="button"
                onClick={() => setSortBy('reviews')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  sortBy === 'reviews' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Most Reviewed
              </button>
              <button
                type="button"
                onClick={() => setSortBy('distance')}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  sortBy === 'distance' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Nearest First
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowRankingInfo(!showRankingInfo)}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-md"
              title="How ranking works"
            >
              <Info className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Ranking Methodology Disclosure */}
        {showRankingInfo && (
          <div className="mb-6 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 leading-relaxed">
            <div className="font-semibold text-slate-900 mb-1 flex items-center gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 text-blue-600" />
              <span>Hospital Ranking &amp; Data Integrity Rules</span>
            </div>
            <p>
              • <strong>Genuine Data Only:</strong> Ratings and review counts reflect authentic Google Maps provider records. Missing ratings are designated as "Rating unavailable" and never manufactured.
            </p>
            <p className="mt-1">
              • <strong>Bayesian Volume Weighting:</strong> A clinic with 1 review at 5.0 will not outrank a trauma centre with 15,000 reviews at 4.7.
            </p>
            <p className="mt-1">
              • <strong>Clinical Disclaimer:</strong> Review popularity reflects patient footfall and public feedback; it does not certify live ICU bed vacancy, blood availability, or surgical team readiness. For extreme trauma emergencies, call <strong>112 / 108</strong> immediately.
            </p>
          </div>
        )}

        {/* Loading Skeleton */}
        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((n) => (
              <div key={n} className="rounded-2xl border border-slate-200 p-5 bg-white animate-pulse">
                <div className="h-4 bg-slate-200 rounded-sm w-3/4 mb-3" />
                <div className="h-3 bg-slate-100 rounded-sm w-1/2 mb-4" />
                <div className="h-16 bg-slate-100 rounded-lg mb-4" />
                <div className="h-8 bg-slate-200 rounded-lg w-full" />
              </div>
            ))}
          </div>
        )}

        {/* Hospital Cards Grid */}
        {!isLoading && hospitals.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {hospitals.map((hospital) => {
              const hasRating = typeof hospital.googleRating === 'number';
              const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                `${hospital.businessName} ${hospital.address}`
              )}`;

              return (
                <div
                  key={hospital.id}
                  className="rounded-2xl border border-slate-200 bg-white hover:border-slate-300 hover:shadow-md transition-all flex flex-col justify-between overflow-hidden"
                >
                  {/* Card Visual Header Fallback Container */}
                  <div className="h-28 bg-gradient-to-br from-slate-100 to-slate-200 p-4 relative flex items-start justify-between border-b border-slate-100">
                    <div className="w-10 h-10 rounded-xl bg-white text-red-600 flex items-center justify-center shadow-xs">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div className="flex items-center gap-2">
                      {hospital.isOpenNow && (
                        <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                          Open 24/7
                        </span>
                      )}
                      <span className="text-xs font-mono font-medium text-slate-600 bg-white/80 px-2 py-0.5 rounded-md tabular-nums">
                        {hospital.distanceKm} km
                      </span>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-base font-bold text-slate-900 leading-snug line-clamp-1">
                        {hospital.businessName}
                      </h3>

                      {/* Unboxed Metadata (Zero-Pill Discipline) */}
                      <div className="flex items-center gap-2 text-xs text-slate-500 mt-1 mb-2.5">
                        {hasRating ? (
                          <span className="flex items-center gap-1 font-semibold text-slate-900 tabular-nums">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                            <span>{hospital.googleRating?.toFixed(1)}</span>
                            <span className="text-slate-400 font-normal">
                              ({hospital.googleReviewCount?.toLocaleString()} reviews)
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">Rating unavailable</span>
                        )}
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-600">{hospital.locality}</span>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {hospital.description}
                      </p>

                      <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-500">
                        <div className="flex items-start gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                          <span className="line-clamp-1">{hospital.address}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <a href={`tel:${hospital.phone}`} className="hover:text-slate-900 font-medium">
                            {hospital.phone}
                          </a>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap sm:flex-nowrap">
                      <div className="flex items-center gap-1.5">
                        <a
                          href={mapsUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2.5 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1"
                          title="Get directions in Google Maps"
                        >
                          <Navigation className="w-3.5 h-3.5 text-blue-600" />
                          <span>Directions</span>
                        </a>

                        <button
                          type="button"
                          onClick={() => onBookAppointment(hospital)}
                          className="px-2.5 py-1.5 text-xs font-medium text-blue-700 hover:bg-blue-50 rounded-lg transition-colors flex items-center gap-1"
                          title="Request appointment or emergency bed inquiry"
                        >
                          <CalendarPlus className="w-3.5 h-3.5" />
                          <span>Book</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {onOpenSos && (
                          <button
                            type="button"
                            onClick={() => onOpenSos(hospital)}
                            className="px-2.5 py-1.5 text-xs font-bold text-red-700 bg-red-50 hover:bg-red-100 active:bg-red-200 border border-red-200 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                            title={`Dispatch Emergency SOS for ${hospital.businessName} with location, contacts & shortest route`}
                          >
                            <span>🚨 SOS</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onSelectHospital(hospital)}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1"
                        >
                          <span>Details</span>
                          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Empty State */}
        {!isLoading && hospitals.length === 0 && (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 text-xs text-slate-500">
            No hospital records located in the immediate vicinity. Use the search bar above or expand search radius in settings.
          </div>
        )}
      </div>
    </section>
  );
};
