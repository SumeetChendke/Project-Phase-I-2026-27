import { GoogleGenAI, Type, FunctionDeclaration } from '@google/genai';
import { db } from './db';

// Tool Declarations for Gemini Flash Function Calling
const findNearbyServicesTool: FunctionDeclaration = {
  name: 'findNearbyServices',
  description: 'Search real, verified local services (hospitals, garages, petrol pumps, police, ambulances, etc.) near the user coordinates.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      categoryId: {
        type: Type.STRING,
        description: 'Category identifier (e.g. "hospitals", "garages", "petrol-pumps", "ambulances", "pharmacies", "police-stations", "electricians", "water-suppliers", "emergency-shelters")',
      },
      query: {
        type: Type.STRING,
        description: 'Specific search keyword or locality name (optional)',
      },
      radiusKm: {
        type: Type.NUMBER,
        description: 'Search radius in kilometers (default 25)',
      },
    },
  },
};

const getDisasterInstructionsTool: FunctionDeclaration = {
  name: 'getDisasterInstructions',
  description: 'Retrieve verified life-safety instructions for 16 specific disasters (floods, earthquakes, cyclones, fires, chemical leaks, etc.) for Before, During, or After the event.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      disasterType: {
        type: Type.STRING,
        description: 'Type of disaster: floods, earthquakes, cyclones, tsunamis, landslides, fires, heatwaves, droughts, lightning-storms, cloudbursts, industrial-accidents, chemical-leaks, road-accidents, building-collapse, dam-failure, forest-fires',
      },
      phase: {
        type: Type.STRING,
        description: 'Phase: "before", "during", "after", or "all"',
      },
    },
    required: ['disasterType'],
  },
};

const getOfficialEmergencyNumbersTool: FunctionDeclaration = {
  name: 'getOfficialEmergencyNumbers',
  description: 'Fetch verified national and local emergency contact numbers (112, 108, 100, 101, 1070 NDMA, 1077 DDMA, etc.)',
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'Optional query filter for emergency type (e.g. "ambulance", "police", "disaster", "poison")',
      },
    },
  },
};

export async function handleGeminiAssistantChat(params: {
  message: string;
  userLat: number;
  userLng: number;
  locationName: string;
  conversationHistory?: { role: 'user' | 'assistant'; text: string }[];
  forceFallback?: boolean;
}): Promise<{
  reply: string;
  toolResults?: any[];
  safetyBanner?: string;
}> {
  const { message, userLat, userLng, locationName, conversationHistory = [], forceFallback } = params;
  const apiKey = process.env.GEMINI_API_KEY;

  // Rule-based fallback if API key is not yet configured or fails
  const fallbackHandler = () => {
    const lower = message.toLowerCase();

    // Emergency keywords
    if (lower.includes('112') || lower.includes('sos') || lower.includes('urgent') || lower.includes('dying') || lower.includes('heart attack')) {
      return {
        reply: `EMERGENCY ALERT: If this is an immediate life-threatening emergency, please dial 112 immediately for unified Police, Fire, and Ambulance dispatch. For medical trauma, dial 108 directly. Stay calm, ensure personal physical safety, and notify nearby emergency services.`,
        safetyBanner: 'For immediate life threats, call 112 or 108 without delay.',
        toolResults: [
          {
            tool: 'emergencyContacts',
            contacts: [
              { name: 'Universal Emergency Support (ERSS)', number: '112' },
              { name: 'Ambulance Trauma Emergency', number: '108' },
            ],
          },
        ],
      };
    }

    // Hospital search
    if (lower.includes('hospital') || lower.includes('doctor') || lower.includes('clinic')) {
      const hospitals = db.getPopularHospitals({ lat: userLat, lng: userLng, limit: 3 });
      return {
        reply: `Here are the top-rated emergency hospitals near ${locationName}:\n\n` +
          hospitals
            .map(
              (h) =>
                `• **${h.businessName}** (${h.distanceKm} km away)\n  Address: ${h.address}\n  Phone: ${h.phone}\n  Google Rating: ${h.googleRating ?? 'Rating unavailable'} (${h.googleReviewCount?.toLocaleString() ?? 0} reviews)\n  Open: 24/7 Emergency Service`
            )
            .join('\n\n'),
        toolResults: [{ tool: 'findNearbyServices', category: 'hospitals', results: hospitals }],
      };
    }

    // Breakdown / garage
    if (lower.includes('garage') || lower.includes('car broke down') || lower.includes('puncture') || lower.includes('mechanic') || lower.includes('towing')) {
      const garages = db.getNearbyServices({ lat: userLat, lng: userLng, categoryId: 'garages', radiusKm: 30 });
      return {
        reply: `I found verified vehicle roadside assistance and garages near ${locationName}:\n\n` +
          garages
            .slice(0, 3)
            .map(
              (g) =>
                `• **${g.businessName}** (${g.distanceKm} km away)\n  Phone: ${g.phone}\n  Address: ${g.address}\n  Rating: ${g.googleRating ?? 'Rating unavailable'} (${g.googleReviewCount ?? 0} reviews)`
            )
            .join('\n\n'),
        toolResults: [{ tool: 'findNearbyServices', category: 'garages', results: garages.slice(0, 3) }],
      };
    }

    // Disaster safety query
    const matchedGuide = db.getDisasterGuides().find(
      (g) =>
        lower.includes(g.id) ||
        lower.includes(g.name.toLowerCase()) ||
        (lower.includes('flood') && g.id === 'floods') ||
        (lower.includes('earthquake') && g.id === 'earthquakes') ||
        (lower.includes('cyclone') && g.id === 'cyclones') ||
        (lower.includes('fire') && g.id === 'fires')
    );
    if (matchedGuide) {
      return {
        reply: `### Essential Safety Protocol: ${matchedGuide.name}\n\n` +
          `**Immediate Actions During the Event:**\n` +
          matchedGuide.duringSteps.map((s) => `1. ${s}`).join('\n') +
          `\n\n**Preparedness Checklist:**\n` +
          matchedGuide.emergencyKit.map((k) => `• ${k}`).join('\n') +
          `\n\n**Vital Contacts:** ` +
          matchedGuide.vitalContacts.map((c) => `${c.label}: ${c.number}`).join(', '),
        safetyBanner: `Verified safety protocol for ${matchedGuide.name}. Always follow official local authority orders.`,
      };
    }

    return {
      reply: `I am your ResQ local services & disaster management assistant. You can ask me to find nearest hospitals, 24/7 garages, petrol pumps, check disaster safety protocols (floods, earthquakes, fires), or review emergency contacts near ${locationName}. How can I assist you?`,
    };
  };

  if (forceFallback || !apiKey || apiKey.startsWith('MY_') || apiKey === 'undefined') {
    return fallbackHandler();
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const modelName = process.env.GEMINI_MODEL || 'gemini-3.8-flash';

    const systemInstruction = `You are ResQ AI Assistant, an authoritative, calm, and accurate assistant for local services discovery, emergency response, and disaster management.
User's current selected location: "${locationName}" (Latitude: ${userLat}, Longitude: ${userLng}).
Key Rules:
1. NEVER invent or fabricate providers, phone numbers, ratings, or emergency warnings. Only present verified facts or data retrieved from tool functions.
2. If the user is facing a life-threatening crisis, immediately urge them to call 112 (Universal Emergency in India) or 108 (Ambulance), providing clear, actionable safety instructions.
3. For hospital requests, accurately state the hospital name, distance, authentic Google Maps rating & review count, phone, and address.
4. Keep disaster instructions concise, clear, and direct.`;

    // First turn with tool declarations
    const contents: any[] = [];
    for (const h of conversationHistory.slice(-4)) {
      contents.push({
        role: h.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: h.text }],
      });
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: modelName,
      contents,
      config: {
        systemInstruction,
        tools: [
          {
            functionDeclarations: [
              findNearbyServicesTool,
              getDisasterInstructionsTool,
              getOfficialEmergencyNumbersTool,
            ],
          },
        ],
      },
    });

    const functionCalls = response.functionCalls;
    const executedToolResults: any[] = [];

    if (functionCalls && functionCalls.length > 0) {
      const toolCallResponses: any[] = [];

      for (const call of functionCalls) {
        if (call.name === 'findNearbyServices') {
          const args = call.args as any;
          const services = db.getNearbyServices({
            lat: userLat,
            lng: userLng,
            categoryId: args.categoryId,
            query: args.query,
            radiusKm: args.radiusKm || 30,
          });
          const summary = services.slice(0, 5).map((s) => ({
            id: s.id,
            name: s.businessName,
            category: s.primaryCategoryId,
            distanceKm: s.distanceKm,
            phone: s.phone,
            address: s.address,
            rating: s.googleRating,
            reviewCount: s.googleReviewCount,
            isOpenNow: s.isOpenNow,
          }));
          executedToolResults.push({ tool: 'findNearbyServices', data: summary });
          toolCallResponses.push({
            name: call.name,
            response: { results: summary },
          });
        } else if (call.name === 'getDisasterInstructions') {
          const args = call.args as any;
          const guide = db.getDisasterGuideById(args.disasterType);
          executedToolResults.push({ tool: 'getDisasterInstructions', data: guide });
          toolCallResponses.push({
            name: call.name,
            response: { guide },
          });
        } else if (call.name === 'getOfficialEmergencyNumbers') {
          const contacts = db.getEmergencyContacts();
          executedToolResults.push({ tool: 'getOfficialEmergencyNumbers', data: contacts });
          toolCallResponses.push({
            name: call.name,
            response: { contacts },
          });
        }
      }

      // Second turn with tool results to generate the final assistant response
      const toolFollowUp = await ai.models.generateContent({
        model: modelName,
        contents: [
          ...contents,
          response.candidates?.[0]?.content as any,
          {
            role: 'user',
            parts: toolCallResponses.map((res) => ({
              functionResponse: {
                name: res.name,
                response: res.response,
              },
            })),
          },
        ],
        config: { systemInstruction },
      });

      return {
        reply: toolFollowUp.text || 'I have retrieved the verified information for your location above.',
        toolResults: executedToolResults,
      };
    }

    return {
      reply: response.text || fallbackHandler().reply,
      toolResults: executedToolResults,
    };
  } catch (error) {
    console.error('[ResQ Gemini Assistant Error]', error);
    return fallbackHandler();
  }
}
