import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { z } from 'zod';
import { db } from './src/server/db';
import { ServiceProvider } from './src/types';
import { handleGeminiAssistantChat } from './src/server/gemini';
import {
  reverseGeocode,
  searchLocations,
  fetchLivePlacesAround,
  fetchGooglePlacesAround,
} from './src/server/geocoding';
import {
  dispatchDirectSos,
  getSosGatewayStatus,
  updateSosGatewayConfig,
  testSosGatewayConnection,
} from './src/server/sosDispatcher';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// CORS & Preflight handling for iframe preview
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(204);
  }
  next();
});

// Request logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (req.path.startsWith('/api')) {
      console.log(`[API] ${req.method} ${req.path} -> ${res.statusCode} (${duration}ms)`);
    }
  });
  next();
});

// --- API ROUTES ---

// 1. Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    platform: 'ResQ - Smart Local Services & Disaster Management',
  });
});

// Geocode: Reverse lookup coordinates to real live street address
app.get('/api/geocode/reverse', async (req: Request, res: Response) => {
  const lat = parseFloat(req.query.lat as string);
  const lng = parseFloat(req.query.lng as string);
  if (isNaN(lat) || isNaN(lng)) {
    return res.status(400).json({ error: 'Valid lat and lng required' });
  }

  const result = await reverseGeocode(lat, lng);
  res.json(result);
});

// Geocode: Search any village, town, city, district or PIN code
app.get('/api/geocode/search', async (req: Request, res: Response) => {
  const q = (req.query.q as string || '').trim();
  if (!q) {
    return res.json({ locations: [] });
  }

  const locations = await searchLocations(q);
  res.json({ locations });
});

// Geocode: Approximate IP fallback
app.get('/api/geocode/ip', async (req: Request, res: Response) => {
  try {
    const response = await fetch('https://ipapi.co/json/');
    if (response.ok) {
      const data = await response.json();
      if (data.latitude && data.longitude) {
        return res.json({
          name: `${data.city || data.region || 'Live Area'}, ${data.country_name || ''}`,
          city: data.city || 'Live Area',
          state: data.region || '',
          country: data.country_name || '',
          lat: data.latitude,
          lng: data.longitude,
          isGps: false,
        });
      }
    }
  } catch (err) {
    // fallback
  }

  res.json({
    name: 'Connaught Place, New Delhi',
    city: 'New Delhi',
    state: 'Delhi',
    lat: 28.6304,
    lng: 77.2177,
    isGps: false,
  });
});

// Google Maps Configuration
app.get('/api/config/maps', (_req: Request, res: Response) => {
  const apiKey =
    process.env.VITE_GOOGLE_MAPS_API_KEY ||
    process.env.GOOGLE_MAPS_API_KEY ||
    'AIzaSyA2ngfPYpWKParBoiwkZCkig-PTFBr2GV8';
  const mapId =
    process.env.VITE_GOOGLE_MAPS_MAP_ID ||
    process.env.GOOGLE_MAPS_MAP_ID ||
    'bf51a910020fa25a';
  res.json({
    apiKey,
    mapId,
    hasKey: Boolean(apiKey && apiKey !== 'your-google-maps-api-key'),
  });
});

// Live Google Places Search (Returns authentic services on Google Maps ranked rating-wise)
app.get('/api/places/live-google', async (req: Request, res: Response) => {
  const lat = parseFloat(req.query.lat as string) || 28.6304;
  const lng = parseFloat(req.query.lng as string) || 77.2177;
  const category = req.query.category as string;
  const radiusKm = req.query.radius ? parseFloat(req.query.radius as string) : 25;
  const sortBy = (req.query.sort as 'rating' | 'reviews' | 'distance') || 'rating';

  try {
    const places = await fetchGooglePlacesAround({
      lat,
      lng,
      radiusMeters: radiusKm * 1000,
      category,
    });

    if (places.length > 0) {
      db.addProviders(places);
    }

    // Prioritize authentic live Google Places, falling back to DB if none returned
    let results: ServiceProvider[] = [];
    if (places.length > 0) {
      results = [...places];
    } else {
      results = db.getNearbyServices({
        lat,
        lng,
        categoryId: category,
        radiusKm,
        sortBy: sortBy === 'rating' ? 'rating' : (sortBy as any),
      });
    }

    // Sort rating-wise (Highest rating, then review count) or requested sort
    if (sortBy === 'distance') {
      results.sort((a, b) => (a.distanceKm ?? 999) - (b.distanceKm ?? 999));
    } else if (sortBy === 'reviews') {
      results.sort((a, b) => (b.googleReviewCount ?? 0) - (a.googleReviewCount ?? 0));
    } else {
      // Default: 'rating' (Rating-wise: highest rating first, tie-break by review count)
      results.sort((a, b) => {
        const rateA = a.googleRating ?? a.platformRating ?? 0;
        const rateB = b.googleRating ?? b.platformRating ?? 0;
        if (rateB !== rateA) return rateB - rateA;
        const countA = a.googleReviewCount ?? a.platformReviewCount ?? 0;
        const countB = b.googleReviewCount ?? b.platformReviewCount ?? 0;
        return countB - countA;
      });
    }

    results.forEach((s, idx) => {
      s.ratingWiseRank = idx + 1;
    });

    res.json({
      services: results,
      total: results.length,
      origin: { lat, lng },
      sortBy,
      isLiveGoogle: true,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to fetch live Google places' });
  }
});

// 2. Service categories
app.get('/api/categories', (req: Request, res: Response) => {
  const categories = db.getCategories();
  res.json({ categories, count: categories.length });
});

// 3. Nearby services (with live location discovery fallback)
app.get('/api/services/nearby', async (req: Request, res: Response) => {
  const lat = parseFloat(req.query.lat as string) || 28.6304;
  const lng = parseFloat(req.query.lng as string) || 77.2177;
  const categoryId = req.query.category as string;
  const query = req.query.q as string;
  const radiusKm = req.query.radius ? parseFloat(req.query.radius as string) : 50;
  const sortBy = (req.query.sort as 'rating' | 'reviews' | 'distance' | 'balanced') || 'balanced';

  let services = db.getNearbyServices({
    lat,
    lng,
    categoryId,
    query,
    radiusKm,
    sortBy,
  });

  // If no services in the immediate seed database around user's live position, fetch real live places
  if (services.length === 0) {
    try {
      const livePlaces = await fetchLivePlacesAround({
        lat,
        lng,
        category: categoryId,
        radiusMeters: Math.max(radiusKm, 35) * 1000,
      });
      if (livePlaces.length > 0) {
        db.addProviders(livePlaces);
        services = db.getNearbyServices({
          lat,
          lng,
          categoryId,
          query,
          radiusKm,
          sortBy,
        });
      }
    } catch (err) {
      console.warn('Live places fetch warning:', err);
    }
  }

  res.json({
    services,
    total: services.length,
    origin: { lat, lng },
    sortBy,
  });
});

// 4. Universal search across categories and providers
app.get('/api/services/search', (req: Request, res: Response) => {
  const q = (req.query.q as string || '').trim();
  const lat = parseFloat(req.query.lat as string) || 28.6304;
  const lng = parseFloat(req.query.lng as string) || 77.2177;

  if (!q) {
    return res.json({ categories: [], services: [] });
  }

  const matchingCategories = db.getCategories().filter(
    (c) => c.name.toLowerCase().includes(q.toLowerCase()) || c.description.toLowerCase().includes(q.toLowerCase())
  );

  const matchingServices = db.getNearbyServices({
    lat,
    lng,
    query: q,
    radiusKm: 150,
  });

  res.json({
    query: q,
    categories: matchingCategories,
    services: matchingServices,
  });
});

// 5. Popular hospitals (Mandatory Section 4)
app.get('/api/services/popular-hospitals', async (req: Request, res: Response) => {
  const lat = parseFloat(req.query.lat as string) || 28.6304;
  const lng = parseFloat(req.query.lng as string) || 77.2177;
  const sortBy = (req.query.sort as 'rating' | 'reviews' | 'distance') || 'rating';
  const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 10;

  let hospitals = db.getPopularHospitals({
    lat,
    lng,
    sortBy,
    limit,
  });

  if (hospitals.length === 0) {
    try {
      const livePlaces = await fetchGooglePlacesAround({
        lat,
        lng,
        category: 'hospitals',
        radiusMeters: 35000,
      });
      if (livePlaces.length > 0) {
        db.addProviders(livePlaces);
        hospitals = db.getPopularHospitals({
          lat,
          lng,
          sortBy,
          limit,
        });
      }
    } catch (err) {
      console.warn('Live hospitals fetch warning:', err);
    }
  }

  res.json({
    hospitals,
    total: hospitals.length,
    origin: { lat, lng },
    sortBy,
    rankingMethod: 'Genuine Google Maps verified ratings & Bayesian weighted score',
  });
});

// 6. Popular services across other key categories (Garages, Petrol pumps, Pharmacies, etc.)
app.get('/api/services/popular', async (req: Request, res: Response) => {
  const lat = parseFloat(req.query.lat as string) || 28.6304;
  const lng = parseFloat(req.query.lng as string) || 77.2177;

  let garages = db.getNearbyServices({ lat, lng, categoryId: 'garages', radiusKm: 35 }).slice(0, 4);
  let petrolPumps = db.getNearbyServices({ lat, lng, categoryId: 'petrol-pumps', radiusKm: 35 }).slice(0, 4);
  let pharmacies = db.getNearbyServices({ lat, lng, categoryId: 'pharmacies', radiusKm: 35 }).slice(0, 4);
  let shelters = db.getNearbyServices({ lat, lng, categoryId: 'emergency-shelters', radiusKm: 35 }).slice(0, 4);
  let electricians = db.getNearbyServices({ lat, lng, categoryId: 'electricians', radiusKm: 35 }).slice(0, 4);

  // If local seed database has no services around user's live position, fetch authentic live Google Places
  if (garages.length === 0 && petrolPumps.length === 0 && pharmacies.length === 0) {
    try {
      const livePlaces = await fetchGooglePlacesAround({
        lat,
        lng,
        radiusMeters: 35000,
      });
      if (livePlaces.length > 0) {
        db.addProviders(livePlaces);
        garages = db.getNearbyServices({ lat, lng, categoryId: 'garages', radiusKm: 35 }).slice(0, 4);
        petrolPumps = db.getNearbyServices({ lat, lng, categoryId: 'petrol-pumps', radiusKm: 35 }).slice(0, 4);
        pharmacies = db.getNearbyServices({ lat, lng, categoryId: 'pharmacies', radiusKm: 35 }).slice(0, 4);
        shelters = db.getNearbyServices({ lat, lng, categoryId: 'emergency-shelters', radiusKm: 35 }).slice(0, 4);
        electricians = db.getNearbyServices({ lat, lng, categoryId: 'electricians', radiusKm: 35 }).slice(0, 4);
      }
    } catch (err) {
      console.warn('Could not populate live popular services:', err);
    }
  }

  res.json({
    garages,
    petrolPumps,
    pharmacies,
    shelters,
    electricians,
  });
});

// 7. Single service details
app.get('/api/services/:id', (req: Request, res: Response) => {
  const provider = db.getProviderById(req.params.id);
  if (!provider) {
    return res.status(404).json({ error: 'Service provider not found' });
  }

  const reviews = db.getReviewsByProvider(provider.id);

  res.json({
    provider,
    reviews,
  });
});

// 8. User favorites
app.get('/api/favorites', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'user-demo-123';
  const favorites = db.getFavoritesByUser(userId);
  res.json({ favorites });
});

app.post('/api/favorites', (req: Request, res: Response) => {
  const schema = z.object({
    userId: z.string().default('user-demo-123'),
    providerId: z.string(),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid favorite payload', details: parsed.error.issues });
  }

  const success = db.addFavorite(parsed.data.userId, parsed.data.providerId);
  res.json({ success, message: success ? 'Saved to favorites' : 'Already in favorites' });
});

app.delete('/api/favorites/:id', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'user-demo-123';
  const success = db.removeFavorite(userId, req.params.id);
  res.json({ success });
});

// 9. Bookings & Service Requests
app.get('/api/bookings', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'user-demo-123';
  const bookings = db.getBookingsByUser(userId);
  res.json({ bookings });
});

app.post('/api/bookings', (req: Request, res: Response) => {
  const bookingSchema = z.object({
    userId: z.string().default('user-demo-123'),
    providerId: z.string(),
    providerName: z.string(),
    categoryName: z.string(),
    serviceTitle: z.string(),
    bookingDate: z.string(),
    bookingTime: z.string(),
    contactPhone: z.string().min(8, 'Valid contact phone required'),
    notes: z.string().optional(),
  });

  const parsed = bookingSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid booking data', details: parsed.error.issues });
  }

  const newBooking = db.createBooking({
    ...parsed.data,
    status: 'pending',
  });

  res.status(201).json({
    booking: newBooking,
    message: 'Booking request placed successfully with status Pending until confirmed by the provider.',
  });
});

app.patch('/api/bookings/:id', (req: Request, res: Response) => {
  const schema = z.object({
    status: z.enum(['pending', 'accepted', 'rejected', 'cancelled', 'completed']),
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  const updated = db.updateBookingStatus(req.params.id, parsed.data.status);
  if (!updated) {
    return res.status(404).json({ error: 'Booking not found' });
  }
  res.json({ booking: updated });
});

// 10. Reviews & Ratings
app.get('/api/reviews', (req: Request, res: Response) => {
  const providerId = req.query.providerId as string;
  if (!providerId) {
    return res.status(400).json({ error: 'providerId parameter is required' });
  }
  const reviews = db.getReviewsByProvider(providerId);
  res.json({ reviews });
});

app.post('/api/reviews', (req: Request, res: Response) => {
  const reviewSchema = z.object({
    userId: z.string().default('user-demo-123'),
    userName: z.string().min(2, 'Name required'),
    providerId: z.string(),
    rating: z.number().min(1).max(5),
    comment: z.string().min(5, 'Review comment must be at least 5 characters'),
    isVerifiedVisit: z.boolean().default(true),
  });

  const parsed = reviewSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid review', details: parsed.error.issues });
  }

  const newReview = db.createReview(parsed.data);
  res.status(201).json({ review: newReview, message: 'Review submitted successfully.' });
});

// 11. Disaster Guides (Before, During, After)
app.get('/api/disasters/guides', (req: Request, res: Response) => {
  const guides = db.getDisasterGuides();
  res.json({ guides });
});

app.get('/api/disasters/guides/:id', (req: Request, res: Response) => {
  const guide = db.getDisasterGuideById(req.params.id);
  if (!guide) {
    return res.status(404).json({ error: 'Disaster guide not found' });
  }
  res.json({ guide });
});

// 12. Official Alerts
app.get('/api/alerts', (req: Request, res: Response) => {
  const alerts = db.getAlerts();
  res.json({ alerts });
});

app.post('/api/alerts', (req: Request, res: Response) => {
  const alertSchema = z.object({
    hazardType: z.string(),
    title: z.string(),
    affectedArea: z.string(),
    severity: z.enum(['warning', 'severe', 'critical', 'advisory']),
    source: z.string(),
    details: z.string(),
    instructions: z.string(),
    issueTime: z.string().default(() => new Date().toISOString()),
    expiryTime: z.string().optional(),
    verifiedStatus: z.boolean().default(true),
  });

  const parsed = alertSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid alert data', details: parsed.error.issues });
  }

  const alert = db.createAlert(parsed.data);
  res.status(201).json({ alert });
});

// 13. Emergency Contacts
app.get('/api/emergency-contacts', (req: Request, res: Response) => {
  const contacts = db.getEmergencyContacts();
  res.json({ contacts });
});

// 14. Emergency Reports (Citizen hazard reporting)
app.get('/api/reports', (req: Request, res: Response) => {
  const reports = db.getReports();
  res.json({ reports });
});

app.post('/api/reports', (req: Request, res: Response) => {
  const reportSchema = z.object({
    userId: z.string().optional(),
    userName: z.string().default('Anonymous Citizen'),
    reportType: z.enum(['disaster_hazard', 'road_block', 'incorrect_listing', 'shortage', 'other']),
    targetProviderId: z.string().optional(),
    title: z.string().min(5),
    description: z.string().min(10),
    locationName: z.string().min(3),
    latitude: z.number().optional(),
    longitude: z.number().optional(),
    urgency: z.enum(['low', 'medium', 'high', 'critical']).default('medium'),
  });

  const parsed = reportSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid report', details: parsed.error.issues });
  }

  const report = db.createReport(parsed.data);
  res.status(201).json({ report, message: 'Report submitted to disaster control room and moderators.' });
});

app.patch('/api/reports/:id', (req: Request, res: Response) => {
  const schema = z.object({
    status: z.enum(['pending', 'investigating', 'resolved', 'dismissed']),
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid report status' });
  }

  const updated = db.updateReportStatus(req.params.id, parsed.data.status);
  if (!updated) {
    return res.status(404).json({ error: 'Report not found' });
  }
  res.json({ report: updated });
});

// 15a. SOS Gateway Status (Check email & telephony readiness)
app.get('/api/sos/gateway-status', (_req: Request, res: Response) => {
  const status = getSosGatewayStatus();
  res.json(status);
});

// 15b. SOS Gateway Config (Save credentials for Gmail App Password or Twilio/Fast2SMS)
app.post('/api/sos/gateway-config', (req: Request, res: Response) => {
  const configSchema = z.object({
    smtpHost: z.string().optional(),
    smtpPort: z.number().optional(),
    smtpUser: z.string().optional(),
    smtpPass: z.string().optional(),
    twilioSid: z.string().optional(),
    twilioAuth: z.string().optional(),
    twilioFrom: z.string().optional(),
    fast2smsApiKey: z.string().optional(),
    resendApiKey: z.string().optional(),
  });

  const parsed = configSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid config format', details: parsed.error.issues });
  }

  const result = updateSosGatewayConfig(parsed.data);
  res.json(result);
});

// 15c. SOS Gateway Test (Verify connection to SMTP and Telephony carriers)
app.post('/api/sos/gateway-test', async (_req: Request, res: Response) => {
  const result = await testSosGatewayConnection();
  res.json(result);
});

// 15. SOS Emergency Dispatch (Calls mobile + Forwards email directly without requiring external apps)
app.post('/api/sos/alert', async (req: Request, res: Response) => {
  const sosSchema = z.object({
    userName: z.string().default('Citizen in Distress'),
    userPhone: z.string().optional(),
    locationName: z.string(),
    latitude: z.number(),
    longitude: z.number(),
    targetPhone: z.string().default('9373783496'),
    targetEmail: z.string().default('sumeetchendke@gmail.com'),
    emergencyType: z.string().default('General Medical / Safety SOS'),
    notes: z.string().optional(),
    serviceType: z.string().optional(),
    selectedFacility: z.object({
      id: z.string().optional(),
      name: z.string(),
      category: z.string().optional(),
      address: z.string().optional(),
      phone: z.string().optional(),
      latitude: z.number().optional(),
      longitude: z.number().optional(),
      distanceKm: z.number().optional(),
    }).optional(),
  });

  const parsed = sosSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid SOS payload', details: parsed.error.issues });
  }

  const {
    userName,
    userPhone,
    locationName,
    latitude,
    longitude,
    targetPhone,
    targetEmail,
    emergencyType,
    notes,
    serviceType,
    selectedFacility,
  } = parsed.data;

  // Shortest turn-by-turn driving route from responder's location to the user
  const shortestPathUrl = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}&travelmode=driving`;
  const googlePinUrl = `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;
  const timestamp = new Date().toISOString();

  // Shortest route from victim to chosen facility
  let facilityRouteUrl: string | undefined = undefined;
  if (selectedFacility) {
    if (selectedFacility.latitude && selectedFacility.longitude) {
      facilityRouteUrl = `https://www.google.com/maps/dir/?api=1&origin=${latitude},${longitude}&destination=${selectedFacility.latitude},${selectedFacility.longitude}&travelmode=driving`;
    } else if (selectedFacility.name) {
      facilityRouteUrl = `https://www.google.com/maps/dir/?api=1&origin=${latitude},${longitude}&destination=${encodeURIComponent(`${selectedFacility.name} ${selectedFacility.address || ''}`)}&travelmode=driving`;
    }
  }

  const facilityLabel = selectedFacility ? ` [${serviceType ? `${serviceType}: ` : ''}${selectedFacility.name}]` : (serviceType ? ` [${serviceType}]` : '');

  // Create an emergency alert record in the database
  const alertRecord = db.createAlert({
    hazardType: 'sos_emergency',
    title: `🚨 EMERGENCY SOS${facilityLabel}: ${userName} requested help at ${locationName}`,
    affectedArea: locationName,
    severity: 'critical',
    source: 'ResQ SOS Dispatch Engine',
    details: `Immediate SOS call forwarded to ${targetPhone} and alert email dispatched to ${targetEmail}.${selectedFacility ? ` Designated Facility: ${selectedFacility.name} (${selectedFacility.phone || 'No phone'}). Facility Route: ${facilityRouteUrl}.` : ''} Caller Coordinates: ${latitude.toFixed(5)}, ${longitude.toFixed(5)}. Shortest Navigation Route: ${shortestPathUrl}`,
    instructions: `Call ${targetPhone} immediately or follow shortest navigation route: ${shortestPathUrl}`,
    issueTime: timestamp,
    verifiedStatus: true,
  });

  // Execute direct server-side email and telephony dispatch (Zero 3rd party apps required)
  const dispatchResult = await dispatchDirectSos({
    userName,
    userPhone,
    locationName,
    latitude,
    longitude,
    targetPhone,
    targetEmail,
    emergencyType,
    notes,
    serviceType,
    selectedFacility,
  });

  const emailSubject = selectedFacility
    ? `🚨 URGENT SOS ALERT - ${serviceType ? `${serviceType}: ` : ''}${selectedFacility.name} requested at ${locationName}`
    : `🚨 URGENT SOS ALERT - Immediate Help Needed at ${locationName}`;

  const emailBody = [
    `URGENT SOS EMERGENCY ASSISTANCE REQUEST`,
    `========================================`,
    `Time of Alert: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })} IST`,
    `Caller: ${userName} ${userPhone ? `(${userPhone})` : ''}`,
    `Emergency Type: ${emergencyType}`,
    serviceType ? `Service Type: ${serviceType}` : '',
    ``,
    `VICTIM LIVE LOCATION:`,
    `Location Name: ${locationName}`,
    `Exact GPS Coordinates: ${latitude.toFixed(5)}, ${longitude.toFixed(5)}`,
    ``,
    `SHORTEST PATH TO REACH THE USER:`,
    `Click below for instant turn-by-turn driving directions from your location directly to the user:`,
    `${shortestPathUrl}`,
    ``,
    `GOOGLE MAPS PIN:`,
    `${googlePinUrl}`,
    ``,
    selectedFacility ? [
      `DESIGNATED FACILITY & EMERGENCY CONTACTS:`,
      `Facility: ${selectedFacility.name}`,
      selectedFacility.phone ? `Emergency Contact Phone: ${selectedFacility.phone}` : '',
      selectedFacility.address ? `Address: ${selectedFacility.address}` : '',
      selectedFacility.distanceKm !== undefined ? `Distance from Victim: ${selectedFacility.distanceKm.toFixed(1)} km` : '',
      facilityRouteUrl ? `Shortest Route (Victim to Facility):\n${facilityRouteUrl}` : '',
      ``,
    ].filter(Boolean).join('\n') : '',
    notes ? `Additional Details: ${notes}\n` : '',
    `Forwarded automatically by ResQ Emergency Assistance Platform to ${targetPhone} and ${targetEmail}.`,
  ].filter(Boolean).join('\n');

  const whatsappText = selectedFacility
    ? `🚨 *EMERGENCY SOS ALERT!*\nHelp needed at: *${locationName}*\nService: *${serviceType || 'Emergency'}*\nFacility: *${selectedFacility.name}* (Ph: ${selectedFacility.phone || 'N/A'})\nGPS: ${latitude}, ${longitude}\nShortest Route: ${shortestPathUrl}`
    : `🚨 *EMERGENCY SOS ALERT!*\nHelp needed at: *${locationName}*\nGPS: ${latitude}, ${longitude}\nShortest Driving Route: ${shortestPathUrl}`;

  res.status(200).json({
    ...dispatchResult,
    alertId: alertRecord.id,
    emailSubject,
    emailBody,
    facilityRouteUrl,
    webGmailUrl: `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(targetEmail)}&su=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`,
    whatsappUrl: `https://web.whatsapp.com/send?phone=91${targetPhone.replace(/[^0-9]/g, '')}&text=${encodeURIComponent(whatsappText)}`,
    mailtoUrl: `mailto:${targetEmail}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`,
    telUrl: `tel:${targetPhone}`,
    smsUrl: `sms:${targetPhone}?body=${encodeURIComponent(`🚨 EMERGENCY SOS! Help needed at ${locationName}. Shortest route: ${shortestPathUrl}`)}`,
  });
});

// 16. Relief Resources
app.get('/api/relief-resources', (req: Request, res: Response) => {
  const lat = parseFloat(req.query.lat as string) || 28.6304;
  const lng = parseFloat(req.query.lng as string) || 77.2177;
  const resources = db.getReliefResources(lat, lng);
  res.json({ resources });
});

// 16. Gemini Flash AI Assistant
app.post('/api/ai/chat', async (req: Request, res: Response) => {
  try {
    const { message, userLat, userLng, locationName, conversationHistory } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message string is required' });
    }

    const lat = typeof userLat === 'number' ? userLat : 28.6304;
    const lng = typeof userLng === 'number' ? userLng : 77.2177;
    const loc = typeof locationName === 'string' ? locationName : 'Connaught Place, New Delhi';

    const result = await handleGeminiAssistantChat({
      message,
      userLat: lat,
      userLng: lng,
      locationName: loc,
      conversationHistory,
    });

    res.json(result);
  } catch (error: any) {
    console.error('[Gemini API Endpoint Error]', error);
    res.status(500).json({
      error: 'Assistant processing error',
      details: error?.message || 'Unknown error',
    });
  }
});

// 17. Admin Overview
app.get('/api/admin/overview', (req: Request, res: Response) => {
  const stats = db.getAdminStats();
  const recentReports = db.getReports().slice(0, 5);
  const recentBookings = db.bookings.slice(0, 5);
  const activeAlerts = db.getAlerts();

  res.json({
    stats,
    recentReports,
    recentBookings,
    activeAlerts,
  });
});

// Global Error Handler
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('[Express Server Error]', err);
  res.status(500).json({
    error: 'Internal Server Error',
    message: err.message,
  });
});

// Mount Vite in dev or serve static files in production
async function startServer() {
  if (!isProduction) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ResQ Platform Server] listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
